import React, { useMemo, useState } from "react";
import { ArrowLeftRight, PackagePlus, AlertCircle, Search, ShieldCheck, X, DollarSign, Trash2, Edit, History, Package, TrendingUp, Filter, Download, Plus, ArrowRightLeft, LayoutGrid, List, Settings2, Tag, Building2, Save, RefreshCw, Minus } from "lucide-react";
import { useStore } from "../store/useStore";
import { cn, generateId } from "../lib/utils";
import { Product, Category } from "../types";
import { InfoTooltip } from "../components/InfoTooltip";
import { TransferHistory } from "../components/TransferHistory";
import { PrintLabels } from "../components/PrintLabels";
import { ABCAnalysis } from "../components/ABCAnalysis";
import { RestockAlerts } from "../components/RestockAlerts";
import { useBarcodeScanner } from "../hooks/useBarcodeScanner";

export default function Inventory() {
  const { 
    products, inventory, branches, addProduct, updateProduct, 
    transferInventory, setInventoryQuantity, deleteProduct, deleteCategory,
    transfers, categories, batchDeleteProducts, batchUpdateProducts, getBaseCurrency, currencies,
    currentUser, addNotification, users
  } = useStore();
  const currentBranchId = currentUser?.branchId || branches[0]?.id || '';
  const baseCurrency = getBaseCurrency();

  const [searchQuery, setSearchQuery] = useState("");
  const [debouncedSearchQuery, setDebouncedSearchQuery] = useState("");

  // Debounce search query to improve performance on low-end tablets
  React.useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearchQuery(searchQuery);
    }, 200);
    return () => clearTimeout(timer);
  }, [searchQuery]);
  
  useBarcodeScanner((barcode) => {
    setSearchQuery(barcode);
  });
  const [selectedBranch, setSelectedBranch] = useState("all");
  const [showAddModal, setShowAddModal] = useState(false);
  const [managingStockProduct, setManagingStockProduct] = useState<Product | null>(null);
  const [transferQuantity, setTransferQuantity] = useState<number>(0);
  const [targetBranchId, setTargetBranchId] = useState<string>("");
  const [transferVariant, setTransferVariant] = useState<string>("");

  const handleTransfer = async (productId: string, fromBranchId: string) => {
    if (!targetBranchId || transferQuantity <= 0) {
      addNotification("Selecciona una sucursal destino y una cantidad válida.", 'warning');
      return;
    }
    
    const success = await transferInventory(productId, fromBranchId, targetBranchId, transferQuantity, transferVariant);
    if (success) {
      addNotification("Transferencia completada con éxito.", 'success');
      setTransferQuantity(0);
      setTargetBranchId("");
    } else {
      addNotification("Error al realizar la transferencia. Verifica el stock disponible.", 'error');
    }
  };
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [viewMode, setViewMode] = useState<'table' | 'grid'>('table');
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [stockFilter, setStockFilter] = useState<'all' | 'in_stock' | 'low' | 'out'>('all');
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<'products' | 'transfers' | 'labels' | 'abc' | 'restock' | 'bulk'>('products');
  const [showBatchPriceModal, setShowBatchPriceModal] = useState(false);
  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [activeFormTab, setActiveFormTab] = useState<'general' | 'stock' | 'extra'>('general');
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [categoryFormData, setCategoryFormData] = useState({ name: "", department: "" });
  const [batchPriceAdjust, setBatchPriceAdjust] = useState({ type: 'percentage' as 'percentage' | 'fixed', value: 0, direction: 'increase' as 'increase' | 'decrease' });
  const [bulkChanges, setBulkChanges] = useState<Record<string, { costPrice?: number, price?: number, quantity?: number, baseSalary?: number, commissionRate?: number }>>({});
  const [isSavingBulk, setIsSavingBulk] = useState(false);
  const [bulkBranchId, setBulkBranchId] = useState<string>(branches[0]?.id || "");
  const [bulkMode, setBulkMode] = useState<'products' | 'users'>('products');

  const [transferSubTab, setTransferSubTab] = useState<'history' | 'new'>('history');
  const [bulkTransferItems, setBulkTransferItems] = useState<{ productId: string, quantity: number, variant?: string }[]>([]);
  const [bulkTransferSourceId, setBulkTransferSourceId] = useState(currentBranchId);
  const [bulkTransferTargetId, setBulkTransferTargetId] = useState("");
  const [transferSearch, setTransferSearch] = useState("");
  const [isExecutingTransfer, setIsExecutingTransfer] = useState(false);

  // Auto-select first branch when they load
  React.useEffect(() => {
    if (!bulkBranchId && branches.length > 0) {
      setBulkBranchId(branches[0].id);
    }
  }, [branches, bulkBranchId]);

  const handleBulkChange = (id: string, field: 'costPrice' | 'price' | 'quantity' | 'baseSalary' | 'commissionRate', value: number) => {
    const [prodId, branchId] = id.split(':::');
    
    setBulkChanges(prev => {
      const next = { ...prev };
      
      if (field === 'quantity') {
        // Quantity is branch-specific
        next[id] = { ...(next[id] || {}), [field]: value };
      } else if (field === 'baseSalary' || field === 'commissionRate') {
        // User fields
        next[id] = { ...(next[id] || {}), [field]: value };
      } else {
        // Price/Cost are global for the product. Update ALL rows for this product.
        // We find all keys starting with this prodId and update them to keep UI in sync
        const productRows = Object.keys(next).filter(key => key.startsWith(`${prodId}:::`));
        
        // If no rows exist yet for this product in next, create one for current row
        if (productRows.length === 0) {
          next[id] = { ...(next[id] || {}), [field]: value };
        } else {
          productRows.forEach(key => {
            next[key] = { ...(next[key] || {}), [field]: value };
          });
        }
      }
      return next;
    });
  };

  const saveBulkChanges = async () => {
    setIsSavingBulk(true);
    try {
      // Collect unique product updates to avoid redundant calls
      const productUpdates: Record<string, { costPrice?: number, price?: number }> = {};
      const userUpdates: Record<string, { baseSalary?: number, commissionRate?: number }> = {};
      
      for (const [id, changes] of Object.entries(bulkChanges)) {
        if (id.startsWith('user:::')) {
          const userId = id.replace('user:::', '');
          userUpdates[userId] = {
            ...userUpdates[userId],
            ...(changes.baseSalary !== undefined ? { baseSalary: changes.baseSalary } : {}),
            ...(changes.commissionRate !== undefined ? { commissionRate: changes.commissionRate } : {})
          };
          continue;
        }

        const [prodId] = id.split(':::');
        
        // Latest request: Only Price and User salary
        if (changes.price !== undefined) {
          productUpdates[prodId] = {
            ...productUpdates[prodId],
            price: changes.price
          };
        }
      }

      // Apply product updates (price/cost)
      for (const [prodId, updates] of Object.entries(productUpdates)) {
        updateProduct(prodId, updates);
      }

      // Apply user updates (salaries)
      const { updateUser } = useStore.getState();
      for (const [userId, updates] of Object.entries(userUpdates)) {
        updateUser(userId, updates);
      }

      setBulkChanges({});
      addNotification("Cambios masivos guardados con éxito", 'success');
    } catch (err) {
      addNotification("Error al guardar cambios masivos", 'error');
    } finally {
      setIsSavingBulk(false);
    }
  };

  const handleBatchDelete = () => {
    if (window.confirm(`¿Seguro que deseas eliminar ${selectedItems.length} productos?`)) {
      batchDeleteProducts(selectedItems);
      setSelectedItems([]);
    }
  };

  const handleBatchUpdateStatus = (status: 'active' | 'discontinued' | 'draft') => {
    batchUpdateProducts(selectedItems, { status });
    setSelectedItems([]);
  };

  const handleBatchPriceApply = () => {
    const factor = batchPriceAdjust.direction === 'increase' ? 1 : -1;
    
    selectedItems.forEach(id => {
      const product = products.find(p => p.id === id);
      if (product) {
        let newPrice = product.price;
        if (batchPriceAdjust.type === 'percentage') {
          newPrice = product.price * (1 + (batchPriceAdjust.value / 100) * factor);
        } else {
          newPrice = product.price + (batchPriceAdjust.value * factor);
        }
        updateProduct(id, { price: Math.max(0, newPrice), margin: Math.max(0, newPrice - product.costPrice) });
      }
    });
    
    setShowBatchPriceModal(false);
    setSelectedItems([]);
    addNotification(`Se han actualizado ${selectedItems.length} precios.`, 'success');
  };

  // Form State
  const [formData, setFormData] = useState<Partial<Product & { initialQuantity: number, initialBranchId: string, initialVariant?: string, initialVariantQuantities?: { [key: string]: number } }>>({
    name: "",
    sku: "",
    barcode: "",
    costPrice: 0,
    price: 0,
    margin: 0,
    categoryId: "",
    color: "bg-slate-100 text-slate-700",
    commissionValue: 0,
    initialQuantity: 0,
    initialBranchId: branches?.[0]?.id || "",
    availableSizes: [],
    availableColors: [],
    initialVariantQuantities: {}
  });

  const [newSize, setNewSize] = useState("");
  const [newColor, setNewColor] = useState("");
  const [showKitPicker, setShowKitPicker] = useState(false);
  const [kitQuery, setKitQuery] = useState("");

  const handleCostPriceChange = (cost: number, price: number) => {
    const margin = price - cost;
    setFormData(prev => ({ ...prev, costPrice: cost, price, margin }));
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingProduct) {
      updateProduct(editingProduct.id, formData);
      addNotification("Producto actualizado correctamente.", 'success');
    } else {
      const { initialQuantity, initialBranchId, initialVariant, initialVariantQuantities, ...productData } = formData;
      const finalBranchId = initialBranchId || (branches?.length > 0 ? branches[0].id : "");
      const newProduct: Product = {
        ...productData as Product,
        id: generateId('PRD'),
      };
      addProduct(newProduct, initialQuantity, finalBranchId, initialVariant, initialVariantQuantities);
    }
    setShowAddModal(false);
    setEditingProduct(null);
    setActiveFormTab('general');
    setFormData({ 
      name: "", sku: "", barcode: "", costPrice: 0, price: 0, margin: 0, categoryId: "", 
      color: "bg-slate-100 text-slate-700", commissionValue: 0,
      initialQuantity: 0, initialBranchId: branches?.[0]?.id || "",
      availableSizes: [], availableColors: [], initialVariantQuantities: {}
    });
  };

  const exportToCSV = () => {
    const headers = ["ID", "Nombre", "SKU", "EAN", "Departamento", "Costo", "Precio", "Stock Total", "Unidad", "Estado"];
    const rows = inventoryView.map(p => [
      p.id,
      p.name,
      p.sku,
      p.barcode || "",
      categories.find(c => c.id === p.categoryId)?.name || "",
      p.costPrice,
      p.price,
      p.totalStock,
      p.unit || "uds",
      p.status || "active"
    ]);

    const csvContent = [
      headers.join(","),
      ...rows.map(r => r.join(","))
    ].join("\n");

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `inventario_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCategorySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const { addCategory, updateCategory } = useStore.getState();
    if (editingCategory) {
      updateCategory(editingCategory.id, categoryFormData);
    } else {
      addCategory({
        id: generateId('CAT'),
        ...categoryFormData
      } as Category);
    }
    setEditingCategory(null);
    setCategoryFormData({ name: "", department: "" });
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
          // Resize and compress
          const canvas = document.createElement('canvas');
          const MAX_WIDTH = 600;
          const MAX_HEIGHT = 600;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          
          // Use a medium quality jpeg for better compression
          const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
          setFormData(prev => ({ ...prev, image: dataUrl }));
        };
        img.src = event.target?.result as string;
      };
      reader.readAsDataURL(file);
    }
  };

  const [displayLimit, setDisplayLimit] = useState(200);

  const inventoryData = useMemo(() => {
    if (!products || !inventory) return { full: [], paginated: [] };
    let filtered = products.map(product => {
      const productLevels = inventory.filter(i => i.productId === product.id && (selectedBranch === 'all' || i.branchId === selectedBranch));
      
      const totalStock = productLevels.reduce((acc, curr) => acc + curr.quantity, 0);
      const isLowStock = productLevels.some(i => i.quantity <= (product.minStockAlert || i.minQuantity));
      
      return {
        ...product,
        totalStock,
        isLowStock,
        levels: productLevels
      };
    });

    if (debouncedSearchQuery) {
      const query = debouncedSearchQuery.toLowerCase();
      filtered = filtered.filter(item => 
        item.name.toLowerCase().includes(query) || 
        item.sku.toLowerCase().includes(query) || 
        (item.barcode && item.barcode.includes(query))
      );
    }

    if (selectedCategory !== "all") {
      filtered = filtered.filter(p => p.categoryId === selectedCategory);
    }

    if (stockFilter === 'in_stock') {
      filtered = filtered.filter(p => p.totalStock > 0);
    } else if (stockFilter === 'low') {
      filtered = filtered.filter(p => p.isLowStock);
    } else if (stockFilter === 'out') {
      filtered = filtered.filter(p => p.totalStock === 0);
    }

    return {
      full: filtered,
      paginated: filtered.slice(0, displayLimit)
    };
  }, [products, inventory, debouncedSearchQuery, selectedBranch, selectedCategory, stockFilter, displayLimit]);

  const inventoryView = inventoryData.paginated;

  const formatMoney = (amount: number, currency = baseCurrency, withCode = true) => {
    const converted = currency.isBase ? amount : amount / (currency.rateToBase || 1);
    const formatted = converted.toLocaleString('es-CU', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    if (withCode) {
      return `${currency.code} ${currency.symbol}${formatted}`;
    }
    return `${currency.symbol} ${formatted}`;
  };

  const MultiCurrencyDisplay = ({ amount }: { amount: number }) => {
    const baseCurr = currencies.find(c => c.isBase) || baseCurrency;
    const secondaryCurr = currencies.filter(c => !c.isBase);
    const convertedBase = baseCurr.isBase ? amount : amount / (baseCurr.rateToBase || 1);
    const formattedBase = convertedBase.toLocaleString('es-CU', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

    return (
      <div className="mt-0.5 space-y-0.5">
        <div className="text-[11px] font-black text-primary leading-tight truncate flex items-center gap-1">
          <span className="text-[7.5px] font-black px-1 py-0.2 rounded bg-indigo-100/70 dark:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300 uppercase tracking-tighter">
            {baseCurr.code}
          </span>
          <span>{baseCurr.symbol}{formattedBase}</span>
        </div>
        {secondaryCurr.length > 0 && (
          <div className="text-[8px] font-bold text-muted flex flex-wrap items-center gap-x-1.5 gap-y-0.5">
            {secondaryCurr.map(c => {
              const val = amount / (c.rateToBase || 1);
              const formattedVal = val.toLocaleString('es-CU', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
              return (
                <span key={c.code} className="inline-flex items-center gap-0.5 whitespace-nowrap">
                  <span className="text-[6.5px] font-black uppercase text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-0.5 py-0.2 rounded">{c.code}</span>
                  <span className="text-[7.5px]">{c.symbol}{formattedVal}</span>
                </span>
              );
            })}
          </div>
        )}
      </div>
    );
  };

  const stats = useMemo(() => {
    // If all branches, show stats for ALL products even if filtered (as requested)
    const activeProducts = selectedBranch === 'all' ? inventoryData.full : inventoryData.full; 
    // Wait, if I want ALL products even if NOT filtered by search/category:
    let baseProducts = products.map(product => {
      const productLevels = inventory.filter(i => i.productId === product.id && (selectedBranch === 'all' || i.branchId === selectedBranch));
      const totalStock = productLevels.reduce((acc, curr) => acc + curr.quantity, 0);
      return { ...product, totalStock };
    });

    const targetProducts = selectedBranch === 'all' ? baseProducts : inventoryData.full;

    const totalProducts = targetProducts.length;
    const totalStock = targetProducts.reduce((sum, p) => sum + p.totalStock, 0);
    const lowStockCount = inventoryData.full.filter(p => p.isLowStock).length;
    const totalCostValue = targetProducts.reduce((sum, p) => sum + (p.costPrice * p.totalStock), 0);
    const totalSaleValue = targetProducts.reduce((sum, p) => sum + (p.price * p.totalStock), 0);
    const totalProfit = totalSaleValue - totalCostValue;

    return { totalProducts, totalStock, lowStockCount, totalCostValue, totalSaleValue, totalProfit };
  }, [inventoryData.full, products, inventory, selectedBranch]);

  return (
    <div className="space-y-3 animate-in fade-in slide-in-from-bottom-4 duration-500 h-full flex flex-col min-h-0">
      <header className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-2 px-1 shrink-0">
        <div>
          <h2 className="text-lg sm:text-xl font-black text-primary tracking-tight flex items-center gap-2 uppercase">
            Inventario
          </h2>
          <p className="text-[9px] sm:text-[10px] font-black text-muted uppercase tracking-widest">Stock Control</p>
        </div>
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-hide w-full sm:w-auto py-1">
          <button 
            onClick={exportToCSV}
            className="shrink-0 flex items-center gap-1.5 px-2.5 py-1.5 bg-secondary border border-base text-muted rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-subtle transition-all shadow-sm active:scale-95"
          >
            <Download className="w-3 h-3" />
            <span>CSV</span>
          </button>
          <button 
            onClick={() => setActiveTab('labels')}
            className="shrink-0 bg-slate-900 dark:bg-slate-800 text-white px-2.5 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-wider flex items-center justify-center gap-2 hover:bg-slate-800 dark:hover:bg-slate-700 transition-all shadow-md active:scale-95 whitespace-nowrap"
          >
            Etiquetas
          </button>
          <button 
            onClick={() => setActiveTab('abc')}
            className="shrink-0 bg-blue-600 text-white px-2.5 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-wider flex items-center justify-center gap-2 hover:bg-blue-700 transition-all shadow-md active:scale-95 whitespace-nowrap"
          >
            Análisis ABC
          </button>
          <button 
            onClick={() => {
              setEditingProduct(null);
              setFormData({ 
                name: "", sku: "", barcode: "", costPrice: 0, price: 0, margin: 0, categoryId: "", 
                color: "bg-slate-100 text-slate-700", commissionType: 'percentage', commissionValue: 0,
                initialQuantity: 0, initialBranchId: branches[0]?.id || ""
              });
              setShowAddModal(true);
            }}
            className="shrink-0 bg-indigo-600 text-white px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-wider flex items-center justify-center gap-2 hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 active:scale-95 whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5 shrink-0" />
            Nuevo
          </button>
        </div>
      </header>

      {/* Summary Cards Lineal - Responsive Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-1.5 sm:gap-2 px-1 shrink-0">
        <div className="bg-secondary p-1.5 sm:p-2 rounded-xl border border-base shadow-xs flex flex-col justify-between">
          <span className="text-[7px] sm:text-[7.5px] font-black uppercase text-muted tracking-wider">Tipos</span>
          <div className="text-[11px] font-black text-primary mt-0.5">{stats.totalProducts.toLocaleString()}</div>
        </div>
        <div className="bg-secondary p-1.5 sm:p-2 rounded-xl border border-base shadow-xs flex flex-col justify-between">
          <span className="text-[7px] sm:text-[7.5px] font-black uppercase text-muted tracking-wider">Costo</span>
          <div className="mt-0.5"><MultiCurrencyDisplay amount={stats.totalCostValue} /></div>
        </div>
        <div className="bg-secondary p-1.5 sm:p-2 rounded-xl border border-base shadow-xs flex flex-col justify-between">
          <span className="text-[7px] sm:text-[7.5px] font-black uppercase text-muted tracking-wider">Venta</span>
          <div className="mt-0.5"><MultiCurrencyDisplay amount={stats.totalSaleValue} /></div>
        </div>
        <div className="bg-indigo-50/70 dark:bg-indigo-950/40 p-1.5 sm:p-2 rounded-xl border border-indigo-100 dark:border-indigo-900/40 shadow-xs flex flex-col justify-between">
          <span className="text-[7px] sm:text-[7.5px] font-black uppercase text-indigo-600 dark:text-indigo-400 tracking-wider">Ganancia</span>
          <div className="mt-0.5"><MultiCurrencyDisplay amount={stats.totalProfit} /></div>
        </div>
        <div className="col-span-2 sm:col-span-1 bg-secondary p-1.5 sm:p-2 rounded-xl border border-base shadow-xs flex flex-col justify-between">
          <span className="text-[7px] sm:text-[7.5px] font-black uppercase text-rose-500 tracking-wider">Bajo Stock</span>
          <div className="text-[11px] font-black text-rose-600 dark:text-rose-400 mt-0.5">{stats.lowStockCount} alertas</div>
        </div>
      </div>

      {/* Advanced Unified Toolbar - Linear & Compact */}
      <div className="bg-secondary p-1.5 rounded-2xl border border-base shadow-sm flex flex-col lg:flex-row gap-2 items-center justify-between shrink-0">
        <div className="flex flex-wrap gap-2 items-center w-full lg:w-auto">
            <div className="flex-1 relative flex items-center gap-1.5">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted group-focus-within:text-indigo-500 transition-colors" />
                <input 
                  type="text" 
                  placeholder="Buscar productos..." 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 bg-subtle border border-base text-primary rounded-xl text-[11px] font-bold focus:bg-secondary focus:ring-1 focus:ring-indigo-500 outline-none transition-all placeholder:text-muted"
                />
              </div>
              <InfoTooltip text="Busca productos por nombre, SKU o código de barras." position="bottom" />
            </div>
            
            <div className="flex items-center gap-1.5 flex-wrap">
              <div className="flex items-center gap-1">
                <select 
                  value={selectedBranch}
                  onChange={(e) => setSelectedBranch(e.target.value)}
                  className="px-2.5 py-1.5 bg-subtle border border-base text-primary rounded-xl text-[10px] font-bold outline-none hover:bg-secondary transition-colors cursor-pointer appearance-none min-w-[110px]"
                >
                  <option value="all">Sucs: Todas</option>
                  {branches.map(b => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </select>
                <InfoTooltip text="Filtra por una sucursal específica para ver su stock local." position="bottom" />
              </div>

              <div className="flex items-center gap-1">
                <select 
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="px-2.5 py-1.5 bg-subtle border border-base text-primary rounded-xl text-[10px] font-bold outline-none hover:bg-secondary transition-colors cursor-pointer appearance-none min-w-[110px]"
                >
                  <option value="all">Cats: Todas</option>
                  {categories.map(cat => (
                    <option key={cat.id} value={cat.id}>{cat.name}</option>
                  ))}
                </select>
                <InfoTooltip text="Filtra los productos por su categoría o departamento." position="bottom" />
              </div>

            <button 
              onClick={() => setShowCategoryModal(true)}
              className="p-1.5 bg-subtle border border-base rounded-xl text-muted hover:text-indigo-600 hover:bg-secondary transition-all shadow-sm"
              title="Gestionar Categorías"
            >
              <Settings2 className="w-3.5 h-3.5" />
            </button>

            <select 
              value={stockFilter}
              onChange={(e) => setStockFilter(e.target.value as any)}
              className="px-2.5 py-1.5 bg-subtle border border-base text-primary rounded-xl text-[10px] font-bold outline-none hover:bg-secondary transition-colors cursor-pointer appearance-none min-w-[100px]"
            >
              <option value="all">Stock: Todo</option>
              <option value="in_stock">Solo con Stock (&gt;0)</option>
              <option value="low">Bajo Stock</option>
              <option value="out">Sin Exist. (0)</option>
            </select>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full lg:w-auto justify-end border-t lg:border-t-0 pt-2 lg:pt-0">
          <div className="bg-subtle p-0.5 rounded-lg flex gap-0.5 border border-base">
            <button 
              onClick={() => setViewMode('table')}
              title="Vista Lista"
              className={cn(
                "p-1.5 rounded-md transition-all",
                viewMode === 'table' ? "bg-primary text-indigo-600 shadow-xs ring-1 ring-black/5" : "text-muted hover:text-primary"
              )}
            >
              <List className="w-3.5 h-3.5" />
            </button>
            <button 
              onClick={() => setViewMode('grid')}
              title="Vista Cuadrícula Compacta"
              className={cn(
                "p-1.5 rounded-md transition-all",
                viewMode === 'grid' ? "bg-primary text-indigo-600 shadow-xs ring-1 ring-black/5" : "text-muted hover:text-primary"
              )}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Tabs - High contrast and modern segmented design */}
      <div className="flex items-center gap-1.5 bg-secondary p-1 rounded-xl border border-base shrink-0 w-fit shadow-xs">
        {(['products', 'transfers', 'restock', 'bulk'] as const)
          .filter(tab => tab !== 'transfers' || transfers.length > 0)
          .map(tab => {
            const isActive = activeTab === tab;
            return (
              <button 
                key={tab}
                onClick={() => setActiveTab(tab as any)}
                className={cn(
                  "whitespace-nowrap px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all cursor-pointer",
                  isActive 
                    ? "bg-indigo-600 text-white shadow-xs ring-1 ring-indigo-500/20" 
                    : "text-secondary hover:text-primary hover:bg-subtle"
                )}
              >
                {tab === 'products' ? 'Existencias' : tab === 'transfers' ? 'Traslados' : tab === 'restock' ? 'Alertas' : 'Edición Masiva'}
              </button>
            );
        })}
      </div>


      {/* Tab Content */}
      {activeTab === 'labels' && <PrintLabels />}
      {activeTab === 'abc' && <ABCAnalysis />}
      {activeTab === 'restock' && <RestockAlerts />}

      {activeTab === 'bulk' && (
        <div className="flex-1 min-h-0 bg-white dark:bg-slate-900 rounded-3xl shadow-xl border border-base overflow-hidden animate-in fade-in zoom-in-95 duration-300 flex flex-col">
          <div className="p-4 border-b border-base bg-slate-50/50 dark:bg-slate-800/50 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 shrink-0">
            <div className="flex items-center gap-4">
              <div>
                <h2 className="text-sm font-black text-primary uppercase tracking-tight">Edición Masiva</h2>
                <p className="text-[10px] font-bold text-muted uppercase">Actualiza precios y salarios rápidamente</p>
              </div>
              
              {/* Bulk Mode Toggle */}
              <div className="flex bg-slate-200 dark:bg-slate-800 p-0.5 rounded-xl ml-2">
                <button
                  onClick={() => setBulkMode('products')}
                  className={cn(
                    "px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all",
                    bulkMode === 'products' ? "bg-white dark:bg-slate-700 text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
                  )}
                >
                  Precios
                </button>
                <button
                  onClick={() => setBulkMode('users')}
                  className={cn(
                    "px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all",
                    bulkMode === 'users' ? "bg-white dark:bg-slate-700 text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
                  )}
                >
                  Salarios
                </button>
              </div>

              {/* Branch Selector for Bulk Edition - Only for products if we care about stock, but user said remove stock */}
              {bulkMode === 'products' && (
                <div className="flex flex-col gap-1 ml-2">
                  <span className="text-[8px] font-black text-muted uppercase tracking-widest px-1">Filtrar por Sala</span>
                  <select 
                    value={bulkBranchId}
                    onChange={(e) => setBulkBranchId(e.target.value)}
                    className="bg-white dark:bg-slate-800 border border-base rounded-xl px-3 py-1.5 text-[10px] font-black uppercase tracking-tight outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm min-w-[140px]"
                  >
                    <option value="">Todas las Salas</option>
                    {branches.map(b => (
                      <option key={b.id} value={b.id}>{b.name}</option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              {Object.keys(bulkChanges).length > 0 && (
                <button
                  onClick={() => setBulkChanges({})}
                  className="px-4 py-2 bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-slate-300 transition-all cursor-pointer"
                >
                  Descartar ({Object.keys(bulkChanges).length})
                </button>
              )}
              <button
                disabled={isSavingBulk || Object.keys(bulkChanges).length === 0}
                onClick={saveBulkChanges}
                className="flex-1 sm:flex-initial px-6 py-2 bg-indigo-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 disabled:opacity-50 disabled:shadow-none flex items-center justify-center gap-2 cursor-pointer"
              >
                {isSavingBulk ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                Guardar Cambios
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-auto">
            {bulkMode === 'products' ? (
              <table className="w-full text-left border-collapse min-w-[700px]">
                <thead className="sticky top-0 z-10 bg-slate-50 dark:bg-slate-800 border-b border-base">
                  <tr>
                    <th className="px-4 py-3 text-[9px] font-black text-muted uppercase tracking-widest">Producto</th>
                    <th className="px-4 py-3 text-[9px] font-black text-muted uppercase tracking-widest">SKU</th>
                    <th className="px-4 py-3 text-[9px] font-black text-muted uppercase tracking-widest text-center">Precio de Venta ({baseCurrency.symbol})</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-base">
                  {products.filter(p => 
                    p.name.toLowerCase().includes(debouncedSearchQuery.toLowerCase()) || 
                    p.sku?.toLowerCase().includes(debouncedSearchQuery.toLowerCase()) ||
                    p.barcode?.toLowerCase().includes(debouncedSearchQuery.toLowerCase())
                  ).map(product => {
                    // Prices are global, so we only show one row per product in this view
                    const rowKey = `${product.id}:::global`;
                    
                    // Look for price changes in ANY row of the same product to keep UI consistent
                    const otherRows = Object.entries(bulkChanges).find(([key, val]) => 
                      key.startsWith(`${product.id}:::`) && val.price !== undefined
                    );
                    const globalPriceChange = otherRows ? otherRows[1].price : undefined;
                    
                    return (
                      <tr key={product.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-3">
                            <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center text-[10px] font-bold", product.color || 'bg-slate-100')}>
                              {product.name.charAt(0)}
                            </div>
                            <div>
                              <div className="text-[11px] font-black text-primary uppercase leading-tight">{product.name}</div>
                              <div className="text-[8px] font-bold text-muted uppercase tracking-tighter">
                                {categories.find(c => c.id === product.categoryId)?.name || 'Sin Categoría'}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="text-[10px] font-black text-secondary uppercase tracking-tight">
                            {product.sku || 'SIN SKU'}
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex justify-center">
                            <input
                              type="number"
                              value={globalPriceChange !== undefined ? globalPriceChange : product.price}
                              onChange={(e) => handleBulkChange(rowKey, 'price', parseFloat(e.target.value) || 0)}
                              className={cn(
                                "w-32 px-3 py-2 bg-white dark:bg-slate-800 border rounded-xl text-xs font-black text-center outline-none focus:ring-2 focus:ring-indigo-500",
                                globalPriceChange !== undefined ? "border-amber-500 ring-1 ring-amber-500" : "border-base shadow-sm"
                              )}
                            />
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            ) : (
              <table className="w-full text-left border-collapse min-w-[700px]">
                <thead className="sticky top-0 z-10 bg-slate-50 dark:bg-slate-800 border-b border-base">
                  <tr>
                    <th className="px-4 py-3 text-[9px] font-black text-muted uppercase tracking-widest">Trabajador</th>
                    <th className="px-4 py-3 text-[9px] font-black text-muted uppercase tracking-widest">Rol</th>
                    <th className="px-4 py-3 text-[9px] font-black text-muted uppercase tracking-widest text-center">Salario Base (CUP)</th>
                    <th className="px-4 py-3 text-[9px] font-black text-muted uppercase tracking-widest text-center">Comisión (%)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-base">
                  {users.filter(u => u.name.toLowerCase().includes(debouncedSearchQuery.toLowerCase())).map(user => {
                    const rowKey = `user:::${user.id}`;
                    const changes = bulkChanges[rowKey] || {};
                    
                    return (
                      <tr key={user.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center text-[10px] font-black uppercase">
                              {user.name.charAt(0)}
                            </div>
                            <div>
                              <div className="text-[11px] font-black text-primary uppercase leading-tight">{user.name}</div>
                              <div className="text-[8px] font-bold text-muted uppercase tracking-tighter">{user.email}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <span className={cn(
                            "px-2 py-0.5 rounded-lg text-[8px] font-black uppercase tracking-widest",
                            user.role === 'admin' ? "bg-rose-100 text-rose-600" : "bg-blue-100 text-blue-600"
                          )}>
                            {user.role}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex justify-center">
                            {!user.isIndependent ? (
                              <input
                                type="number"
                                value={changes.baseSalary !== undefined ? changes.baseSalary : (user.baseSalary || 0)}
                                onChange={(e) => handleBulkChange(rowKey, 'baseSalary', parseFloat(e.target.value) || 0)}
                                className={cn(
                                  "w-32 px-3 py-2 bg-white dark:bg-slate-800 border rounded-xl text-xs font-black text-center outline-none focus:ring-2 focus:ring-indigo-500",
                                  changes.baseSalary !== undefined ? "border-amber-500 ring-1 ring-amber-500" : "border-base shadow-sm"
                                )}
                              />
                            ) : (
                              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded-lg">IDN (Sin Salario)</span>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex justify-center">
                            {!user.isIndependent ? (
                              <input
                                type="number"
                                step="0.1"
                                value={changes.commissionRate !== undefined ? changes.commissionRate : (user.commissionRate || 0)}
                                onChange={(e) => handleBulkChange(rowKey, 'commissionRate', parseFloat(e.target.value) || 0)}
                                className={cn(
                                  "w-32 px-3 py-2 bg-white dark:bg-slate-800 border rounded-xl text-xs font-black text-center outline-none focus:ring-2 focus:ring-indigo-500",
                                  changes.commissionRate !== undefined ? "border-amber-500 ring-1 ring-amber-500" : "border-base shadow-sm"
                                )}
                              />
                            ) : (
                              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded-lg">IDN (Sin Comisión)</span>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
          
          {((bulkMode === 'products' && products.length === 0) || (bulkMode === 'users' && users.length === 0)) && (
            <div className="py-20 text-center shrink-0">
              <Package className="w-12 h-12 text-slate-200 mx-auto mb-4" />
              <p className="text-xs font-bold text-muted uppercase">No se encontraron datos para editar</p>
            </div>
          )}
        </div>
      )}
      {activeTab === 'transfers' && (
        <div className="flex-1 flex flex-col min-h-0 bg-white dark:bg-slate-900 rounded-3xl shadow-xl border border-base overflow-hidden animate-in fade-in zoom-in-95 duration-300">
          <div className="p-4 border-b border-base bg-slate-50/50 dark:bg-slate-800/50 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 shrink-0">
            <div className="flex items-center gap-4">
              <div>
                <h2 className="text-sm font-black text-primary uppercase tracking-tight">Traslados de Mercancía</h2>
                <p className="text-[10px] font-bold text-muted uppercase">Mueve inventario entre salas de forma individual o masiva</p>
              </div>
              
              <div className="flex bg-slate-200 dark:bg-slate-800 p-0.5 rounded-xl ml-2">
                <button
                  onClick={() => setTransferSubTab('history')}
                  className={cn(
                    "px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all",
                    transferSubTab === 'history' ? "bg-white dark:bg-slate-700 text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
                  )}
                >
                  Historial
                </button>
                <button
                  onClick={() => setTransferSubTab('new')}
                  className={cn(
                    "px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all",
                    transferSubTab === 'new' ? "bg-white dark:bg-slate-700 text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
                  )}
                >
                  Nuevo Traslado
                </button>
              </div>
            </div>
          </div>

          <div className="flex-1 overflow-hidden flex flex-col">
            {transferSubTab === 'history' ? (
              <div className="flex-1 overflow-auto p-4">
                <TransferHistory />
              </div>
            ) : (
              <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
                <div className="p-4 bg-slate-50 dark:bg-slate-800/50 border-b border-base flex flex-col lg:flex-row gap-4 shrink-0">
                  <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[8px] font-black text-muted uppercase tracking-widest mb-1 px-1">Sala de Origen</label>
                      <select 
                        value={bulkTransferSourceId}
                        onChange={(e) => {
                          setBulkTransferSourceId(e.target.value);
                          setBulkTransferItems([]); // Clear items if source changes
                        }}
                        className="w-full bg-white dark:bg-slate-800 border border-base rounded-xl px-3 py-2 text-[10px] font-black uppercase outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm"
                      >
                        {branches.map(b => (
                          <option key={b.id} value={b.id}>{b.name}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[8px] font-black text-muted uppercase tracking-widest mb-1 px-1">Sala de Destino</label>
                      <select 
                        value={bulkTransferTargetId}
                        onChange={(e) => setBulkTransferTargetId(e.target.value)}
                        className="w-full bg-white dark:bg-slate-800 border border-base rounded-xl px-3 py-2 text-[10px] font-black uppercase outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm"
                      >
                        <option value="">Seleccionar destino...</option>
                        {branches.filter(b => b.id !== bulkTransferSourceId).map(b => (
                          <option key={b.id} value={b.id}>{b.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div className="flex items-end gap-2">
                    <button
                      disabled={isExecutingTransfer || bulkTransferItems.length === 0 || !bulkTransferTargetId}
                      onClick={async () => {
                        setIsExecutingTransfer(true);
                        try {
                          let successCount = 0;
                          for (const item of bulkTransferItems) {
                            const success = await transferInventory(item.productId, bulkTransferSourceId, bulkTransferTargetId, item.quantity, item.variant);
                            if (success) successCount++;
                          }
                          if (successCount === bulkTransferItems.length) {
                            addNotification(`Traslado masivo completado: ${successCount} productos enviados.`, 'success');
                            setBulkTransferItems([]);
                            setTransferSubTab('history');
                          } else if (successCount > 0) {
                            addNotification(`Se trasladaron ${successCount} de ${bulkTransferItems.length} productos. Revisa el stock disponible.`, 'warning');
                          } else {
                            addNotification("No se pudo realizar el traslado. Verifica el stock disponible.", 'error');
                          }
                        } catch (err) {
                          addNotification("Error al procesar el traslado masivo.", 'error');
                        } finally {
                          setIsExecutingTransfer(false);
                        }
                      }}
                      className="w-full lg:w-auto px-6 py-2.5 bg-indigo-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 disabled:opacity-50 disabled:shadow-none flex items-center justify-center gap-2 cursor-pointer h-[42px]"
                    >
                      {isExecutingTransfer ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <ArrowRightLeft className="w-3.5 h-3.5" />}
                      Ejecutar Traslado ({bulkTransferItems.length})
                    </button>
                    {bulkTransferItems.length > 0 && (
                      <button
                        onClick={() => setBulkTransferItems([])}
                        className="p-2.5 bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-400 rounded-xl hover:bg-slate-300 transition-all h-[42px]"
                        title="Vaciar lista"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>

                <div className="flex-1 flex flex-col lg:flex-row min-h-0">
                  {/* Product Search & Selection */}
                  <div className="flex-1 flex flex-col border-r border-base min-h-0 bg-slate-50/30 dark:bg-slate-900/30">
                    <div className="p-4 border-b border-base bg-white dark:bg-slate-900/50">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                        <input 
                          type="text" 
                          placeholder="Buscar productos para trasladar..."
                          value={transferSearch}
                          onChange={(e) => setTransferSearch(e.target.value)}
                          className="w-full pl-9 pr-4 py-2.5 bg-white dark:bg-slate-800 border border-base rounded-xl text-xs font-black uppercase outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm"
                        />
                      </div>
                    </div>
                    <div className="flex-1 overflow-auto p-2">
                      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-2">
                        {products
                          .filter(p => 
                            !bulkTransferItems.some(item => item.productId === p.id) &&
                            (p.name.toLowerCase().includes(transferSearch.toLowerCase()) || 
                             p.sku?.toLowerCase().includes(transferSearch.toLowerCase()))
                          )
                          .slice(0, 20)
                          .map(product => {
                            const stock = inventory.find(inv => inv.productId === product.id && inv.branchId === bulkTransferSourceId)?.quantity || 0;
                            return (
                              <button
                                key={product.id}
                                disabled={stock <= 0}
                                onClick={() => {
                                  setBulkTransferItems(prev => [...prev, { productId: product.id, quantity: 1 }]);
                                }}
                                className={cn(
                                  "p-3 rounded-2xl border text-left transition-all group flex flex-col gap-1.5",
                                  stock > 0 
                                    ? "bg-white dark:bg-slate-800 border-base hover:border-indigo-500 hover:shadow-md cursor-pointer" 
                                    : "bg-slate-50 dark:bg-slate-900 border-base opacity-60 grayscale cursor-not-allowed"
                                )}
                              >
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-2">
                                    <div className={cn("w-6 h-6 rounded-lg flex items-center justify-center text-[10px] font-bold", product.color)}>
                                      {product.name.charAt(0)}
                                    </div>
                                    <div className="min-w-0">
                                      <p className="text-[10px] font-black text-primary uppercase truncate leading-none mb-0.5">{product.name}</p>
                                      <p className="text-[8px] font-bold text-muted uppercase tracking-tighter truncate">{product.sku || 'SIN SKU'}</p>
                                    </div>
                                  </div>
                                  <Plus className="w-3.5 h-3.5 text-indigo-400 group-hover:text-indigo-600 transition-colors" />
                                </div>
                                <div className="flex items-center justify-between mt-auto pt-1.5 border-t border-slate-50 dark:border-slate-700/50">
                                  <span className="text-[8px] font-black text-muted uppercase tracking-widest">Disponible:</span>
                                  <span className={cn(
                                    "text-[9px] font-black px-1.5 py-0.5 rounded-md",
                                    stock > 5 ? "text-emerald-600 bg-emerald-50 dark:bg-emerald-950/30" : "text-amber-600 bg-amber-50 dark:bg-amber-950/30"
                                  )}>
                                    {stock} u.
                                  </span>
                                </div>
                              </button>
                            );
                          })}
                      </div>
                      {transferSearch && products.filter(p => (p.name.toLowerCase().includes(transferSearch.toLowerCase()) || p.sku?.toLowerCase().includes(transferSearch.toLowerCase()))).length === 0 && (
                        <div className="py-10 text-center">
                          <Package className="w-8 h-8 text-slate-200 mx-auto mb-2" />
                          <p className="text-[10px] font-bold text-muted uppercase">No se encontraron productos</p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Selected Items List */}
                  <div className="w-full lg:w-96 flex flex-col bg-white dark:bg-slate-900 min-h-0 border-l border-base">
                    <div className="p-4 border-b border-base flex items-center justify-between bg-slate-50 dark:bg-slate-800/30 shrink-0">
                      <h3 className="text-[10px] font-black text-primary uppercase tracking-widest flex items-center gap-2">
                        <List className="w-3.5 h-3.5 text-indigo-500" />
                        Lista de Traslado
                      </h3>
                      <span className="px-2 py-0.5 bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 rounded-lg text-[10px] font-black">
                        {bulkTransferItems.length}
                      </span>
                    </div>
                    <div className="flex-1 overflow-auto p-4 space-y-2">
                      {bulkTransferItems.length === 0 ? (
                        <div className="h-full flex flex-col items-center justify-center text-center p-6 grayscale opacity-60">
                          <ArrowRightLeft className="w-12 h-12 text-slate-300 mb-4" />
                          <p className="text-xs font-black text-slate-400 uppercase tracking-widest mb-1">Tu lista está vacía</p>
                          <p className="text-[10px] font-bold text-slate-400 uppercase">Busca y añade productos para comenzar el traslado</p>
                        </div>
                      ) : (
                        bulkTransferItems.map((item, index) => {
                          const product = products.find(p => p.id === item.productId);
                          const stock = inventory.find(inv => inv.productId === item.productId && inv.branchId === bulkTransferSourceId)?.quantity || 0;
                          
                          return (
                            <div key={item.productId} className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-base group animate-in slide-in-from-right-2 duration-200">
                              <div className="flex items-center justify-between gap-3 mb-2">
                                <div className="min-w-0 flex-1">
                                  <p className="text-[10px] font-black text-primary uppercase truncate leading-tight">{product?.name}</p>
                                  <p className="text-[8px] font-bold text-muted uppercase tracking-tighter truncate">{product?.sku}</p>
                                </div>
                                <button 
                                  onClick={() => setBulkTransferItems(prev => prev.filter(i => i.productId !== item.productId))}
                                  className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-lg transition-all"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                              <div className="flex items-center justify-between gap-4 bg-white dark:bg-slate-900 p-2 rounded-xl border border-base shadow-sm">
                                <div className="flex flex-col">
                                  <span className="text-[7px] font-black text-muted uppercase tracking-widest">Disponible</span>
                                  <span className="text-[10px] font-black text-secondary">{stock} u.</span>
                                </div>
                                <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 rounded-lg p-1">
                                  <button 
                                    onClick={() => {
                                      if (item.quantity > 1) {
                                        setBulkTransferItems(prev => prev.map((i, idx) => idx === index ? { ...i, quantity: i.quantity - 1 } : i));
                                      }
                                    }}
                                    className="w-6 h-6 flex items-center justify-center text-slate-500 hover:text-primary transition-colors disabled:opacity-30"
                                    disabled={item.quantity <= 1}
                                  >
                                    <Minus className="w-3.5 h-3.5" />
                                  </button>
                                  <input 
                                    type="number"
                                    value={item.quantity}
                                    onChange={(e) => {
                                      const val = parseInt(e.target.value) || 0;
                                      const finalVal = Math.min(Math.max(0, val), stock);
                                      setBulkTransferItems(prev => prev.map((i, idx) => idx === index ? { ...i, quantity: finalVal } : i));
                                    }}
                                    className="w-12 bg-transparent text-center text-xs font-black outline-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                                  />
                                  <button 
                                    onClick={() => {
                                      if (item.quantity < stock) {
                                        setBulkTransferItems(prev => prev.map((i, idx) => idx === index ? { ...i, quantity: i.quantity + 1 } : i));
                                      }
                                    }}
                                    className="w-6 h-6 flex items-center justify-center text-slate-500 hover:text-primary transition-colors disabled:opacity-30"
                                    disabled={item.quantity >= stock}
                                  >
                                    <Plus className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
      {activeTab === 'products' && (
        viewMode === 'table' ? (
          <div className="bg-secondary rounded-[2rem] shadow-sm border border-base overflow-hidden flex-1 flex flex-col min-h-[500px] w-full">
          <div className="overflow-x-auto overflow-y-auto flex-1 h-full custom-scrollbar w-full">
            <table className="w-full text-left border-collapse table-fixed min-w-[950px]">
              <thead>
                <tr className="bg-secondary border-b border-base sticky top-0 z-30 shadow-sm translate-y-[-1px]">
                  <th className="w-14 px-4 py-3 bg-secondary">
                    <input 
                      type="checkbox" 
                      className="rounded border-base text-indigo-600 focus:ring-indigo-500 bg-primary"
                      checked={selectedItems.length === inventoryView.length && inventoryView.length > 0}
                      onChange={(e) => {
                        if (e.target.checked) setSelectedItems(inventoryView.map(i => i.id));
                        else setSelectedItems([]);
                      }}
                    />
                  </th>
                  <th className="w-1/4 px-4 py-3 text-[9px] font-black text-muted uppercase tracking-widest bg-secondary">Producto / Cat</th>
                  <th className="w-36 px-4 py-3 text-[9px] font-black text-muted uppercase tracking-widest bg-secondary">SKU / CB</th>
                  <th className="w-28 px-4 py-3 text-[9px] font-black text-muted uppercase tracking-widest bg-secondary">Garantía</th>
                  <th className="w-36 px-4 py-3 text-[9px] font-black text-muted uppercase tracking-widest bg-secondary">Precio (CUP)</th>
                  <th className="w-40 px-4 py-3 text-[9px] font-black text-muted uppercase tracking-widest bg-secondary">Stock Actual</th>
                  <th className="w-28 px-4 py-3 text-[9px] font-black text-muted uppercase tracking-widest text-right bg-secondary">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-subtle">
                {inventoryView.map((item) => (
                  <tr key={item.id} className={cn(
                    "hover:bg-subtle/50 transition-colors group",
                    selectedItems.includes(item.id) && "bg-indigo-50/30 dark:bg-indigo-900/10"
                  )}>
                    <td className="px-4 py-3">
                      <input 
                        type="checkbox" 
                        checked={selectedItems.includes(item.id)}
                        onChange={() => {
                          setSelectedItems(prev => prev.includes(item.id) ? prev.filter(id => id !== item.id) : [...prev, item.id]);
                        }}
                        className="rounded border-base text-indigo-600 focus:ring-indigo-500 bg-primary"
                      />
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-subtle flex items-center justify-center overflow-hidden shrink-0 border border-base relative shadow-sm">
                          {item.image ? (
                            <img 
                              src={item.image} 
                              alt={item.name} 
                              className="w-full h-full object-cover" 
                              referrerPolicy="no-referrer" 
                              onError={(e) => {
                                e.currentTarget.onerror = null;
                                e.currentTarget.src = '';
                                e.currentTarget.style.display = 'none';
                              }}
                            />
                          ) : (
                            <div className={cn("w-full h-full opacity-20", item.color)} />
                          )}
                          {!item.image && (
                            <span className="absolute text-[10px] font-black text-muted uppercase">
                              {item.name.substring(0, 2)}
                            </span>
                          )}
                        </div>
                        <div className="flex flex-col min-w-0">
                          <div className="text-xs font-black text-primary uppercase tracking-tighter truncate flex items-center gap-1.5">
                            {item.name}
                            {item.isLowStock && (
                              <span title="Bajo Stock" className="inline-flex items-center">
                                <AlertCircle className="w-3 h-3 text-rose-500 shrink-0" />
                              </span>
                            )}
                          </div>
                          <span className="text-[9px] text-muted font-bold uppercase truncate">{categories.find(c => c.id === item.categoryId)?.name || 'General'}</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="text-[9px] font-mono font-black text-primary uppercase truncate">{item.sku}</div>
                      <div className="text-[7px] text-muted font-mono truncate">{item.barcode || '---'}</div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5">
                        <ShieldCheck className={cn("w-3 h-3", item.warrantyDays ? "text-emerald-500" : "text-slate-300 dark:text-slate-600")} />
                        <span className="text-[9px] font-bold text-secondary">
                          {item.warrantyDays ? `${item.warrantyDays}d` : '---'}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="text-[10px] font-black text-primary whitespace-nowrap">{formatMoney(item.price)}</div>
                      <div className="text-[8px] text-emerald-600 dark:text-emerald-400 font-black whitespace-nowrap">GAN: {formatMoney(item.margin)}</div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex flex-col gap-1">
                        <span className={cn(
                          "px-2 py-0.5 rounded-lg text-[9px] font-black inline-block w-fit whitespace-nowrap",
                          item.totalStock === 0 ? "bg-rose-100 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400" :
                          item.isLowStock ? "bg-amber-100 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400" : 
                          "bg-emerald-100 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400"
                        )}>
                          {item.totalStock} {item.unit || 'uds'}
                        </span>
                        {item.levels.filter(l => l.variantLabel).length > 0 && (
                          <div className="flex flex-wrap gap-1">
                            {item.levels.filter(l => l.variantLabel).slice(0, 3).map((lvl, idx) => (
                              <span key={idx} className="text-[8px] font-bold text-slate-400 uppercase bg-slate-50 px-1.5 py-0.5 rounded border border-slate-100">
                                {lvl.variantLabel}: {lvl.quantity}
                              </span>
                            ))}
                            {item.levels.filter(l => l.variantLabel).length > 3 && (
                              <span className="text-[7px] font-black text-slate-300 uppercase">+{item.levels.filter(l => l.variantLabel).length - 3}</span>
                            )}
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex justify-end gap-1.5">
                        <button 
                          onClick={() => {
                            const { totalStock, isLowStock, levels, ...productOnly } = item as any;
                            setManagingStockProduct(productOnly);
                          }}
                          className="text-muted hover:text-emerald-600 transition-colors p-1.5 rounded-xl hover:bg-emerald-50 dark:hover:bg-emerald-950/50 border border-base shadow-sm"
                          title="Gestionar Stock"
                        >
                          <PackagePlus className="w-3.5 h-3.5" />
                        </button>
                        <button 
                          onClick={() => {
                            const { totalStock, isLowStock, levels, ...productOnly } = item as any;
                            setEditingProduct(productOnly);
                            setFormData(productOnly);
                            setShowAddModal(true);
                          }}
                          className="text-muted hover:text-indigo-600 transition-colors p-1.5 rounded-xl hover:bg-indigo-50 dark:hover:bg-indigo-950/50 border border-base shadow-sm"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        <button 
                          onClick={() => window.confirm("¿Seguro que deseas eliminar este producto?") && deleteProduct(item.id)}
                          className="text-muted hover:text-rose-600 transition-colors p-1.5 rounded-xl hover:bg-rose-50 dark:hover:bg-rose-950/50 border border-base shadow-sm"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
            
            {inventoryData.full.length > displayLimit && (
              <div className="p-4 border-t border-base flex justify-center bg-secondary">
                <button 
                  onClick={() => setDisplayLimit(prev => prev + 200)}
                  className="px-6 py-2 bg-indigo-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-md active:scale-95"
                >
                  Cargar más productos ({inventoryData.full.length - displayLimit} restantes)
                </button>
              </div>
            )}

            {/* Table Footer / Batch Actions */}
            {selectedItems.length > 0 && (
              <div className="bg-indigo-600 p-4 flex items-center justify-between text-white animate-in slide-in-from-bottom-full duration-300">
                <div className="flex items-center gap-4">
                  <span className="text-sm font-bold">{selectedItems.length} seleccionados</span>
                  <div className="h-4 w-px bg-indigo-400" />
                  <button 
                    onClick={() => handleBatchUpdateStatus('active')}
                    className="text-xs font-black uppercase tracking-widest hover:text-indigo-200 transition-colors"
                  >
                    Marcar Activo
                  </button>
                  <button 
                    onClick={() => handleBatchUpdateStatus('discontinued')}
                    className="text-xs font-black uppercase tracking-widest hover:text-amber-200 transition-colors"
                  >
                    Descontinuar
                  </button>
                  <button 
                    onClick={() => setShowBatchPriceModal(true)}
                    className="text-xs font-black uppercase tracking-widest hover:text-emerald-200 transition-colors"
                  >
                    Ajustar Precios
                  </button>
                  <button 
                    onClick={handleBatchDelete}
                    className="text-xs font-black uppercase tracking-widest hover:text-rose-200 transition-colors"
                  >
                    Eliminar
                  </button>
                </div>
                <button onClick={() => setSelectedItems([])} className="text-xs font-black uppercase tracking-widest hover:text-indigo-200">Cancelar</button>
              </div>
            )}
          </div>
        ) : (
          <div className="flex-1 min-h-0 flex flex-col bg-secondary rounded-[2rem] border border-base shadow-sm overflow-hidden p-4">
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-8 gap-3 overflow-y-auto pr-2 flex-1 custom-scrollbar">
              {inventoryView.map((item) => (
                <div 
                  key={item.id} 
                  onClick={() => {
                    const { totalStock, isLowStock, levels, ...productOnly } = item as any;
                    setEditingProduct(productOnly);
                    setFormData(productOnly);
                    setShowAddModal(true);
                  }}
                  className="bg-primary p-2.5 rounded-2xl border border-base shadow-xs hover:shadow-md hover:border-indigo-300 transition-all cursor-pointer group flex flex-col gap-1.5 h-fit relative"
                >
                  <div className="flex justify-between items-start gap-1">
                    <h3 className="text-[10px] font-black text-primary uppercase tracking-tight line-clamp-2 leading-tight flex-1">{item.name}</h3>
                    <div className={cn(
                      "w-1.5 h-1.5 rounded-full shrink-0 mt-0.5",
                      item.totalStock === 0 ? "bg-rose-500 shadow-[0_0_5px_rgba(244,63,94,0.5)]" :
                      item.isLowStock ? "bg-amber-500" : "bg-emerald-500"
                    )} />
                  </div>
                  
                  <div className="flex items-center justify-between mt-auto">
                    <p className="text-[9px] font-black text-indigo-600">{formatMoney(item.price)}</p>
                    <p className={cn(
                      "text-[9px] font-black px-1.5 py-0.5 rounded-lg",
                      item.isLowStock ? "bg-rose-50/50 text-rose-600" : "bg-emerald-50/50 text-emerald-600"
                    )}>{item.totalStock}</p>
                  </div>

                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      const { totalStock, isLowStock, levels, ...productOnly } = item as any;
                      setManagingStockProduct(productOnly);
                    }}
                    className="absolute -top-1 -right-1 p-1 bg-white border border-base rounded-lg text-slate-400 hover:text-indigo-600 opacity-0 group-hover:opacity-100 transition-opacity shadow-sm"
                  >
                    <PackagePlus className="w-3 h-3" />
                  </button>
                </div>
              ))}
              
              {inventoryData.full.length > displayLimit && (
                <div className="col-span-full py-4 flex justify-center">
                  <button 
                    onClick={() => setDisplayLimit(prev => prev + 200)}
                    className="px-8 py-2.5 bg-indigo-600 text-white rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-md active:scale-95"
                  >
                    Ver más ({inventoryData.full.length - displayLimit} restantes)
                  </button>
                </div>
              )}
            </div>
          </div>
        )
      )}

      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-xs z-50 flex justify-center items-center p-2 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl sm:rounded-[2.5rem] w-full max-w-4xl max-h-[94vh] flex flex-col shadow-2xl animate-in zoom-in-95 duration-200 overflow-hidden border border-white/20 my-auto">
            <header className="p-4 sm:p-6 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-full -mr-32 -mt-32 blur-3xl"></div>
              <div className="relative z-10">
                <h2 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight uppercase">
                  {editingProduct ? 'Editar Producto' : 'Nuevo Producto'}
                </h2>
                <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">Ficha Técnica y Almacén</p>
              </div>
              <button 
                onClick={() => { setShowAddModal(false); setEditingProduct(null); setActiveFormTab('general'); }}
                className="p-2 hover:bg-slate-200 rounded-full transition-all active:scale-90 relative z-10"
              >
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </header>

            <nav className="px-4 sm:px-6 pt-1 bg-slate-50/50 flex gap-3 sm:gap-6 border-b border-slate-100 overflow-x-auto">
              {[
                { id: 'general', label: 'Datos Generales', icon: Tag },
                { id: 'stock', label: 'Inventario y Stock', icon: Package },
                { id: 'extra', label: 'Precios y Extras', icon: DollarSign },
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveFormTab(tab.id as any)}
                  className={cn(
                    "flex items-center gap-1.5 py-3 px-1 text-[9px] sm:text-[10px] font-black uppercase tracking-wider transition-all relative whitespace-nowrap",
                    activeFormTab === tab.id ? "text-indigo-600" : "text-slate-400 hover:text-slate-600"
                  )}
                >
                  <tab.icon className={cn("w-3.5 h-3.5", activeFormTab === tab.id ? "text-indigo-600" : "text-slate-400")} />
                  {tab.label}
                  {activeFormTab === tab.id && (
                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-600 rounded-full" />
                  )}
                </button>
              ))}
            </nav>

            <form onSubmit={handleAddSubmit} className="flex-1 overflow-hidden flex flex-col">
              <div className="flex-1 overflow-y-auto p-4 sm:p-6 custom-scrollbar">
                {activeFormTab === 'general' && (
                  <div className="space-y-8">
                    <div className="grid grid-cols-1 md:grid-cols-[200px_1fr] gap-8">
                      <div className="space-y-3">
                        <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1 text-center">Imagen de Producto</label>
                        <div className="relative group w-full aspect-square bg-slate-50 rounded-[2rem] border-2 border-dashed border-slate-200 flex items-center justify-center overflow-hidden hover:border-indigo-300 transition-all">
                          {formData.image ? (
                            <img src={formData.image} alt="Product" className="w-full h-full object-cover" />
                          ) : (
                            <div className="flex flex-col items-center gap-2">
                              <Plus className="w-8 h-8 text-slate-300" />
                              <span className="text-[8px] font-black text-slate-400 uppercase">Subir Foto</span>
                            </div>
                          )}
                          <input type="file" accept="image/*" onChange={handleImageChange} className="absolute inset-0 opacity-0 cursor-pointer" />
                        </div>
                      </div>

                      <div className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-1.5">
                            <label className="block text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Nombre Comercial</label>
                            <input 
                              type="text" required value={formData.name || ''} 
                              onChange={e => setFormData({...formData, name: e.target.value})} 
                              className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-indigo-500/20 outline-none text-sm font-bold transition-all" 
                              placeholder="Ej: iPhone 15 Pro Max" 
                            />
                          </div>
                          <div className="space-y-1.5">
                            <label className="block text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Categoría</label>
                            <select 
                              required value={formData.categoryId || ''} 
                              onChange={e => setFormData({...formData, categoryId: e.target.value})} 
                              className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-indigo-500/20 outline-none text-sm font-bold uppercase transition-all"
                            >
                              <option value="">Seleccione...</option>
                              {(categories || []).map(c => <option key={c.id} value={c.id}>{c.department} - {c.name}</option>)}
                            </select>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-1.5">
                            <label className="block text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">SKU (Código Interno)</label>
                            <div className="flex gap-2">
                              <input 
                                type="text" required value={formData.sku || ''} 
                                onChange={e => setFormData({...formData, sku: e.target.value})} 
                                className="flex-1 px-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-indigo-500/20 outline-none text-sm font-mono font-bold uppercase transition-all" 
                                placeholder="AUTOGENERAR ->"
                              />
                              <button type="button" onClick={() => setFormData({...formData, sku: `SKU-${Math.floor(Math.random() * 100000).toString().padStart(5, '0')}`})} className="px-4 py-3 bg-slate-200 text-slate-600 rounded-2xl hover:bg-slate-300 transition-colors">
                                <Settings2 className="w-5 h-5" />
                              </button>
                            </div>
                          </div>
                          <div className="space-y-1.5">
                            <label className="block text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Código de Barras</label>
                            <div className="flex gap-2">
                              <input 
                                type="text" value={formData.barcode || ''} 
                                onChange={e => setFormData({...formData, barcode: e.target.value})} 
                                className="flex-1 px-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-indigo-500/20 outline-none text-sm font-mono font-bold transition-all" 
                                placeholder="EAN-13 / UPC" 
                              />
                              <button type="button" onClick={() => setFormData({...formData, barcode: `750${Math.floor(Math.random() * 100000000).toString().padStart(8, '0')}`})} className="px-4 py-3 bg-slate-200 text-slate-600 rounded-2xl hover:bg-slate-300 transition-colors">
                                <List className="w-5 h-5" />
                              </button>
                            </div>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-1.5">
                            <label className="block text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Unidad</label>
                            <select value={formData.unit || 'unidad'} onChange={e => setFormData({...formData, unit: e.target.value})} className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold uppercase outline-none focus:ring-2 focus:ring-indigo-500/20">
                              <option value="unidad">Unidad</option>
                              <option value="kg">Kilo</option>
                              <option value="m">Metro</option>
                              <option value="par">Par</option>
                            </select>
                          </div>
                          <div className="space-y-1.5">
                            <label className="block text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Estado</label>
                            <select value={formData.status || 'active'} onChange={e => setFormData({...formData, status: e.target.value as any})} className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold uppercase outline-none focus:ring-2 focus:ring-indigo-500/20">
                              <option value="active">Activo</option>
                              <option value="draft">Borrador</option>
                              <option value="discontinued">Descontinuado</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeFormTab === 'stock' && (
                  <div className="space-y-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="space-y-6">
                        <div className="bg-slate-50 p-6 rounded-[2rem] border border-slate-100 space-y-4">
                          <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
                            <ShieldCheck className="w-4 h-4 text-indigo-500" />
                            Seguimiento Avanzado
                          </h3>
                          <div className="space-y-3">
                            <label className="flex items-center gap-3 p-3 bg-white rounded-2xl border border-slate-200 cursor-pointer hover:border-indigo-300 transition-all">
                              <input type="checkbox" checked={formData.hasSerial || false} onChange={e => setFormData({...formData, hasSerial: e.target.checked})} className="w-5 h-5 text-indigo-600 rounded-lg" />
                              <div className="flex-1">
                                <p className="text-[10px] font-black text-slate-900 uppercase">Rastrear por Serial / IMEI</p>
                                <p className="text-[8px] font-bold text-slate-400 uppercase">Obligatorio para equipos electrónicos</p>
                              </div>
                            </label>
                            <label className="flex items-center gap-3 p-3 bg-white rounded-2xl border border-slate-200 cursor-pointer hover:border-indigo-300 transition-all">
                              <input type="checkbox" checked={formData.isKit || false} onChange={e => setFormData({...formData, isKit: e.target.checked})} className="w-5 h-5 text-indigo-600 rounded-lg" />
                              <div className="flex-1">
                                <p className="text-[10px] font-black text-slate-900 uppercase">Combo / Kit de Productos</p>
                                <p className="text-[8px] font-bold text-slate-400 uppercase">Agrupa varios productos en uno</p>
                              </div>
                            </label>
                          </div>
                        </div>

                        {formData.isKit && (
                          <div className="bg-indigo-50/50 p-6 rounded-[2rem] border border-indigo-100 space-y-4">
                            <div className="flex justify-between items-center">
                              <h4 className="text-[10px] font-black text-indigo-900 uppercase tracking-widest">Componentes</h4>
                              <button type="button" onClick={() => setShowKitPicker(true)} className="px-3 py-1.5 bg-indigo-600 text-white rounded-xl text-[8px] font-black uppercase">Agregar</button>
                            </div>
                            <div className="space-y-2">
                              {(formData.kitComponents || []).map((comp, idx) => (
                                <div key={idx} className="flex items-center justify-between bg-white p-3 rounded-xl border border-indigo-100">
                                  <span className="text-[10px] font-bold text-slate-600 uppercase truncate pr-2">
                                    {products.find(p => p.id === comp.productId)?.name}
                                  </span>
                                  <div className="flex items-center gap-2">
                                    <input type="number" value={comp.quantity} onChange={e => {
                                      const newComps = [...(formData.kitComponents || [])];
                                      newComps[idx].quantity = parseInt(e.target.value) || 1;
                                      setFormData({...formData, kitComponents: newComps});
                                    }} className="w-12 py-1 border-slate-100 rounded text-center text-xs font-black" />
                                    <button type="button" onClick={() => setFormData({...formData, kitComponents: (formData.kitComponents || []).filter((_, i) => i !== idx)})} className="p-1 text-rose-500 hover:bg-rose-50 rounded-lg"><Trash2 className="w-4 h-4" /></button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="space-y-6">
                        <div className="bg-slate-50 p-6 rounded-[2rem] border border-slate-100 space-y-4">
                          <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
                            <Plus className="w-4 h-4 text-emerald-500" />
                            Variantes (Tallas / Colores)
                          </h3>
                          <div className="space-y-4">
                            <div className="space-y-2">
                              <label className="text-[9px] font-black text-slate-500 uppercase ml-1">Tallas / Números</label>
                              <div className="flex gap-2">
                                <input type="text" value={newSize} onChange={e => setNewSize(e.target.value)} className="flex-1 px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold outline-none" placeholder="Ej: L o 42" />
                                <button type="button" onClick={() => { if(newSize) { setFormData({...formData, availableSizes: [...(formData.availableSizes || []), newSize]}); setNewSize(""); } }} className="px-3 bg-slate-900 text-white rounded-xl">+</button>
                              </div>
                              <div className="flex flex-wrap gap-1.5">
                                {(formData.availableSizes || []).map(size => (
                                  <span key={size} className="px-2 py-1 bg-indigo-100 text-indigo-700 rounded-lg text-[9px] font-black flex items-center gap-1 uppercase">
                                    {size}
                                    <button type="button" onClick={() => setFormData({...formData, availableSizes: (formData.availableSizes || []).filter(s => s !== size)})}><X className="w-3 h-3" /></button>
                                  </span>
                                ))}
                              </div>
                            </div>
                            <div className="space-y-2">
                              <label className="text-[9px] font-black text-slate-500 uppercase ml-1">Colores / Otros</label>
                              <div className="flex gap-2">
                                <input type="text" value={newColor} onChange={e => setNewColor(e.target.value)} className="flex-1 px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold outline-none" placeholder="Ej: Azul" />
                                <button type="button" onClick={() => { if(newColor) { setFormData({...formData, availableColors: [...(formData.availableColors || []), newColor]}); setNewColor(""); } }} className="px-3 bg-slate-900 text-white rounded-xl">+</button>
                              </div>
                              <div className="flex flex-wrap gap-1.5">
                                {(formData.availableColors || []).map(color => (
                                  <span key={color} className="px-2 py-1 bg-emerald-100 text-emerald-700 rounded-lg text-[9px] font-black flex items-center gap-1 uppercase">
                                    {color}
                                    <button type="button" onClick={() => setFormData({...formData, availableColors: (formData.availableColors || []).filter(c => c !== color)})}><X className="w-3 h-3" /></button>
                                  </span>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>

                        {!editingProduct && (
                          <div className="bg-emerald-50/50 p-6 rounded-[2rem] border border-emerald-100 space-y-4">
                            <h3 className="text-xs font-black text-emerald-900 uppercase tracking-widest flex items-center gap-2">
                              <TrendingUp className="w-4 h-4 text-emerald-500" />
                              Stock Inicial
                            </h3>
                            <div className="space-y-3">
                              <select 
                                value={formData.initialBranchId || (branches?.[0]?.id || '')} 
                                onChange={e => setFormData({...formData, initialBranchId: e.target.value})}
                                className="w-full px-4 py-3 bg-white border border-emerald-100 rounded-2xl text-xs font-bold uppercase outline-none focus:ring-2 focus:ring-emerald-500/20"
                              >
                                {(branches || []).map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                              </select>
                              {((formData.availableSizes || []).length > 0 || (formData.availableColors || []).length > 0) ? (
                                <div className="space-y-2 max-h-32 overflow-y-auto pr-1 custom-scrollbar">
                                  {Array.from(new Set([...(formData.availableSizes || []), ...(formData.availableColors || [])])).map(variant => (
                                    <div key={variant} className="flex items-center justify-between bg-white p-2.5 rounded-xl border border-emerald-100">
                                      <span className="text-[10px] font-black text-slate-700 uppercase">{variant}</span>
                                      <input 
                                        type="number" min="0" 
                                        value={formData.initialVariantQuantities?.[variant] || ''} 
                                        onFocus={(e) => e.target.select()}
                                        onChange={e => setFormData({...formData, initialVariantQuantities: {...(formData.initialVariantQuantities || {}), [variant]: parseInt(e.target.value) || 0}})}
                                        className="w-16 px-2 py-1 bg-slate-50 rounded-lg text-center text-xs font-bold outline-none" 
                                        placeholder="0"
                                      />
                                    </div>
                                  ))}
                                </div>
                              ) : (
                                <input 
                                  type="number" min="0" 
                                  value={formData.initialQuantity === 0 ? '' : (formData.initialQuantity || '')} 
                                  onFocus={(e) => e.target.select()}
                                  onChange={e => setFormData({...formData, initialQuantity: e.target.value === '' ? 0 : (parseInt(e.target.value) || 0)})} 
                                  className="w-full px-4 py-3 bg-white border border-emerald-100 rounded-2xl text-xs font-bold outline-none focus:ring-2 focus:ring-emerald-500/20" 
                                  placeholder="0" 
                                />
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {activeFormTab === 'extra' && (
                  <div className="space-y-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="bg-slate-50 p-8 rounded-[2.5rem] border border-slate-100 space-y-6">
                        <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
                          <DollarSign className="w-5 h-5 text-indigo-500" />
                          Configuración Económica
                        </h3>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-1.5">
                            <label className="block text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Costo de Compra (CUP)</label>
                            <input 
                              type="number" 
                              required 
                              value={formData.costPrice === 0 ? '' : (formData.costPrice ?? '')} 
                              placeholder="0.00"
                              onFocus={(e) => e.target.select()}
                              onChange={e => handleCostPriceChange(e.target.value === '' ? 0 : (parseFloat(e.target.value) || 0), formData.price || 0)} 
                              className="w-full px-4 py-3 bg-white border border-slate-200 rounded-2xl text-sm font-black outline-none focus:ring-2 focus:ring-indigo-500/20" 
                            />
                          </div>
                          <div className="space-y-1.5">
                            <label className="block text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Precio de Venta (CUP)</label>
                            <input 
                              type="number" 
                              required 
                              value={formData.price === 0 ? '' : (formData.price ?? '')} 
                              placeholder="0.00"
                              onFocus={(e) => e.target.select()}
                              onChange={e => handleCostPriceChange(formData.costPrice || 0, e.target.value === '' ? 0 : (parseFloat(e.target.value) || 0))} 
                              className="w-full px-4 py-3 bg-indigo-50 border border-indigo-200 rounded-2xl text-sm font-black text-indigo-700 outline-none focus:ring-2 focus:ring-indigo-500/20" 
                            />
                          </div>
                        </div>

                        <div className="bg-emerald-50 p-4 rounded-2xl flex items-center justify-between">
                          <div>
                            <p className="text-[9px] font-black text-emerald-600 uppercase">Margen de Utilidad</p>
                            <p className="text-xl font-black text-emerald-700">CUP {formData.margin?.toLocaleString()}</p>
                          </div>
                          <TrendingUp className="w-8 h-8 text-emerald-200" />
                        </div>

                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between">
                            <label className="block text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Comisión Vendedor (CUP Fijo)</label>
                            <InfoTooltip text="Monto fijo en CUP que recibe el vendedor por cada unidad vendida de este producto." />
                          </div>
                          <input 
                            type="number" 
                            min="0" 
                            value={formData.commissionValue === 0 ? '' : (formData.commissionValue ?? '')} 
                            placeholder="0.00"
                            onFocus={(e) => e.target.select()}
                            onChange={e => setFormData({...formData, commissionValue: e.target.value === '' ? 0 : (parseFloat(e.target.value) || 0)})} 
                            className="w-full px-4 py-3 bg-white border border-slate-200 rounded-2xl text-sm font-black outline-none focus:ring-2 focus:ring-indigo-500/20" 
                          />
                        </div>
                      </div>

                      <div className="bg-slate-50 p-8 rounded-[2.5rem] border border-slate-100 space-y-6">
                        <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
                          <ShieldCheck className="w-5 h-5 text-indigo-500" />
                          Garantía y Alertas
                        </h3>
                        <div className="space-y-4">
                          <div className="space-y-1.5">
                            <label className="block text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Días de Garantía</label>
                            <input 
                              type="number" 
                              min="0" 
                              value={formData.warrantyDays === 0 ? '' : (formData.warrantyDays ?? '')} 
                              placeholder="0 = Sin garantía"
                              onFocus={(e) => e.target.select()}
                              onChange={e => setFormData({...formData, warrantyDays: e.target.value === '' ? 0 : (parseInt(e.target.value) || 0)})} 
                              className="w-full px-4 py-3 bg-white border border-slate-200 rounded-2xl text-sm font-black outline-none" 
                            />
                          </div>
                          <div className="space-y-1.5">
                            <label className="block text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Stock Mínimo para Alertas</label>
                            <input 
                              type="number" 
                              min="0" 
                              value={formData.minStockAlert === 0 ? '' : (formData.minStockAlert ?? '')} 
                              placeholder="5"
                              onFocus={(e) => e.target.select()}
                              onChange={e => setFormData({...formData, minStockAlert: e.target.value === '' ? 0 : (parseInt(e.target.value) || 0)})} 
                              className="w-full px-4 py-3 bg-white border border-slate-200 rounded-2xl text-sm font-black outline-none" 
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <footer className="p-4 sm:p-6 border-t border-slate-100 bg-slate-50/50 flex items-center justify-end gap-3">
                <button 
                  type="button" 
                  onClick={() => { setShowAddModal(false); setEditingProduct(null); setActiveFormTab('general'); }} 
                  className="px-4 py-2.5 text-[9px] sm:text-[10px] font-black uppercase tracking-wider text-slate-400 hover:text-slate-600 transition-colors"
                >
                  Descartar
                </button>
                <button 
                  type="submit" 
                  className="px-6 py-3 bg-indigo-600 text-white rounded-xl text-[10px] font-black uppercase tracking-wider shadow-lg shadow-indigo-200 hover:bg-indigo-700 active:scale-95 transition-all"
                >
                  {editingProduct ? 'Guardar Cambios' : 'Registrar Producto'}
                </button>
              </footer>
            </form>
          </div>
        </div>
      )}

      {/* Modal Nueva Categoría */}
      {/* (Categoría funcionalidad eliminada) */}

      {managingStockProduct && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-sm z-50 flex justify-center items-center p-3 sm:p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-2xl flex flex-col shadow-2xl border border-slate-200 dark:border-slate-800 animate-in zoom-in-95 duration-200 overflow-hidden max-h-[90vh]">
            <div className="flex justify-between items-center px-4 py-3 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-600 flex items-center justify-center shrink-0">
                  <PackagePlus className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-sm font-black text-slate-900 dark:text-slate-100 uppercase tracking-tight">Gestionar Stock</h2>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium truncate max-w-[280px] sm:max-w-md">{managingStockProduct.name}</p>
                </div>
              </div>
              <button 
                onClick={() => setManagingStockProduct(null)} 
                className="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            
            <div className="p-4 overflow-y-auto custom-scrollbar flex-1 bg-white dark:bg-slate-900">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {branches.map(branch => {
                  const productVariants = [
                    undefined, 
                    ...(managingStockProduct.availableSizes || []), 
                    ...(managingStockProduct.availableColors || [])
                  ];

                  // Calculate total in this branch
                  const totalInBranch = productVariants.reduce((sum, v) => {
                    const lev = inventory.find(i => 
                      i.productId === managingStockProduct.id && 
                      i.branchId === branch.id && 
                      (i.variantLabel || '') === (v || '')
                    );
                    return sum + (lev?.quantity || 0);
                  }, 0);

                  return (
                    <div key={branch.id} className="bg-slate-50 dark:bg-slate-800/50 p-3 rounded-xl border border-slate-200 dark:border-slate-700/60 space-y-2.5 flex flex-col justify-between">
                      <div className="flex items-center justify-between gap-2 pb-1.5 border-b border-slate-200 dark:border-slate-700/60">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <Building2 className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                          <p className="text-xs font-black text-slate-900 dark:text-slate-100 uppercase tracking-tight truncate">{branch.name}</p>
                        </div>
                        <span className="text-[10px] font-black px-2 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 shrink-0 border border-indigo-200/50 dark:border-indigo-800/50">
                          {totalInBranch} uds
                        </span>
                      </div>
                      
                      <div className="space-y-1.5 flex-1">
                        {productVariants.map(variant => {
                          const level = inventory.find(i => 
                            i.productId === managingStockProduct.id && 
                            i.branchId === branch.id && 
                            (i.variantLabel || '') === (variant || '')
                          ) || { quantity: 0, minQuantity: 5 };

                          return (
                            <div key={variant || 'base'} className="flex items-center justify-between gap-2 bg-white dark:bg-slate-800/90 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 shadow-2xs">
                              <div className="min-w-0 flex-1">
                                <p className="text-[10px] font-bold text-slate-800 dark:text-slate-200 truncate">
                                  {variant ? variant : 'Stock Base'}
                                </p>
                                <div className="flex items-center gap-1 mt-0.5">
                                  <label className="text-[8px] font-semibold text-slate-400 uppercase">Mín:</label>
                                  <input 
                                    type="number" 
                                    min="0"
                                    value={level.minQuantity === 0 ? '' : level.minQuantity} 
                                    placeholder="0"
                                    onFocus={(e) => e.target.select()}
                                    onChange={(e) => setInventoryQuantity(managingStockProduct.id, branch.id, level.quantity, variant, e.target.value === '' ? 0 : (parseInt(e.target.value) || 0))}
                                    className="w-10 px-1 py-0.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded text-[9px] text-slate-900 dark:text-slate-100 outline-none focus:ring-1 focus:ring-indigo-500 text-center font-bold"
                                  />
                                </div>
                              </div>
                              <div className="flex items-center gap-1 shrink-0">
                                <span className="text-[9px] font-semibold text-slate-400 uppercase">Cant:</span>
                                <input 
                                    type="number" 
                                    min="0"
                                    value={level.quantity === 0 ? '' : level.quantity} 
                                    placeholder="0"
                                    onFocus={(e) => e.target.select()}
                                    onChange={(e) => setInventoryQuantity(managingStockProduct.id, branch.id, e.target.value === '' ? 0 : (parseInt(e.target.value) || 0), variant, level.minQuantity)}
                                    className="w-16 px-2 py-1 bg-white dark:bg-slate-900 border border-indigo-400 dark:border-indigo-600 rounded-lg font-black text-indigo-600 dark:text-indigo-400 text-right outline-none text-xs focus:ring-2 focus:ring-indigo-500 shadow-2xs"
                                />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
            
            <div className="px-4 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between gap-3">
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                Almacenes: <strong className="text-slate-900 dark:text-slate-100 font-bold">{branches.length}</strong>
              </span>
              <button 
                onClick={() => setManagingStockProduct(null)} 
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs transition-colors shadow-sm active:scale-95"
              >
                Cerrar y Guardar
              </button>
            </div>
          </div>
        </div>
      )}

      {showBatchPriceModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex justify-center items-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl animate-in zoom-in-95 duration-200 overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <h3 className="text-lg font-black text-slate-900 uppercase tracking-tight">Ajuste de Precios Masivo</h3>
              <button onClick={() => setShowBatchPriceModal(false)} className="p-2 hover:bg-slate-200 rounded-full transition-colors"><X className="w-5 h-5 text-slate-400" /></button>
            </div>
            <div className="p-6 space-y-4">
              <p className="text-xs text-slate-500 font-bold uppercase tracking-widest text-center mb-4">Afectando a {selectedItems.length} productos</p>
              
              <div className="grid grid-cols-2 gap-2">
                <button 
                  onClick={() => setBatchPriceAdjust({...batchPriceAdjust, direction: 'increase'})}
                  className={cn("py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all", batchPriceAdjust.direction === 'increase' ? "bg-emerald-100 text-emerald-700 ring-2 ring-emerald-500/20" : "bg-slate-50 text-slate-400 hover:bg-slate-100")}
                >Incrementar</button>
                <button 
                  onClick={() => setBatchPriceAdjust({...batchPriceAdjust, direction: 'decrease'})}
                  className={cn("py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all", batchPriceAdjust.direction === 'decrease' ? "bg-rose-100 text-rose-700 ring-2 ring-rose-500/20" : "bg-slate-50 text-slate-400 hover:bg-slate-100")}
                >Decrementar</button>
              </div>

              <div className="flex gap-2">
                <select 
                  value={batchPriceAdjust.type}
                  onChange={(e) => setBatchPriceAdjust({...batchPriceAdjust, type: e.target.value as any})}
                  className="flex-1 px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-xs font-black uppercase outline-none"
                >
                  <option value="percentage">Porcentaje (%)</option>
                  <option value="fixed">Monto Fijo (CUP)</option>
                </select>
                <input 
                  type="number" 
                  value={batchPriceAdjust.value || ''}
                  onFocus={(e) => e.target.select()}
                  onChange={(e) => setBatchPriceAdjust({...batchPriceAdjust, value: parseFloat(e.target.value) || 0})}
                  className="w-32 px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-xs font-black outline-none focus:ring-2 focus:ring-indigo-500/20"
                  placeholder="0.00"
                />
              </div>

              <button 
                onClick={handleBatchPriceApply}
                className="w-full py-4 bg-indigo-600 text-white font-black uppercase tracking-widest text-xs rounded-2xl hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 active:scale-[0.98] mt-4"
              >Aplicar Cambios</button>
            </div>
          </div>
        </div>
      )}

      {/* Kit Component Picker Modal */}
      {showKitPicker && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[60] flex justify-center items-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl animate-in zoom-in-95 duration-200 overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <h3 className="text-sm font-black text-slate-900 uppercase tracking-tight">Seleccionar Componente</h3>
              <button onClick={() => setShowKitPicker(false)} className="p-1.5 hover:bg-slate-200 rounded-full transition-colors"><X className="w-4 h-4 text-slate-400" /></button>
            </div>
            <div className="p-4 space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Buscar producto..." 
                  value={kitQuery}
                  onChange={e => setKitQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-100 rounded-2xl text-sm outline-none"
                />
              </div>
              <div className="max-h-60 overflow-y-auto space-y-2 px-1 custom-scrollbar">
                {products
                  .filter(p => !p.isKit && (p.name.toLowerCase().includes(kitQuery.toLowerCase()) || p.sku.toLowerCase().includes(kitQuery.toLowerCase())))
                  .slice(0, 10)
                  .map(p => (
                    <button 
                      key={p.id}
                      type="button"
                      onClick={() => {
                        const existing = (formData.kitComponents || []).find(c => c.productId === p.id);
                        if (!existing) {
                          setFormData({
                            ...formData, 
                            kitComponents: [...(formData.kitComponents || []), { productId: p.id, quantity: 1 }]
                          });
                        }
                        setShowKitPicker(false);
                      }}
                      className="w-full flex items-center justify-between p-3 bg-white hover:bg-indigo-50 border border-slate-100 rounded-2xl transition-all"
                    >
                      <div className="text-left">
                        <p className="text-[10px] font-black text-slate-900 uppercase">{p.name}</p>
                        <p className="text-[8px] font-bold text-slate-400 uppercase tracking-tight">{p.sku}</p>
                      </div>
                      <Plus className="w-4 h-4 text-indigo-400" />
                    </button>
                  ))}
              </div>
            </div>
          </div>
        </div>
      )}
      {/* Modal Categorías */}
      {showCategoryModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[60] flex justify-center items-center p-4">
          <div className="bg-white rounded-[2rem] w-full max-w-xl max-h-[85vh] flex flex-col shadow-2xl animate-in zoom-in-95 duration-200 overflow-hidden">
            <div className="flex justify-between items-center p-6 border-b border-slate-100 bg-slate-50/50">
              <div>
                <h2 className="text-lg font-black text-slate-900 tracking-tight uppercase">Gestionar Categorías</h2>
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Organización del catálogo</p>
              </div>
              <button onClick={() => setShowCategoryModal(false)} className="p-1.5 hover:bg-slate-200 rounded-full transition-colors">
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              <form onSubmit={handleCategorySubmit} className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[8px] font-black text-slate-400 uppercase mb-1 ml-1">Nombre</label>
                    <input 
                      required
                      type="text" 
                      value={categoryFormData.name}
                      onChange={e => setCategoryFormData({...categoryFormData, name: e.target.value})}
                      className="w-full px-3 py-2 bg-white border border-slate-100 rounded-xl text-xs font-bold outline-none focus:ring-1 focus:ring-indigo-100"
                      placeholder="Ej: Smartphones"
                    />
                  </div>
                  <div>
                    <label className="block text-[8px] font-black text-slate-400 uppercase mb-1 ml-1">Departamento</label>
                    <input 
                      required
                      type="text" 
                      value={categoryFormData.department}
                      onChange={e => setCategoryFormData({...categoryFormData, department: e.target.value})}
                      className="w-full px-3 py-2 bg-white border border-slate-100 rounded-xl text-xs font-bold outline-none focus:ring-1 focus:ring-indigo-100"
                      placeholder="Ej: Electrónica"
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  {editingCategory && (
                    <button 
                      type="button"
                      onClick={() => {
                        setEditingCategory(null);
                        setCategoryFormData({ name: "", department: "" });
                      }}
                      className="px-4 py-2 text-[10px] font-black uppercase text-slate-400"
                    >
                      Cancelar
                    </button>
                  )}
                  <button 
                    type="submit"
                    className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-indigo-100"
                  >
                    {editingCategory ? 'Actualizar' : 'Agregar'}
                  </button>
                </div>
              </form>

              <div className="space-y-2">
                <h3 className="text-[10px] font-black text-slate-900 uppercase tracking-widest px-1">Existentes</h3>
                <div className="grid grid-cols-1 gap-2">
                  {categories.map(cat => (
                    <div key={cat.id} className="flex items-center justify-between p-3 bg-white border border-slate-100 rounded-2xl group hover:border-indigo-100 transition-all">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
                          <Tag className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-[10px] font-black text-slate-900 uppercase tracking-tighter">{cat.name}</p>
                          <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">{cat.department}</p>
                        </div>
                      </div>
                      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button 
                          onClick={() => {
                            setEditingCategory(cat);
                            setCategoryFormData({ name: cat.name, department: cat.department });
                          }}
                          className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        <button 
                          onClick={() => window.confirm("¿Eliminar categoría?") && deleteCategory(cat.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
