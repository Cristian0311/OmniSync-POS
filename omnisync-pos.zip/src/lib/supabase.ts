import { createClient, SupabaseClient } from '@supabase/supabase-js';

const STORAGE_URL_KEY = 'mare_supabase_url';
const STORAGE_ANON_KEY = 'mare_supabase_anon_key';

export function getSupabaseCredentials() {
  const envUrl = import.meta.env.VITE_SUPABASE_URL || '';
  const envKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

  const storedUrl = localStorage.getItem(STORAGE_URL_KEY) || '';
  const storedKey = localStorage.getItem(STORAGE_ANON_KEY) || '';

  const url = storedUrl || envUrl;
  const anonKey = storedKey || envKey;

  return { url, anonKey, isConfigured: Boolean(url && anonKey) };
}

export function saveSupabaseCredentials(url: string, anonKey: string) {
  if (url) localStorage.setItem(STORAGE_URL_KEY, url.trim());
  else localStorage.removeItem(STORAGE_URL_KEY);

  if (anonKey) localStorage.setItem(STORAGE_ANON_KEY, anonKey.trim());
  else localStorage.removeItem(STORAGE_ANON_KEY);

  cachedClient = null; // Reset cache so new client is instantiated
}

let cachedClient: SupabaseClient | null = null;

export function getSupabase(): SupabaseClient | null {
  const { url, anonKey, isConfigured } = getSupabaseCredentials();

  if (!isConfigured) {
    return null;
  }

  if (!cachedClient) {
    try {
      cachedClient = createClient(url, anonKey, {
        auth: {
          persistSession: false,
          autoRefreshToken: false,
        }
      });
    } catch (e) {
      console.error("Error inicializando cliente de Supabase:", e);
      return null;
    }
  }

  return cachedClient;
}

export async function testSupabaseConnection(url?: string, anonKey?: string): Promise<{ success: boolean; message: string; tableCount?: number }> {
  try {
    const targetUrl = url || getSupabaseCredentials().url;
    const targetKey = anonKey || getSupabaseCredentials().anonKey;

    if (!targetUrl || !targetKey) {
      return { success: false, message: "URL o Clave Anon de Supabase no configuradas." };
    }

    const client = createClient(targetUrl, targetKey);
    // Test query on products table or branches
    const { data: prodData, error: prodErr } = await client.from('products').select('id').limit(1);

    if (prodErr) {
      // Check if branches table works
      const { data: branchData, error: branchErr } = await client.from('branches').select('id').limit(1);
      if (branchErr) {
        return { success: false, message: `Error de conexión: ${prodErr.message || branchErr.message}` };
      }
    }

    return { success: true, message: "¡Conexión con Supabase establecida exitosamente!" };
  } catch (err: any) {
    return { success: false, message: err?.message || "No se pudo conectar con Supabase." };
  }
}
