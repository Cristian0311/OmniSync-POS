/**
 * Offline-first operation queue.
 *
 * IMPORTANT: this queue stores operations, not a copy of the whole application
 * state. IndexedDB is used because POS devices can remain offline for long
 * periods and localStorage is too fragile for a growing transactional queue.
 */
import { getSupabase } from '../lib/supabase';
import { useStore } from '../store/useStore';
import {
  Transaction, CashRegisterSession,
  Customer, ReturnItem, Branch, Product, Category
} from '../types';
import {
  callOpenSessionRPC, callOpenSessionRPCWithId, callProcessTransactionRPC, callVoidTransactionRPC, callCancelSessionRPC,
  callCompleteReturnRPC, callTransferInventoryRPC, callReceiveSupplierOrderRPC,
  callCompleteInventoryAuditRPC
} from './supabaseSync';
import { addSyncLog } from '../utils/syncLogger';

export type OfflineActionType =
  | 'transaction' | 'void_transaction' | 'return_complete' | 'transfer'
  | 'supplier_receive' | 'audit_complete' | 'cash_session' | 'inventory' | 'inventory_adjustment' | 'inventory_reconcile'
  | 'customer' | 'customer_delete' | 'return' | 'bank_transaction'
  | 'branch' | 'product' | 'category' | 'receipt_config' | 'store_config' | 'catalog_config' | 'salary_settlement'
  | 'user' | 'currency' | 'idn_settlement_price' | 'warranty' | 'time_shift' | 'quote'
  | 'bank_card' | 'supplier' | 'supplier_order' | 'inventory_audit';

export interface OfflineQueueItem {
  id: string;
  actionId: string;
  type: OfflineActionType;
  data: any;
  timestamp: string;
  retryCount: number;
  status?: 'pending' | 'processing' | 'failed' | 'conflict';
  lastError?: string;
  deviceId?: string;
}

const STORAGE_KEY = 'pos_offline_sync_queue';
const DB_NAME = 'omnisync-pos-offline';
const DB_VERSION = 1;
const STORE_NAME = 'operations';
const DEVICE_KEY = 'omnisync_device_id';

let isProcessingQueue = false;
let memoryQueue: OfflineQueueItem[] = [];
let queueReady = false;
let persistenceChain: Promise<void> = Promise.resolve();
let persistenceError: Error | null = null;
let queueInitPromise: Promise<void>;
let removedDuringQueueProcess = new Set<string>();

class PermanentSyncError extends Error {
  permanent = true;
}

function getDeviceId(): string {
  if (typeof window === 'undefined') return 'server';
  const existing = localStorage.getItem(DEVICE_KEY);
  if (existing) return existing;
  const id = crypto.randomUUID();
  localStorage.setItem(DEVICE_KEY, id);
  return id;
}

function openDb(): Promise<IDBDatabase | null> {
  if (typeof indexedDB === 'undefined') return Promise.resolve(null);
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        store.createIndex('status', 'status', { unique: false });
        store.createIndex('action', ['type', 'actionId'], { unique: true });
        store.createIndex('timestamp', 'timestamp', { unique: false });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('IndexedDB open failed'));
  });
}

async function idbGetAll(): Promise<OfflineQueueItem[] | null> {
  const db = await openDb();
  if (!db) return null;
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const request = tx.objectStore(STORE_NAME).getAll();
    request.onsuccess = () => resolve((request.result || []) as OfflineQueueItem[]);
    request.onerror = () => reject(request.error || new Error('IndexedDB read failed'));
    tx.onerror = () => reject(tx.error || new Error('IndexedDB transaction read failed'));
    tx.onabort = () => reject(tx.error || new Error('IndexedDB transaction read aborted'));
    tx.oncomplete = () => db.close();
  });
}

async function idbReplaceAll(queue: OfflineQueueItem[]): Promise<void> {
  const db = await openDb();
  if (!db) throw new Error('IndexedDB no disponible');
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    store.clear();
    queue.forEach(item => store.put(item));
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error || new Error('IndexedDB write failed'));
    tx.onabort = () => reject(tx.error || new Error('IndexedDB write aborted'));
  });
  db.close();
}

async function idbPut(item: OfflineQueueItem): Promise<void> {
  const db = await openDb();
  if (!db) throw new Error('IndexedDB no disponible');
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).put(item);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error || new Error('IndexedDB put failed'));
    tx.onabort = () => reject(tx.error || new Error('IndexedDB put aborted'));
  });
  db.close();
}

async function idbDelete(id: string): Promise<void> {
  const db = await openDb();
  if (!db) throw new Error('IndexedDB no disponible');
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error || new Error('IndexedDB delete failed'));
    tx.onabort = () => reject(tx.error || new Error('IndexedDB delete aborted'));
  });
  db.close();
}

async function idbClear(): Promise<void> {
  const db = await openDb();
  if (!db) throw new Error('IndexedDB no disponible');
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).clear();
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error || new Error('IndexedDB clear failed'));
    tx.onabort = () => reject(tx.error || new Error('IndexedDB clear aborted'));
  });
  db.close();
}

async function migrateLegacyQueue(): Promise<void> {
  if (typeof window === 'undefined') { queueReady = true; return; }
  const legacyRaw = localStorage.getItem(STORAGE_KEY);
  const legacy = legacyRaw ? (() => { try { return JSON.parse(legacyRaw); } catch { return []; } })() : [];
  let existing: OfflineQueueItem[] | null = null;
  try {
    existing = await idbGetAll();
  } catch (e) {
    // Never replace IndexedDB with an empty queue when a read itself failed.
    // The old behavior could erase durable pending sales during startup.
    console.error('[offlineSync] No se pudo leer la cola IndexedDB; se conserva sin sobrescribir:', e);
    memoryQueue = Array.isArray(legacy) ? legacy : [];
    queueReady = true;
    emitQueueEvent();
    return;
  }
  // Merge every source instead of choosing one. This prevents an enqueue that
  // happens during startup from being overwritten by the migration itself.
  const merged = new Map<string, OfflineQueueItem>();
  for (const item of [...(Array.isArray(existing) ? existing : []), ...(Array.isArray(legacy) ? legacy : []), ...memoryQueue]) {
    const normalized = { ...item, deviceId: item.deviceId || getDeviceId() };
    merged.set(`${normalized.type}:${normalized.actionId}`, normalized);
  }
  memoryQueue = Array.from(merged.values()).sort((a,b) => a.timestamp.localeCompare(b.timestamp));
  try {
    await idbReplaceAll(memoryQueue);
    if (legacyRaw) localStorage.removeItem(STORAGE_KEY);
  } catch (e) {
    persistenceError = e instanceof Error ? e : new Error(String(e));
    // Si IndexedDB está dañado/bloqueado, conservamos una copia durable en
    // localStorage y NO eliminamos la cola heredada.
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(memoryQueue)); } catch { /* se conserva en memoria */ }
    console.error('[offlineSync] IndexedDB no disponible durante migración; usando respaldo local:', e);
  }
  queueReady = true;
  emitQueueEvent();

  // Si ya existe conexión al terminar la hidratación, no dejamos la cola
  // esperando hasta el próximo evento 'online' o el intervalo de 30s.
  // En modo manual el usuario conserva el control explícito.
  if (typeof navigator !== 'undefined' && navigator.onLine) {
    try {
      const manual = useStore.getState().storeConfig?.manualOfflineSync === true;
      if (!manual && memoryQueue.length > 0) {
        void processOfflineQueue();
      }
    } catch {
      // El store todavía puede estar inicializándose; el watcher volverá a intentarlo.
    }
  }
}

// Hydrate once at module load. Synchronous readers use the memory snapshot.
// Writers wait for this migration so a first offline operation cannot be lost
// when the legacy localStorage queue is being imported.
queueInitPromise = migrateLegacyQueue();

function emitQueueEvent() {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('offline_queue_updated', { detail: { count: memoryQueue.length } }));
  }
}

export function getOfflineQueue(): OfflineQueueItem[] {
  return [...memoryQueue];
}

/**
 * Espera a que la cola persistida haya terminado de migrarse antes de leerla.
 * Esto evita una condición de carrera al reconectar justo después de abrir la app:
 * antes de la migración memoryQueue puede estar vacía aunque IndexedDB tenga ventas.
 */
export async function waitForOfflineQueueReady(): Promise<void> {
  if (queueInitPromise) await queueInitPromise;
}

function persistQueueSnapshot(queue: OfflineQueueItem[]): void {
  memoryQueue = [...queue];
  emitQueueEvent();
  const snapshot = [...memoryQueue];
  // El snapshot completo se usa solo durante la migración/recuperación.
  // Las operaciones normales usan put/delete incrementales para no reescribir
  // miles de operaciones cada vez que entra una venta nueva.
  persistenceChain = persistenceChain.then(async () => {
    if (!queueReady && queueInitPromise) await queueInitPromise;
    if (typeof indexedDB !== 'undefined') {
      await idbReplaceAll(snapshot);
      return;
    }
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(snapshot)); } catch (e) {
      console.error('[offlineSync] Error al guardar cola offline:', e);
    }
  }).catch(async e => {
    persistenceError = e instanceof Error ? e : new Error(String(e));
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(snapshot)); } catch { /* se conserva en memoria y se reporta al sincronizador */ }
    console.error('[offlineSync] Error persistiendo cola:', e);
  });
}

function persistQueueItem(item: OfflineQueueItem): void {
  persistenceChain = persistenceChain.then(async () => {
    if (!queueReady && queueInitPromise) await queueInitPromise;
    if (typeof indexedDB !== 'undefined') {
      await idbPut(item);
      return;
    }
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(memoryQueue)); } catch (e) {
      console.error('[offlineSync] Error al guardar cola offline:', e);
    }
  }).catch(async e => {
    persistenceError = e instanceof Error ? e : new Error(String(e));
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(memoryQueue)); } catch { /* se reporta y se conserva en memoria */ }
    console.error('[offlineSync] Error persistiendo cola:', e);
  });
}

function persistQueueDelete(id: string): void {
  persistenceChain = persistenceChain.then(async () => {
    if (!queueReady && queueInitPromise) await queueInitPromise;
    if (typeof indexedDB !== 'undefined') {
      await idbDelete(id);
      return;
    }
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(memoryQueue)); } catch (e) {
      console.error('[offlineSync] Error al guardar cola offline:', e);
    }
  }).catch(async e => {
    persistenceError = e instanceof Error ? e : new Error(String(e));
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(memoryQueue)); } catch { /* se reporta y se conserva en memoria */ }
    console.error('[offlineSync] Error persistiendo cola:', e);
  });
}

async function waitForQueuePersistence(): Promise<void> {
  await persistenceChain;
  if (persistenceError) { const error = persistenceError; persistenceError = null; throw error; }
}

function persistQueueClear(): void {
  persistenceChain = persistenceChain.then(async () => {
    if (!queueReady && queueInitPromise) await queueInitPromise;
    if (typeof indexedDB !== 'undefined') {
      await idbClear();
      return;
    }
    try { localStorage.removeItem(STORAGE_KEY); } catch (e) {
      console.error('[offlineSync] Error al limpiar cola offline:', e);
    }
  }).catch(e => console.error('[offlineSync] Error persistiendo cola:', e));
}

export function enqueueOfflineItem(type: OfflineActionType, data: any, actionId?: string): void {
  const finalActionId = actionId || data?.id || crypto.randomUUID();
  const currentQueue = getOfflineQueue();
  const existingIdx = currentQueue.findIndex(item => item.type === type && item.actionId === finalActionId);
  const base = {
    id: existingIdx >= 0 ? currentQueue[existingIdx].id : crypto.randomUUID(),
    actionId: finalActionId,
    type,
    data,
    timestamp: new Date().toISOString(),
    retryCount: existingIdx >= 0 ? currentQueue[existingIdx].retryCount : 0,
    status: 'pending' as const,
    deviceId: getDeviceId()
  };
  if (existingIdx >= 0) {
    removedDuringQueueProcess.delete(currentQueue[existingIdx].id);
    currentQueue[existingIdx] = { ...currentQueue[existingIdx], ...base, data: { ...currentQueue[existingIdx].data, ...data } };
  } else {
    currentQueue.push(base);
  }
  memoryQueue = currentQueue;
  emitQueueEvent();
  persistQueueItem(currentQueue[existingIdx >= 0 ? existingIdx : currentQueue.length - 1]);
  addSyncLog({ level: 'info', source: 'offline_queue', title: `Elemento encolado (${type})`, details: `Operación ${finalActionId} guardada offline. Pendientes: ${currentQueue.length}`, entityType: type, actionId: finalActionId });
}

export function removeFromOfflineQueue(id: string): void {
  removedDuringQueueProcess.add(id);
  memoryQueue = memoryQueue.filter(item => item.id !== id);
  emitQueueEvent();
  persistQueueDelete(id);
}

export function clearOfflineQueue(): void {
  for (const item of memoryQueue) removedDuringQueueProcess.add(item.id);
  memoryQueue = [];
  emitQueueEvent();
  persistQueueClear();
}
export function getOfflineQueueCount(): number { return memoryQueue.length; }

async function processQueueItem(supabase: any, item: OfflineQueueItem): Promise<boolean> {
  const { type, data } = item;
  switch (type) {
    case 'cash_session': {
      const session = data as CashRegisterSession & { __operation?: 'open' | 'close' | 'cancel' | 'snapshot'; settlement?: any; closedAt?: string };
      if (session.__operation === 'close') {
        const settlement = session.settlement;
        if (!settlement) throw new Error('Cierre offline sin liquidación asociada');
        const res = await (await import('./supabaseSync')).callCloseSessionRPC(session.id, session.closingBalances || [], session.closedAt || new Date().toISOString(), session.notes || '', settlement);
        if (!res.success) throw new Error(res.error || 'No se pudo cerrar el turno');
        return true;
      }
      if (session.__operation === 'cancel') {
        const res = await callCancelSessionRPC(session.id, session.userId || 'system', session.deleteReason || 'Cancelación de turno');
        if (!res.success) throw new Error(res.error || 'No se pudo cancelar el turno');
        return true;
      }
      if (session.__operation !== 'snapshot' || String(item.actionId).startsWith('cash-open:')) {
        const res = String(item.actionId).startsWith('cash-open:')
          ? await callOpenSessionRPCWithId(session)
          : await callOpenSessionRPC(session);
        if (res.success) return true;
        throw new Error(res.error || 'No se pudo abrir el turno en Supabase');
      }
      const row = {
        id: session.id, user_id: session.userId || null, worker_name: session.workerName || null,
        branch_id: session.branchId, opened_at: session.openedAt, closed_at: session.closedAt || null,
        opening_balance: session.openingAmount, status: session.status,
        notes: session.notes || '', working_employee_ids: session.workingEmployeeIds || [],
        deleted_at: session.deletedAt || null, deleted_by: session.deletedBy || null, delete_reason: session.deleteReason || null
      };
      const { error } = await supabase.from('cash_sessions').upsert(row);
      if (error) throw error;
      return true;
    }
    case 'salary_settlement': {
      const settlement = data;
      const { error } = await supabase.from('salary_settlements').upsert({
        id: settlement.id, user_id: settlement.userId || null, user_name: settlement.userName || '',
        session_id: settlement.sessionId || null, base_salary: settlement.baseSalary || 0,
        commissions: settlement.commissions || 0, discrepancy_deduction: settlement.discrepancyDeduction || 0,
        total: settlement.total || 0, date: settlement.date, status: settlement.status || 'pending'
      });
      if (error) throw error;
      return true;
    }
    case 'customer': {
      const customer = data as Customer;
      const { error } = await supabase.from('customers').upsert({ id: customer.id, name: customer.name, phone: customer.phone || null, email: customer.email || null, tax_id: customer.taxId || null });
      if (error) throw error; return true;
    }
    case 'customer_delete': {
      const { error } = await supabase.from('customers').delete().eq('id', data.id);
      if (error) throw error; return true;
    }
    case 'branch': {
      const b = data as Branch;
      const { error } = await supabase.from('branches').upsert({ id: b.id, name: b.name, address: b.address || null, phone: b.phone || null, is_active: b.isActive !== false, is_main: b.isMain === true });
      if (error) throw error; return true;
    }
    case 'category': {
      const c = data as Category;
      const { error } = await supabase.from('categories').upsert({ id: c.id, name: c.name, department: c.department || 'General', description: c.description || null, color: c.color || null, image: c.image || null });
      if (error) throw error; return true;
    }
    case 'product': {
      const p = data as Product;
      const { error } = await supabase.from('products').upsert({ id: p.id, name: p.name, sku: p.sku || null, barcode: p.barcode || null, cost_price: p.costPrice || 0, price: p.price || 0, margin: p.margin || 0, category_id: p.categoryId || null, color: p.color || null, commission_value: p.commissionValue || 0, unit: p.unit || 'unidad', status: p.status || 'active', min_stock_alert: p.minStockAlert || 5, has_serial: p.hasSerial || false, warranty_days: p.warrantyDays || 0, is_kit: p.isKit || false, kit_items: p.kitItems || [] });
      if (error) throw error; return true;
    }
    case 'user': {
      const u = data;
      const email = u.email && String(u.email).trim() ? u.email : `${String(u.name || 'user').toLowerCase().replace(/[^a-z0-9]/g, '')}_${String(u.id).slice(0, 6)}@system.local`;
      const { error } = await supabase.from('users').upsert({ id:u.id, name:u.name, email, password:u.password || null, role:u.role || 'employee', base_salary:u.baseSalary || 0, sales_goal:u.salesGoal || 0, branch_id:u.branchId || null, allowed_branches:u.allowedBranches || [], permissions:u.permissions || [], is_active:u.isActive !== false, is_independent:u.isIndependent === true, assigned_branch_id:u.assignedBranchId || u.branchId || null });
      if (error) throw error; return true;
    }
    case 'currency': { const c=data; const {error}=await supabase.from('currencies').upsert({code:c.code,name:c.name,symbol:c.symbol,rate_to_base:c.rateToBase,is_base:c.isBase},{onConflict:'code'}); if(error) throw error; return true; }
    case 'idn_settlement_price': { const d=data; const {error}=await supabase.from('idn_settlement_prices').upsert({id:d.id,user_id:d.userId,product_id:d.productId,settlement_price:d.settlementPrice}); if(error) throw error; return true; }
    case 'warranty': { const d=data; const {error}=await supabase.from('warranties').upsert({id:d.id,product_id:d.productId,product_name:d.productName,transaction_id:d.transactionId,customer_id:d.customerId,customer_name:d.customerName,purchase_date:d.purchaseDate,expiry_date:d.expiryDate,serial_number:d.serialNumber,status:d.status}); if(error) throw error; return true; }
    case 'time_shift': { const d=data; const {error}=await supabase.from('time_shifts').upsert({id:d.id,user_id:d.userId,clock_in:d.clockIn,clock_out:d.clockOut,notes:d.notes}); if(error) throw error; return true; }
    case 'quote': { const d=data; const {error}=await supabase.from('quotes').upsert({id:d.id,branch_id:d.branchId,user_id:d.userId,customer_id:d.customerId,date:d.date,subtotal:d.subtotal,tax:d.tax,total:d.total,items:d.items||[],status:d.status,notes:d.notes}); if(error) throw error; return true; }
    case 'bank_card': { const d=data; const {error}=await supabase.from('bank_cards').upsert({id:d.id,name:d.name||d.bankName||'Tarjeta Bancaria',bank:d.bank||d.bankName||'Banco',bank_name:d.bankName||d.bank||'Banco',card_holder:d.cardHolder||'Titular',account_number:d.accountNumber||d.lastFourDigits||d.lastFour||'',phone:d.phone||'',last_four_digits:d.lastFourDigits||d.lastFour||(d.accountNumber?String(d.accountNumber).slice(-4):'0000'),balance:d.balance||0,currency:d.currency||'CUP',color:d.color||'from-indigo-600 to-purple-800',is_active:d.isActive!==false}); if(error) throw error; return true; }
    case 'bank_transaction': { const d=data; if (d.__operation === 'delete') { const { error } = await supabase.from('bank_transactions').delete().eq('id', d.id); if (error) throw error; return true; } const {error}=await supabase.from('bank_transactions').upsert({id:d.id,card_id:d.cardId,type:d.type,amount:d.amount,date:d.date,reference:d.reference,description:d.description,transaction_id:d.transactionId||null}); if(error) throw error; return true; }
    case 'supplier': { const d=data; const {error}=await supabase.from('suppliers').upsert({id:d.id,name:d.name,phone:d.phone||'',address:d.address||'',email:d.email||'',rating:d.rating||5,type_of_merchandise:d.typeOfMerchandise||''}); if(error) throw error; return true; }
    case 'supplier_order': { const d=data; const {error}=await supabase.from('supplier_orders').upsert({id:d.id,supplier_id:d.supplierId,date:d.date,expected_delivery_date:d.expectedDeliveryDate,items:d.items||[],total:d.total,status:d.status,branch_id:d.branchId,transport_details:d.transportDetails,transport_cost:d.transportCost}); if(error) throw error; return true; }
    case 'inventory_audit': { const d=data; const {error}=await supabase.from('inventory_audits').upsert({id:d.id,date:d.date,branch_id:d.branchId,user_id:d.userId,status:d.status,items:d.items||[],notes:d.notes}); if(error) throw error; return true; }
    case 'transaction': {
      const transaction = data as Transaction;
      // IDN settlement records must be persisted without consuming inventory again.
      if (transaction.notes === 'LIQUIDACION_IDN') {
        const { error } = await supabase.from('transactions').upsert({
          id: transaction.id, date: transaction.date, total: transaction.total,
          tax: transaction.tax || 0, discount: transaction.discount || 0,
          branch_id: transaction.branchId, customer_id: transaction.customerId || null,
          user_id: transaction.userId || null, status: transaction.status || 'completed',
          notes: transaction.notes || '', payment_method: transaction.paymentMethod || 'cash',
          session_id: transaction.sessionId || null, change_given: transaction.changeGiven || 0,
          items: transaction.items || [], payments: transaction.payments || [],
          change_payments: transaction.changePayments || [], seller_employee_ids: transaction.sellerEmployeeIds || [],
          deleted_at: transaction.deletedAt || null, deleted_by: transaction.deletedBy || null,
          delete_reason: transaction.deleteReason || null
        });
        if (error) throw error;
        return true;
      }
      const res = await callProcessTransactionRPC(transaction);
      if (!res.success) {
        if (res.errorCode) throw new PermanentSyncError(res.error || 'La venta fue rechazada por Supabase');
        throw new Error(res.error || 'No se pudo sincronizar la venta');
      }

      // No damos la operación por completada solo porque el HTTP/RPC respondió.
      // Confirmamos que la fila existe realmente en Supabase antes de retirar la
      // operación de IndexedDB. Así una respuesta incompleta o una caída durante
      // la confirmación nunca puede dejar una venta perdida y una cola vacía.
      const { data: persisted, error: verifyError } = await supabase
        .from('transactions')
        .select('id,status,total')
        .eq('id', transaction.id)
        .maybeSingle();
      if (verifyError) throw verifyError;
      if (!persisted || persisted.id !== transaction.id) {
        throw new Error('Supabase no confirmó la venta después de procesarla');
      }
      return true;
    }
    case 'void_transaction': { const res = await callVoidTransactionRPC(data.id, data.userId, data.reason || 'Anulación de venta'); if (!res.success) throw new Error(res.error || 'No se pudo anular la venta'); return true; }
    case 'return_complete': { const res = await callCompleteReturnRPC(data.id, data.userId); if (!res.success) throw new Error(res.error || 'No se pudo completar la devolución'); return true; }
    case 'transfer': { const res = await callTransferInventoryRPC(data); if (!res.success) throw new Error(res.error || 'No se pudo sincronizar la transferencia'); return true; }
    case 'supplier_receive': { const res = await callReceiveSupplierOrderRPC(data.id, data.userId || 'system'); if (!res.success) throw new Error(res.error || 'No se pudo recibir la orden'); return true; }
    case 'audit_complete': { const res = await callCompleteInventoryAuditRPC(data.id, data.branchId, data.userId, data.items || [], data.notes); if (!res.success) throw new Error(res.error || 'No se pudo completar la auditoría'); return true; }
    case 'inventory': {
      // Compatibilidad con colas antiguas que guardaban un stock absoluto.
      // Nunca sobrescribimos silenciosamente un cambio remoto: solo aceptamos
      // la operación si el servidor todavía coincide con el valor esperado.
      const { data: current, error: readError } = await supabase.from('inventory').select('quantity').eq('product_id', data.productId).eq('branch_id', data.branchId).eq('variant_label', data.variantLabel || '').maybeSingle();
      if (readError) throw readError;
      if (current && Number(current.quantity) !== Number(data.quantity)) {
        throw new Error('Conflicto de inventario legado: el stock remoto cambió antes de sincronizar.');
      }
      return true;
    }
    case 'inventory_adjustment': {
      const { data: result, error } = await supabase.rpc('apply_inventory_adjustment_v2', {
        p_operation_id: item.actionId, p_product_id: data.productId, p_branch_id: data.branchId,
        p_variant_label: data.variantLabel || '', p_delta: Number(data.delta) || 0,
        p_min_quantity: Number(data.minQuantity) || 0, p_user_id: data.userId || null,
        p_movement_type: data.movementType || 'ADJUSTMENT'
      });
      if (error) throw error;
      if (result?.conflict) throw new Error(result.message || 'Conflicto de inventario');
      return true;
    }
    case 'inventory_reconcile': {
      const { data: result, error } = await supabase.rpc('reconcile_inventory_v2', {
        p_operation_id: item.actionId, p_product_id: data.productId, p_branch_id: data.branchId,
        p_variant_label: data.variantLabel || '', p_expected_quantity: Number(data.expectedQuantity),
        p_new_quantity: Math.max(0, Number(data.quantity) || 0), p_min_quantity: Number(data.minQuantity) || 0,
        p_user_id: data.userId || null
      });
      if (error) throw error;
      if (result?.conflict) throw new Error(result.message || 'Conflicto de inventario: el stock cambió mientras estaba offline');
      return true;
    }
    case 'return': {
      const ret = data as ReturnItem;
      const { error } = await supabase.from('returns').upsert({ id: ret.id, transaction_id: ret.transactionId || null, product_id: ret.productId, quantity: Number(ret.quantity) || 1, reason: ret.reason || '', date: ret.date, status: ret.status || 'pending', type: ret.type || 'refund', notes: ret.notes || null, variant_label: ret.variantLabel || null });
      if (error) throw error; return true;
    }
    case 'receipt_config': { const { error } = await supabase.from('settings').upsert({ id: 'global', receipt_config: data }); if (error) throw error; return true; }
    case 'store_config': { const { error } = await supabase.from('settings').upsert({ id: 'global', store_config: data }); if (error) throw error; return true; }
    case 'catalog_config': { const { error } = await supabase.from('settings').upsert({ id: 'global', catalog_config: data }); if (error) throw error; return true; }
    default: throw new PermanentSyncError(`Tipo de operación offline no soportado: ${String(type)}`);
  }
}

export async function processOfflineQueue(): Promise<{ processed: number; failed: number; remaining: number; errors: Array<{ type: string; actionId: string; message: string; retryCount?: number }> }> {
  // Nunca inspeccionar una cola todavía no hidratada desde IndexedDB.
  await waitForOfflineQueueReady();
  if (isProcessingQueue || (typeof navigator !== 'undefined' && !navigator.onLine)) {
    return { processed: 0, failed: 0, remaining: getOfflineQueueCount(), errors: [] };
  }
  const supabase = getSupabase();
  if (!supabase) return { processed: 0, failed: 0, remaining: getOfflineQueueCount(), errors: [{ type: 'system', actionId: 'supabase', message: 'Supabase no está disponible en esta sesión.' }] };
  const queueAtStart = getOfflineQueue();
  if (!queueAtStart.length) return { processed: 0, failed: 0, remaining: 0, errors: [] };

  isProcessingQueue = true;
  // Procesamos una instantánea estable. Las operaciones que entren mientras
  // sincronizamos se reconcilian al final y nunca se pierden por reemplazar
  // memoryQueue con una instantánea vieja.
  const sorted = [...queueAtStart].sort((a,b) => a.timestamp.localeCompare(b.timestamp) || a.id.localeCompare(b.id));
  const startById = new Map(sorted.map(item => [item.id, item]));
  let processed = 0, failed = 0;
  const errors: Array<{ type: string; actionId: string; message: string; retryCount?: number }> = [];
  const remainingFromRun: OfflineQueueItem[] = [];
  const handledIds = new Set<string>();

  for (let index = 0; index < sorted.length; index++) {
    const item = sorted[index];
    item.status = 'processing';
    try {
      await processQueueItem(supabase, item);
      processed++;
      handledIds.add(item.id);
      addSyncLog({ level:'success', source:'offline_queue', title:`Item sincronizado (${item.type})`, details:`Operación ${item.actionId} confirmada por Supabase.`, entityType:item.type, actionId:item.actionId });
    } catch (err:any) {
      failed++;
      item.retryCount = (item.retryCount || 0) + 1;
      item.lastError = err?.message || 'Error desconocido';
      const permanent = err?.permanent === true;
      item.status = permanent || item.retryCount >= 8 ? 'conflict' : 'failed';
      remainingFromRun.push(item);
      errors.push({ type: item.type, actionId: item.actionId, message: item.lastError, retryCount: item.retryCount });
      addSyncLog({ level:'error', source:'offline_queue', title:`Error al procesar item (${item.type})`, details:item.lastError, entityType:item.type, actionId:item.actionId, retryAttempt:item.retryCount, maxRetries:8 });
      if (!permanent && (item.type === 'transaction' || item.type === 'cash_session' || item.type === 'transfer' || item.type === 'return_complete')) {
        // Las operaciones críticas mantienen el orden temporal: una dependencia
        // fallida no permite que las posteriores la salten.
        for (let tail = index + 1; tail < sorted.length; tail++) remainingFromRun.push(sorted[tail]);
        break;
      }
    }
  }

  // Conservar elementos de la instantánea que no fueron procesados por el corte
  // de dependencia anterior.
  const runRemainingIds = new Set(remainingFromRun.map(item => item.id));
  for (const item of sorted) {
    if (!handledIds.has(item.id) && !runRemainingIds.has(item.id)) remainingFromRun.push(item);
  }

  // Reconciliar con cambios hechos durante el procesamiento. Un enqueue nuevo
  // puede tener un ID distinto o actualizar el mismo actionId mientras la RPC
  // estaba en vuelo. En ambos casos debe sobrevivir a esta ejecución. Si el
  // usuario lo eliminó explícitamente, no lo reinsertamos.
  const currentAfterRun = getOfflineQueue();
  const currentById = new Map(currentAfterRun.map(item => [item.id, item]));
  const finalById = new Map<string, OfflineQueueItem>();
  for (const item of remainingFromRun) {
    if (!removedDuringQueueProcess.has(item.id)) finalById.set(item.id, item);
  }

  for (const [id, current] of currentById) {
    if (removedDuringQueueProcess.has(id)) continue;
    const original = startById.get(id);
    if (!original) {
      // Operación agregada mientras procesábamos.
      finalById.set(id, current);
      continue;
    }
    const changedDuringRun = current.timestamp !== original.timestamp ||
      current.actionId !== original.actionId ||
      JSON.stringify(current.data) !== JSON.stringify(original.data);
    if (changedDuringRun) {
      // Es una versión más reciente de la operación; no puede considerarse
      // completada por la versión antigua que estaba en vuelo.
      finalById.set(id, { ...current, status: 'pending' });
    } else if (!handledIds.has(id)) {
      // La operación sigue pendiente porque esta ejecución no llegó a confirmarla.
      finalById.set(id, current);
    }
  }

  const finalQueue = Array.from(finalById.values()).sort((a,b) => a.timestamp.localeCompare(b.timestamp) || a.id.localeCompare(b.id));
  for (const item of sorted) removedDuringQueueProcess.delete(item.id);
  memoryQueue = finalQueue;
  emitQueueEvent();

  // Reconciliamos contra el estado final, no contra la instantánea inicial.
  // Esto evita que un enqueue concurrente sea borrado por el commit de la cola.
  persistenceChain = persistenceChain.then(async () => {
    if (!queueReady && queueInitPromise) await queueInitPromise;
    if (typeof indexedDB !== 'undefined') {
      await idbReplaceAll(finalQueue);
      return;
    }
    if (typeof localStorage !== 'undefined') localStorage.setItem(STORAGE_KEY, JSON.stringify(finalQueue));
  });

  try {
    await waitForQueuePersistence();
  } catch (persistenceError: any) {
    // El servidor puede haber confirmado la operación, pero si la cola local no
    // pudo persistir su nuevo estado, conservamos todas las operaciones de esta
    // ejecución para evitar una falsa sensación de sincronización. Las RPC son
    // idempotentes por sus IDs de operación.
    const durableFallback: OfflineQueueItem[] = queueAtStart.map(item => ({
      ...item,
      status: item.status === 'processing' ? 'pending' : item.status
    }));
    const fallbackById = new Map(durableFallback.map(item => [item.id, item]));
    for (const item of currentAfterRun) fallbackById.set(item.id, item);
    memoryQueue = Array.from(fallbackById.values());
    emitQueueEvent();
    isProcessingQueue = false;
    const persistenceMessage = persistenceError?.message || 'Error de IndexedDB/localStorage. Las operaciones se conservaron para reintento.';
    errors.push({ type: 'offline_queue', actionId: 'persistence', message: persistenceMessage });
    addSyncLog({ level:'error', source:'offline_queue', title:'Cola local no pudo persistirse', details:persistenceMessage, entityType:'offline_queue' });
    return { processed, failed, remaining: memoryQueue.length, errors };
  }

  isProcessingQueue = false;
  return { processed, failed, remaining: finalQueue.length, errors };
}

function isManualOfflineSyncEnabled(): boolean {
  try {
    const config = useStore.getState().storeConfig;
    return config?.manualOfflineSync === true;
  } catch {
    return false;
  }
}

export function initOfflineSyncWatcher(): () => void {
  if (typeof window === 'undefined') return () => {};
  let intervalId: any = null;
  const handleOnline = async () => {
    if (isManualOfflineSyncEnabled()) return;
    const count = getOfflineQueueCount();
    if (!count) return;
    useStore.getState().addNotification(`Conexión detectada. Sincronizando ${count} operaciones pendientes...`, 'info');
    try {
      const res = await processOfflineQueue();
      if (res.remaining > 0) {
        useStore.getState().addNotification(`Sincronización incompleta: ${res.processed} procesadas; ${res.remaining} siguen pendientes.`, 'warning', res.errors?.length ? res.errors.map(e => `${e.type} · ${e.actionId}: ${e.message}`).join('\n') : undefined);
      } else if (res.processed > 0) {
        useStore.getState().addNotification(`Sincronización completada: ${res.processed} operaciones confirmadas.`, 'success');
      }
    } catch (e: any) {
      useStore.getState().addNotification(`No se pudo completar la sincronización: ${e?.message || 'error desconocido'}.`, 'error');
    }
  };
  const handleOffline = () => useStore.getState().addNotification('Sin conexión. El POS continúa trabajando offline.', 'warning');
  window.addEventListener('online', handleOnline);
  window.addEventListener('offline', handleOffline);
  intervalId = setInterval(() => { 
    if (navigator.onLine && getOfflineQueueCount() && !isProcessingQueue && !isManualOfflineSyncEnabled()) {
      processOfflineQueue().catch(() => {}); 
    }
  }, 30000);
  if (navigator.onLine && getOfflineQueueCount() && !isManualOfflineSyncEnabled()) processOfflineQueue().catch(() => {});
  return () => { window.removeEventListener('online', handleOnline); window.removeEventListener('offline', handleOffline); if (intervalId) clearInterval(intervalId); };
}
