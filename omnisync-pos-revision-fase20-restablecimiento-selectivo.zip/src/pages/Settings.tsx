import { useShallow } from 'zustand/react/shallow';
import React, { useState, useEffect } from "react";
import { Settings as SettingsIcon, Save, DollarSign, Building2, Users, Plus, Trash2, Edit, LayoutGrid, Store, AlertTriangle, RefreshCw, Usb, Bluetooth, Wifi, Printer, CheckCircle2, ExternalLink, AlertCircle, Sparkles, Smartphone, ChevronRight, Package, Search, X, Database, CreditCard, CloudUpload, CloudDownload, Check, Sun, Moon } from "lucide-react";
import { useStore } from "../store/useStore";
import { InfoTooltip } from "../components/InfoTooltip";
import { Branch, Category, User } from "../types";
import { cn } from "../lib/utils";
import { normalizeSemanticText } from "../utils/textUtils";

export default function Settings() {
  const { 
    currencies, updateCurrencyRate, 
    storeConfig, updateStoreConfig, 
    branches, addBranch, updateBranch, deleteBranch,
    categories, addCategory, updateCategory, deleteCategory,
    receiptConfig, updateReceiptConfig,
    users, updateUser, addUser, deleteUser,
    getBaseCurrency, clearAllData,
    exportData, importData,
    registerEmployee,
    idnSettlementPrices, addIDNSettlementPrice, updateIDNSettlementPrice, deleteIDNSettlementPrice,
    products,
    inventory, transactions, cashSessions,
    syncWithSupabase,
    addNotification
  } = useStore(useShallow((state) => ({ 
    currencies: state.currencies, 
    updateCurrencyRate: state.updateCurrencyRate, 
    storeConfig: state.storeConfig, 
    updateStoreConfig: state.updateStoreConfig, 
    branches: state.branches, 
    addBranch: state.addBranch, 
    updateBranch: state.updateBranch, 
    deleteBranch: state.deleteBranch, 
    categories: state.categories, 
    addCategory: state.addCategory, 
    updateCategory: state.updateCategory, 
    deleteCategory: state.deleteCategory, 
    receiptConfig: state.receiptConfig, 
    updateReceiptConfig: state.updateReceiptConfig, 
    users: state.users, 
    updateUser: state.updateUser, 
    addUser: state.addUser, 
    deleteUser: state.deleteUser, 
    getBaseCurrency: state.getBaseCurrency, 
    clearAllData: state.clearAllData, 
    exportData: state.exportData, 
    importData: state.importData, 
    registerEmployee: state.registerEmployee, 
    idnSettlementPrices: state.idnSettlementPrices, 
    addIDNSettlementPrice: state.addIDNSettlementPrice, 
    updateIDNSettlementPrice: state.updateIDNSettlementPrice, 
    deleteIDNSettlementPrice: state.deleteIDNSettlementPrice, 
    products: state.products, 
    inventory: state.inventory, 
    transactions: state.transactions, 
    cashSessions: state.cashSessions, 
    syncWithSupabase: state.syncWithSupabase,
    addNotification: state.addNotification
  })));

  const baseCurrency = getBaseCurrency();

  const [rates, setRates] = useState<{ [code: string]: number }>(
    currencies.reduce((acc, c) => ({ ...acc, [c.code]: c.rateToBase }), {})
  );

  const [config, setConfig] = useState(storeConfig);
  const [ticketConfig, setTicketConfig] = useState(receiptConfig);
  const employees = users.filter(u => u.role === 'employee');
  const [employeeSalaries, setEmployeeSalaries] = useState<{ [id: string]: number }>({});
  
  const [printerStatus, setPrinterStatus] = useState<{
    type: 'idle' | 'loading' | 'success' | 'error' | 'warning';
    message: string;
    deviceName?: string;
  } | null>(null);
  const [isInIframe, setIsInIframe] = useState(false);

  // In-app Toast
  const [toast, setToast] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ type, message });
    setTimeout(() => setToast(null), 4000);
  };

  // In-app Deletion Confirmations (Bypasses iframe blocked window.confirm)
  const [userToDelete, setUserToDelete] = useState<{ id: string; name: string } | null>(null);
  const [branchToDelete, setBranchToDelete] = useState<{ id: string; name: string } | null>(null);
  const [categoryToDelete, setCategoryToDelete] = useState<{ id: string; name: string } | null>(null);

  useEffect(() => {
    try {
      setIsInIframe(window.self !== window.top);
    } catch (e) {
      setIsInIframe(true);
    }
  }, []);

  // Sync employee salaries when users are loaded
  useEffect(() => {
    if (users.length > 0) {
      setEmployeeSalaries(prev => {
        const next = { ...prev };
        users.forEach(u => {
          if (!(u.id in next)) {
            next[u.id] = u.baseSalary || 0;
          }
        });
        return next;
      });
    }
  }, [users]);

  const [newBranchName, setNewBranchName] = useState("");
  const [editingBranch, setEditingBranch] = useState<Branch | null>(null);

  const [newCategory, setNewCategory] = useState({ name: "", department: "" });
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  
  const [newEmployee, setNewEmployee] = useState({ 
    name: "", 
    password: "", 
    isIndependent: false, 
    assignedBranchId: "" 
  });

  const [isLoading, setIsLoading] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [showConfirmCache, setShowConfirmCache] = useState(false);
  const [showConfirmReset, setShowConfirmReset] = useState(false);
  const [resetInput, setResetInput] = useState("");
  const RESET_OPTIONS = [
    { id: 'inventory', label: 'Inventario', desc: 'Existencias, movimientos y transferencias', icon: Package },
    { id: 'reports', label: 'Reportes e historial', desc: 'Ventas, turnos, devoluciones, garantías y auditorías', icon: Database },
    { id: 'catalog', label: 'Catálogo', desc: 'Productos, categorías y precios IDN', icon: LayoutGrid },
    { id: 'customers', label: 'Clientes', desc: 'Clientes registrados', icon: Users },
    { id: 'suppliers', label: 'Proveedores', desc: 'Proveedores registrados', icon: Store },
    { id: 'purchases', label: 'Compras', desc: 'Pedidos a proveedores', icon: CloudDownload },
    { id: 'cash', label: 'Caja y turnos', desc: 'Turnos, movimientos de caja y liquidaciones', icon: DollarSign },
    { id: 'bank', label: 'Bancos', desc: 'Tarjetas y movimientos bancarios', icon: CreditCard },
    { id: 'users', label: 'Usuarios y empleados', desc: 'Restablece usuarios dejando el administrador inicial', icon: Users },
    { id: 'branches', label: 'Sucursales', desc: 'Elimina las sucursales configuradas', icon: Building2 },
    { id: 'quotes', label: 'Cotizaciones y pedidos', desc: 'Cotizaciones y pedidos pendientes', icon: CloudUpload },
    { id: 'settings', label: 'Configuración', desc: 'Tasas de moneda y valores de configuración restablecibles', icon: SettingsIcon },
  ] as const;
  const [resetSections, setResetSections] = useState<string[]>([]);

  const [selectedIDNUser, setSelectedIDNUser] = useState<User | null>(null);
  const [selectedUserForConfig, setSelectedUserForConfig] = useState<User | null>(null);
  const [userFilterTab, setUserFilterTab] = useState<'all' | 'normal' | 'idn'>('all');
  const [idnProductSearch, setIdnProductSearch] = useState("");
  const [newSettlementPrice, setNewSettlementPrice] = useState<number>(0);
  const [selectedIDNProduct, setSelectedIDNProduct] = useState<string>("");

  const [activeTab, setActiveTab] = useState<'connectivity' | 'company' | 'branches' | 'categories' | 'employees' | 'advanced'>('connectivity');

  const handleClearData = async () => {
    if (resetInput.trim().toUpperCase() !== 'ELIMINAR' || resetSections.length === 0) return;
    setIsLoading(true);
    try {
      const result = await useStore.getState().resetSelectedData(resetSections as any);
      if (!result.success) {
        showToast(`Restablecimiento parcial. No se pudieron limpiar: ${result.failed.join(', ')}`, 'error');
        return;
      }
      showToast('Los módulos seleccionados fueron restablecidos correctamente.');
      setShowConfirmReset(false);
      setResetInput('');
      setResetSections([]);
      window.location.reload();
    } catch (e) {
      console.error('Error al restablecer los datos:', e);
      showToast('No se pudo completar el restablecimiento.', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const toggleResetSection = (id: string) => {
    setResetSections(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const toggleAllResetSections = () => {
    setResetSections(prev => prev.length === RESET_OPTIONS.length ? [] : RESET_OPTIONS.map(x => x.id));
  };

  const handleSaveRates = () => {
    Object.entries(rates).forEach(([code, rate]) => {
      updateCurrencyRate(code, rate as number);
    });
    showToast("Tasas de cambio actualizadas correctamente.");
  };

  const handleSaveConfig = () => {
    updateStoreConfig(config);
    showToast("Datos de la empresa actualizados.");
  };

  const handleSaveTicket = () => {
    updateReceiptConfig(ticketConfig);
    showToast("Configuración de ticket guardada.");
  };

  const handleSaveEmployeeSalary = (userId: string) => {
    const salary = employeeSalaries[userId];
    updateUser(userId, { baseSalary: salary });
    showToast("Salario actualizado correctamente.");
  };

  const confirmDeleteUserAction = () => {
    if (userToDelete) {
      deleteUser(userToDelete.id);
      showToast(`Empleado "${userToDelete.name}" desactivado. Se conserva su historial.`);
      setUserToDelete(null);
    }
  };

  const confirmDeleteBranchAction = () => {
    if (branchToDelete) {
      const hasStock = (inventory || []).some(l => l.branchId === branchToDelete.id && l.quantity > 0);
      const hasTx = (transactions || []).some(t => t.branchId === branchToDelete.id && !t.deletedAt);
      const hasSessions = (cashSessions || []).some(s => s.branchId === branchToDelete.id && !s.deletedAt);

      if (hasStock || hasTx || hasSessions) {
        showToast(`No se puede eliminar "${branchToDelete.name}" porque contiene existencias, ventas o turnos registrados. Considere desactivarla.`, "error");
        setBranchToDelete(null);
        return;
      }

      deleteBranch(branchToDelete.id);
      showToast(`Sucursal "${branchToDelete.name}" eliminada.`);
      setBranchToDelete(null);
    }
  };

  const confirmDeleteCategoryAction = () => {
    if (categoryToDelete) {
      const hasProducts = (products || []).some(p => p.categoryId === categoryToDelete.id);
      if (hasProducts) {
        showToast(`No se puede eliminar la categoría "${categoryToDelete.name}" porque tiene productos asignados.`, "error");
        setCategoryToDelete(null);
        return;
      }

      deleteCategory(categoryToDelete.id);
      showToast(`Categoría "${categoryToDelete.name}" eliminada.`);
      setCategoryToDelete(null);
    }
  };

  const handleAddBranch = () => {
    const trimmed = newBranchName.trim();
    if (trimmed) {
      const normInput = normalizeSemanticText(trimmed);
      const duplicate = branches.find(b => 
        normalizeSemanticText(b.name) === normInput && 
        (!editingBranch || b.id !== editingBranch.id)
      );

      if (duplicate) {
        showToast(`Ya existe un almacén/sucursal con este nombre ("${duplicate.name}"). No se permiten duplicados.`, "error");
        return;
      }

      if (editingBranch) {
        updateBranch(editingBranch.id, { name: trimmed });
        setEditingBranch(null);
        showToast("Sucursal actualizada.");
      } else {
        addBranch({ id: crypto.randomUUID(), name: trimmed });
        showToast("Sucursal agregada y guardada en Supabase.");
      }
      setNewBranchName("");
    }
  };

  const handleAddCategory = () => {
    if (newCategory.name.trim() && newCategory.department.trim()) {
      if (editingCategory) {
        updateCategory(editingCategory.id, { name: newCategory.name.trim(), department: newCategory.department.trim() });
        setEditingCategory(null);
        showToast("Categoría actualizada.");
      } else {
        addCategory({ id: crypto.randomUUID(), name: newCategory.name.trim(), department: newCategory.department.trim() });
        showToast("Categoría registrada.");
      }
      setNewCategory({ name: "", department: "" });
    }
  };

  const handleAddIDNSettlement = () => {
    if (!selectedIDNUser || !selectedIDNProduct || newSettlementPrice <= 0) return;
    
    const existing = idnSettlementPrices.find(p => p.userId === selectedIDNUser.id && p.productId === selectedIDNProduct);
    if (existing) {
      updateIDNSettlementPrice(existing.id, { settlementPrice: newSettlementPrice });
    } else {
      addIDNSettlementPrice({
        id: crypto.randomUUID(),
        userId: selectedIDNUser.id,
        productId: selectedIDNProduct,
        settlementPrice: newSettlementPrice
      });
    }
    setNewSettlementPrice(0);
    setSelectedIDNProduct("");
    showToast("Precio de liquidación guardado.");
  };

  const filteredIDNProducts = products.filter(p => 
    p.name.toLowerCase().includes(idnProductSearch.toLowerCase()) || 
    p.sku.toLowerCase().includes(idnProductSearch.toLowerCase())
  ).slice(0, 5);

  const handleRegisterEmployeeManual = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmployee.name || !newEmployee.password) return;
    
    const registered = registerEmployee(newEmployee.name, newEmployee.password);
    if (newEmployee.isIndependent || newEmployee.assignedBranchId) {
      updateUser(registered.id, {
        isIndependent: newEmployee.isIndependent,
        assignedBranchId: newEmployee.assignedBranchId || undefined,
        allowedBranches: newEmployee.assignedBranchId ? [newEmployee.assignedBranchId] : undefined
      });
    }
    setNewEmployee({ name: "", password: "", isIndependent: false, assignedBranchId: "" });
    showToast("Empleado registrado con éxito. Ya aparecerá en el punto de venta.");
  };

  const handleManualSync = async () => {
    if (isSyncing) return;
    setIsSyncing(true);
    try {
      const { processOfflineQueue, getOfflineQueueCount } = await import('../services/offlineSync');
      const count = getOfflineQueueCount();
      if (count > 0) {
        addNotification(`Sincronizando ${count} operaciones pendientes...`, 'info');
        const res = await processOfflineQueue();
        if (res.processed) addNotification(`Cola procesada: ${res.processed} operaciones.`, 'success');
        if (res.failed) addNotification(`Error en ${res.failed} operaciones.`, 'error');
      }
      const cloudResult = await syncWithSupabase();
      const remaining = getOfflineQueueCount();
      if (remaining > 0 || cloudResult?.success === false) {
        showToast(`Sincronización incompleta: quedan ${remaining} operaciones pendientes.`, "error");
      } else {
        showToast("Sincronización completa con Supabase.");
      }
    } catch (e) {
      showToast("Error al sincronizar con la nube.", "error");
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-500 max-w-5xl mx-auto pb-8 relative">
      {/* In-App Toast Notification */}
      {toast && (
        <div className="fixed top-4 right-4 z-[200] max-w-md animate-in slide-in-from-top-4 fade-in duration-300">
          <div className={cn(
            "p-4 rounded-2xl shadow-2xl border flex items-center gap-3 backdrop-blur-md",
            toast.type === 'success' ? "bg-emerald-950/95 text-emerald-100 border-emerald-800/80 shadow-emerald-900/30" :
            toast.type === 'error' ? "bg-rose-950/95 text-rose-100 border-rose-800/80 shadow-rose-900/30" :
            "bg-slate-900/95 text-white border-slate-700 shadow-slate-900/30"
          )}>
            {toast.type === 'success' && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />}
            {toast.type === 'error' && <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />}
            {toast.type === 'info' && <Database className="w-5 h-5 text-indigo-400 shrink-0" />}
            <div className="flex-1 text-xs font-bold leading-snug">{toast.message}</div>
            <button onClick={() => setToast(null)} className="p-1 hover:bg-white/10 rounded-lg transition-colors">
              <X className="w-4 h-4 text-slate-400 hover:text-white" />
            </button>
          </div>
        </div>
      )}

      {/* Header and Sync Status */}
      <div className="flex flex-col gap-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-secondary p-4 rounded-3xl border border-base shadow-sm">
          <div>
            <h2 className="text-xl font-black text-primary uppercase tracking-tight flex items-center gap-2">
              <SettingsIcon size={20} className="text-indigo-600" />
              Configuración
            </h2>
            <p className="text-[10px] font-bold text-muted uppercase tracking-widest">Sistema y Preferencias</p>
          </div>
          <button
            onClick={handleManualSync}
            disabled={isSyncing || !navigator.onLine}
            className={cn(
              "w-full sm:w-auto px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 shadow-sm active:scale-95 disabled:opacity-50",
              isSyncing ? "bg-slate-100 text-slate-400" : "bg-indigo-600 text-white hover:bg-indigo-700 shadow-indigo-600/20"
            )}
          >
            {isSyncing ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <CloudUpload size={14} />}
            {isSyncing ? "Sincronizando..." : "Sincronizar Nube"}
          </button>
        </div>

        {/* Linear Tabs for Sections */}
        <div className="flex items-center gap-1 bg-secondary p-1 rounded-xl border border-base shrink-0 w-full overflow-x-auto custom-scrollbar shadow-xs scroll-smooth">
          {[
            { id: 'connectivity', label: 'Conexión', icon: Wifi },
            { id: 'company', label: 'Empresa', icon: Store },
            { id: 'branches', label: 'Almacenes', icon: Building2 },
            { id: 'categories', label: 'Categorías', icon: LayoutGrid },
            { id: 'employees', label: 'Empleados', icon: Users },
            { id: 'advanced', label: 'Avanzado', icon: AlertTriangle },
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button 
                key={tab.id} 
                onClick={() => setActiveTab(tab.id as any)} 
                className={cn(
                  "px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all flex items-center gap-1.5 shrink-0 whitespace-nowrap cursor-pointer",
                  isActive 
                    ? "bg-indigo-600 text-white shadow-xs" 
                    : "text-secondary hover:text-primary hover:bg-subtle"
                )}
              >
                <Icon size={13} />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {/* Conectividad y Sincronización */}
        {activeTab === 'connectivity' && (
          <div className="space-y-4">
            <div className="bg-secondary rounded-2xl shadow-sm border border-indigo-200 dark:border-indigo-900/30 p-5 space-y-4">
              <div className="flex items-center gap-3 border-b border-indigo-50 dark:border-indigo-950/30 pb-3">
                <div className="bg-indigo-50 dark:bg-indigo-950/50 p-2 rounded-lg text-indigo-600 dark:text-indigo-400">
                  <Wifi size={16} />
                </div>
                <div>
                  <h3 className="text-xs font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">Conectividad y Nube</h3>
                  <p className="text-[8px] font-bold text-muted uppercase tracking-tight">Control de guardado offline y transferencia de datos</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <label className="flex items-center justify-between p-3.5 bg-primary border border-base rounded-2xl cursor-pointer group hover:border-indigo-300 transition-all">
                    <div className="flex-1 pr-4">
                      <div className="flex items-center gap-2">
                        <CloudUpload size={14} className="text-indigo-600" />
                        <span className="text-[11px] font-black text-primary uppercase">Sincronización Manual</span>
                      </div>
                      <p className="text-[9px] text-muted font-medium mt-1 leading-tight">
                        Si se activa, el sistema NO subirá los datos automáticamente al recuperar internet. Deberás presionar "Sincronizar Nube" manualmente para evitar errores por caídas de conexión.
                      </p>
                    </div>
                    <div className="relative inline-flex items-center">
                      <input 
                        type="checkbox" 
                        className="sr-only peer"
                        checked={config.manualOfflineSync === true}
                        onChange={e => {
                          const newConfig = { ...config, manualOfflineSync: e.target.checked };
                          setConfig(newConfig);
                          updateStoreConfig(newConfig);
                          showToast(`Sincronización manual ${e.target.checked ? 'activada' : 'desactivada'}.`, 'info');
                        }}
                      />
                      <div className="w-11 h-6 bg-slate-200 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                    </div>
                  </label>

                  <div className="bg-amber-50/50 dark:bg-amber-950/10 p-3.5 rounded-2xl border border-amber-100 dark:border-amber-900/30 flex items-start gap-3">
                    <AlertTriangle size={16} className="text-amber-600 shrink-0 mt-0.5" />
                    <p className="text-[9px] text-amber-700 dark:text-amber-400 font-medium leading-relaxed">
                      <strong>Recomendación:</strong> Activa el modo manual en zonas con internet inestable. El sistema guardará todo en una cola local protegida y solo subirá cuando tú lo decidas, garantizando la integridad de cada transacción.
                    </p>
                  </div>
                </div>

                <div className="bg-primary p-4 rounded-2xl border border-base border-dashed flex flex-col justify-between">
                  <div>
                    <h4 className="text-[10px] font-black text-primary uppercase flex items-center gap-2">
                      <Database size={14} className="text-indigo-600" />
                      Estado de la Base de Datos
                    </h4>
                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <div className="p-3 bg-secondary rounded-xl border border-base">
                        <p className="text-[8px] font-black text-muted uppercase">Productos</p>
                        <p className="text-base font-black text-primary">{products.length}</p>
                      </div>
                      <div className="p-3 bg-secondary rounded-xl border border-base">
                        <p className="text-[8px] font-black text-muted uppercase">Ventas</p>
                        <p className="text-base font-black text-primary">{transactions.length}</p>
                      </div>
                    </div>
                  </div>
                  <p className="text-[8px] text-muted uppercase tracking-wider text-center mt-4 font-bold">
                    Conectado a Supabase: <span className="text-emerald-500">{navigator.onLine ? 'SÍ' : 'NO (OFFLINE)'}</span>
                  </p>
                </div>
              </div>
            </div>

            {/* Offline Backup & Restore Section (Moved here) */}
            <div className="bg-secondary rounded-2xl shadow-sm border border-base p-5 space-y-4">
              <div className="flex items-center gap-3 border-b border-base pb-3">
                <div className="bg-emerald-50 dark:bg-emerald-950/30 p-2.5 rounded-xl text-emerald-600 dark:text-emerald-400">
                  <Save size={20} />
                </div>
                <div>
                  <h3 className="text-xs font-black text-primary uppercase tracking-wider">Copia de Seguridad Offline</h3>
                  <p className="text-[9px] font-bold text-muted uppercase tracking-tight">Exportar e importar base de datos local</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 bg-subtle rounded-2xl border border-base">
                  <div className="flex items-center gap-2 mb-2">
                    <CloudDownload className="w-4 h-4 text-indigo-500" />
                    <span className="text-[10px] font-black uppercase text-primary tracking-widest">Generar Backup</span>
                  </div>
                  <p className="text-[9px] text-muted mb-4 font-bold leading-tight">Descarga toda tu información local en un archivo JSON.</p>
                  <button
                    onClick={() => {
                      const data = exportData();
                      const blob = new Blob([data], { type: 'application/json' });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url;
                      a.download = `backup_pos_${new Date().toISOString().split('T')[0]}.json`;
                      document.body.appendChild(a);
                      a.click();
                      document.body.removeChild(a);
                      URL.revokeObjectURL(url);
                      showToast("Copia de seguridad generada y descargada");
                    }}
                    className="w-full py-2 bg-indigo-600 text-white rounded-xl text-[9px] font-black uppercase tracking-wider hover:bg-indigo-700 transition-all cursor-pointer shadow-md"
                  >
                    Exportar Datos
                  </button>
                </div>

                <div className="p-4 bg-subtle rounded-2xl border border-base">
                  <div className="flex items-center gap-2 mb-2">
                    <CloudUpload className="w-4 h-4 text-indigo-500" />
                    <span className="text-[10px] font-black uppercase text-primary tracking-widest">Restaurar Sistema</span>
                  </div>
                  <p className="text-[9px] text-muted mb-4 font-bold leading-tight">Carga un archivo de respaldo previo para sobrescribir los datos.</p>
                  <label className="block">
                    <input
                      type="file"
                      accept=".json"
                      className="hidden"
                      id="backup-upload"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        if (window.confirm("¿Restaurar datos? Se perderá lo que no esté en el archivo.")) {
                          setIsLoading(true);
                          const reader = new FileReader();
                          reader.onload = async (ev) => {
                            const result = await importData(ev.target?.result as string);
                            if (result.success) {
                              showToast("Sistema restaurado");
                              setTimeout(() => window.location.reload(), 1000);
                            } else showToast(`Error: ${result.error}`, "error");
                          };
                          reader.readAsText(file);
                        }
                      }}
                    />
                    <div className="w-full py-2 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-[9px] font-black uppercase tracking-wider text-center cursor-pointer hover:bg-slate-300 transition-all border border-base">
                      Importar JSON
                    </div>
                  </label>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Datos de la Empresa y Apariencia */}
        {activeTab === 'company' && (
          <div className="space-y-4">
            <div className="bg-secondary rounded-2xl shadow-sm border border-base p-5 space-y-4">
              <div className="flex items-center gap-3 border-b border-base pb-3">
                <div className="bg-indigo-50 dark:bg-indigo-950/50 p-2 rounded-lg text-indigo-600 dark:text-indigo-400">
                  <Store size={16} />
                </div>
                <div>
                  <h3 className="text-xs font-black text-primary uppercase tracking-wider">Datos de la Empresa</h3>
                  <p className="text-[8px] font-bold text-muted uppercase tracking-tight">Información para tickets y reportes</p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-muted uppercase px-1">Nombre del Negocio</label>
                  <input 
                    type="text" 
                    value={config.storeName}
                    onChange={e => setConfig({ ...config, storeName: e.target.value })}
                    className="w-full px-4 py-2.5 bg-primary border border-base rounded-xl text-xs font-bold text-primary outline-none focus:ring-1 focus:ring-indigo-500 shadow-sm"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-muted uppercase px-1">Teléfono</label>
                  <input 
                    type="text" 
                    value={config.phone}
                    onChange={e => setConfig({ ...config, phone: e.target.value })}
                    className="w-full px-4 py-2.5 bg-primary border border-base rounded-xl text-xs font-bold text-primary outline-none focus:ring-1 focus:ring-indigo-500 shadow-sm"
                  />
                </div>
                <div className="space-y-1.5 md:col-span-2">
                  <label className="text-[10px] font-black text-muted uppercase px-1">Dirección</label>
                  <input 
                    type="text" 
                    value={config.address}
                    onChange={e => setConfig({ ...config, address: e.target.value })}
                    className="w-full px-4 py-2.5 bg-primary border border-base rounded-xl text-xs font-bold text-primary outline-none focus:ring-1 focus:ring-indigo-500 shadow-sm"
                  />
                </div>
              </div>
              <div className="pt-2 flex justify-end">
                <button 
                  onClick={handleSaveConfig}
                  className="px-6 py-2 bg-indigo-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-md flex items-center gap-2 cursor-pointer"
                >
                  <Save size={14} />
                  Guardar Cambios
                </button>
              </div>
            </div>

            {/* Tasas de Cambio (Moved here) */}
            <div className="bg-secondary rounded-2xl shadow-sm border border-base p-5 space-y-4">
              <div className="flex items-center justify-between border-b border-base pb-3 gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="bg-emerald-50 p-1.5 rounded-lg text-emerald-600 shrink-0">
                    <DollarSign className="w-4 h-4" />
                  </div>
                  <h3 className="text-xs font-black text-primary uppercase tracking-wider truncate">Tasas de Cambio</h3>
                </div>
                <span className="text-[9px] font-black uppercase tracking-wider bg-emerald-100 dark:bg-emerald-900/40 text-emerald-800 dark:text-emerald-300 px-2 py-0.5 rounded-md shrink-0">
                  Base: {baseCurrency.code}
                </span>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {currencies
                  .filter(currency => ['CUP', 'USD', 'EUR'].includes(currency.code))
                  .map(currency => {
                    const isBase = currency.code === baseCurrency.code;
                    return (
                      <div key={currency.code} className={cn("px-3 py-2 rounded-xl border flex items-center justify-between gap-3", isBase ? "bg-subtle border-base" : "bg-primary border-base shadow-xs")}>
                        <div className="flex items-center gap-2 shrink-0">
                          <span className="w-6 h-6 rounded-md bg-secondary text-primary font-black text-[11px] flex items-center justify-center shrink-0 border border-base">
                            {currency.symbol || (currency.code === 'EUR' ? '€' : '$')}
                          </span>
                          <span className="text-xs font-black text-primary uppercase">{currency.code}</span>
                        </div>
                        <div className="flex items-center gap-1.5 justify-end">
                          {isBase ? (
                            <span className="text-[9px] font-black uppercase text-emerald-600">1.00 (Base)</span>
                          ) : (
                            <div className="flex items-center bg-subtle border border-base rounded-lg px-2 py-0.5">
                              <input
                                type="number"
                                step="0.01"
                                value={rates[currency.code] ?? ''}
                                onChange={(e) => setRates({ ...rates, [currency.code]: parseFloat(e.target.value) || 0 })}
                                className="w-12 bg-transparent text-right text-xs font-black text-primary outline-none"
                              />
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
              </div>
              <button onClick={handleSaveRates} className="w-full py-2 bg-emerald-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-emerald-700 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md">
                <Save size={14} /> Actualizar Tasas
              </button>
            </div>

            {/* Apariencia (Moved here) */}
            <div className="bg-secondary rounded-2xl shadow-sm border border-base p-5 space-y-4">
              <div className="flex items-center gap-3 border-b border-base pb-3">
                <div className="bg-indigo-600 p-2 rounded-lg text-white">
                  <Sparkles size={16} />
                </div>
                <div>
                  <h3 className="text-xs font-black text-primary uppercase tracking-wider">Apariencia</h3>
                  <p className="text-[8px] font-bold text-muted uppercase tracking-tight">Tema del sistema</p>
                </div>
              </div>
              <div className="flex items-center justify-between bg-subtle p-4 rounded-2xl border border-base">
                <p className="text-xs font-bold text-primary">Modo Oscuro</p>
                <div className="flex bg-secondary p-1 rounded-xl border border-base">
                  <button onClick={() => { const nc = {...config, darkMode:false}; setConfig(nc); updateStoreConfig(nc); }} className={cn("px-4 py-1.5 rounded-lg text-[9px] font-black uppercase transition-all cursor-pointer", !config.darkMode ? "bg-indigo-600 text-white" : "text-muted")}>Luz</button>
                  <button onClick={() => { const nc = {...config, darkMode:true}; setConfig(nc); updateStoreConfig(nc); }} className={cn("px-4 py-1.5 rounded-lg text-[9px] font-black uppercase transition-all cursor-pointer", config.darkMode ? "bg-indigo-600 text-white" : "text-muted")}>Noche</button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Categorías */}
        {activeTab === 'categories' && (
          <div className="bg-secondary rounded-2xl shadow-sm border border-base p-5 space-y-4">
            <div className="flex items-center gap-3 border-b border-base pb-3">
              <div className="bg-amber-50 dark:bg-amber-950/30 p-2 rounded-lg text-amber-600 dark:text-amber-400">
                <LayoutGrid size={16} />
              </div>
              <div>
                <h3 className="text-xs font-black text-primary uppercase tracking-wider">Categorías de Productos</h3>
                <p className="text-[8px] font-bold text-muted uppercase tracking-tight">Clasificación de inventario para reportes</p>
              </div>
            </div>
            {/* ... Categories content ... */}
          </div>
        )}

        {/* Empleados */}
        {activeTab === 'employees' && (
          <div className="bg-secondary rounded-2xl shadow-sm border border-base p-5 space-y-4">
            <div className="flex items-center gap-3 border-b border-base pb-3">
              <div className="bg-indigo-50 dark:bg-indigo-950/50 p-2 rounded-lg text-indigo-600 dark:text-indigo-400">
                <Users size={16} />
              </div>
              <div>
                <h3 className="text-xs font-black text-primary uppercase tracking-wider">Gestión de Empleados</h3>
                <p className="text-[8px] font-bold text-muted uppercase tracking-tight">Permisos y salarios por turno</p>
              </div>
            </div>
            {/* ... Employees content ... */}
          </div>
        )}

        {/* Avanzado / Reset */}
        {activeTab === 'advanced' && (
          <div className="bg-secondary rounded-2xl shadow-sm border border-rose-100 dark:border-rose-900/30 p-5 space-y-4">
             <div className="flex items-center gap-3 border-b border-rose-50 dark:border-rose-950/30 pb-3">
              <div className="bg-rose-50 dark:bg-rose-950/50 p-2 rounded-lg text-rose-600 dark:text-rose-400">
                <AlertTriangle size={16} />
              </div>
              <div>
                <h3 className="text-xs font-black text-rose-600 dark:text-rose-400 uppercase tracking-wider">Avanzado</h3>
                <p className="text-[8px] font-bold text-muted uppercase tracking-tight">Acciones críticas del sistema</p>
              </div>
            </div>
            <div className="p-4 bg-rose-50/50 dark:bg-rose-950/10 rounded-2xl border border-rose-100 dark:border-rose-900/30">
               <h4 className="text-[10px] font-black text-rose-600 uppercase mb-2">Zona de Peligro</h4>
               <p className="text-[9px] text-rose-700 dark:text-rose-400 font-medium leading-relaxed mb-4">
                 Las siguientes acciones son irreversibles. Borrarán todos los datos locales de este dispositivo. Asegúrate de tener una copia de seguridad o de que los datos estén sincronizados con la nube.
               </p>
               <div className="flex flex-col sm:flex-row gap-3">
                 <button 
                   onClick={() => setShowConfirmReset(true)}
                   className="px-6 py-2.5 bg-rose-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-rose-700 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md"
                 >
                   <Trash2 size={14} /> Borrar Datos Locales
                 </button>
               </div>
            </div>
          </div>
        )}
      </div>

      {/* In-App User Deletion Confirmation Modal */}
      {userToDelete && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-sm z-[150] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-5 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
                <Trash2 className="w-6 h-6" />
              </div>
              <h3 className="text-base font-black text-slate-900 uppercase">¿Desactivar Empleado?</h3>
              <p className="text-xs text-slate-600">
                ¿Desactivar a <span className="font-bold text-slate-900">{userToDelete.name}</span>? El empleado perderá acceso, pero se conservarán su historial y operaciones.
              </p>
            </div>
            <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setUserToDelete(null)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-200 transition-all cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={confirmDeleteUserAction}
                className="px-5 py-2 rounded-xl text-xs font-black uppercase tracking-wider bg-rose-600 hover:bg-rose-700 text-white shadow-lg shadow-rose-600/20 transition-all cursor-pointer"
              >
                Sí, Desactivar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* In-App Branch Deletion Confirmation Modal */}
      {branchToDelete && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-sm z-[150] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-5 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
                <Store className="w-6 h-6" />
              </div>
              <h3 className="text-base font-black text-slate-900 uppercase">¿Eliminar Sucursal?</h3>
              <p className="text-xs text-slate-600">
                ¿Estás seguro de que deseas eliminar la sucursal <span className="font-bold text-slate-900">"{branchToDelete.name}"</span>?
              </p>
            </div>
            <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setBranchToDelete(null)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-200 transition-all cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={confirmDeleteBranchAction}
                className="px-5 py-2 rounded-xl text-xs font-black uppercase tracking-wider bg-rose-600 hover:bg-rose-700 text-white shadow-lg shadow-rose-600/20 transition-all cursor-pointer"
              >
                Sí, Eliminar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* In-App Category Deletion Confirmation Modal */}
      {categoryToDelete && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-sm z-[150] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-5 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
                <Trash2 className="w-6 h-6" />
              </div>
              <h3 className="text-base font-black text-slate-900 uppercase">¿Eliminar Categoría?</h3>
              <p className="text-xs text-slate-600">
                ¿Estás seguro de que deseas eliminar la categoría <span className="font-bold text-slate-900">"{categoryToDelete.name}"</span>?
              </p>
            </div>
            <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setCategoryToDelete(null)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-200 transition-all cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={confirmDeleteCategoryAction}
                className="px-5 py-2 rounded-xl text-xs font-black uppercase tracking-wider bg-rose-600 hover:bg-rose-700 text-white shadow-lg shadow-rose-600/20 transition-all cursor-pointer"
              >
                Sí, Eliminar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Comprehensive Employee Configuration Modal */}
      {selectedUserForConfig && (
        <div className="fixed inset-0 bg-slate-950/40 dark:bg-slate-950/80 backdrop-blur-sm z-[100] flex items-center justify-center p-3 sm:p-4">
          <div className="bg-secondary w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] border border-base animate-in fade-in zoom-in-95 duration-200">
            <div className="bg-indigo-900 dark:bg-indigo-950/50 p-4 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className={cn("p-2 rounded-xl", selectedUserForConfig.isIndependent ? "bg-amber-500/20 text-amber-400" : "bg-indigo-500/20 text-indigo-400")}>
                  {selectedUserForConfig.isIndependent ? <Package size={20} /> : <Users size={20} />}
                </div>
                <div>
                  <h3 className="text-xs font-black uppercase tracking-wider">Configuración de Empleado</h3>
                  <p className="text-[10px] font-bold text-indigo-200/70 uppercase">{selectedUserForConfig.name}</p>
                </div>
              </div>
              <button 
                onClick={() => setSelectedUserForConfig(null)} 
                className="p-1.5 hover:bg-white/10 rounded-lg text-white/60 hover:text-white transition-colors cursor-pointer"
              >
                <X size={20} />
              </button>
            </div>

            <div className="p-4 sm:p-5 overflow-y-auto custom-scrollbar space-y-5 flex-1 bg-secondary">
              {/* Type and Role Settings */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="bg-subtle p-3.5 rounded-xl border border-base space-y-2">
                  <span className="text-[8px] font-black text-muted uppercase tracking-widest block">Tipo de Vendedor</span>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const updated = { ...selectedUserForConfig, isIndependent: false };
                        setSelectedUserForConfig(updated);
                        updateUser(selectedUserForConfig.id, { isIndependent: false });
                      }}
                      className={cn(
                        "flex-1 py-2 px-3 rounded-lg font-black text-[9px] uppercase transition-all flex items-center justify-center gap-1.5 cursor-pointer",
                        !selectedUserForConfig.isIndependent ? "bg-indigo-600 text-white shadow-sm" : "bg-primary text-muted border border-base"
                      )}
                    >
                      <Users size={14} />
                      Fijo
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const updated = { ...selectedUserForConfig, isIndependent: true };
                        setSelectedUserForConfig(updated);
                        updateUser(selectedUserForConfig.id, { isIndependent: true });
                      }}
                      className={cn(
                        "flex-1 py-2 px-3 rounded-lg font-black text-[9px] uppercase transition-all flex items-center justify-center gap-1.5 cursor-pointer",
                        selectedUserForConfig.isIndependent ? "bg-amber-600 text-white shadow-sm" : "bg-primary text-muted border border-base"
                      )}
                    >
                      <Package size={14} />
                      IDN
                    </button>
                  </div>
                </div>

                {/* Base Salary */}
                <div className="bg-subtle p-3.5 rounded-xl border border-base space-y-2">
                  <span className="text-[8px] font-black text-muted uppercase tracking-widest block">
                    {selectedUserForConfig.isIndependent ? 'Comisión Base (CUP)' : 'Salario por Turno (CUP)'}
                  </span>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[10px] font-black text-muted">{baseCurrency.symbol}</span>
                    <input 
                      type="number"
                      min="0"
                      step="0.01"
                      value={employeeSalaries[selectedUserForConfig.id] ?? (selectedUserForConfig.baseSalary || 0)}
                      onChange={e => {
                        const val = Number(e.target.value);
                        setEmployeeSalaries({ ...employeeSalaries, [selectedUserForConfig.id]: val });
                        updateUser(selectedUserForConfig.id, { baseSalary: val });
                      }}
                      className="w-full pl-8 pr-3 py-2 bg-primary border border-base rounded-lg text-xs font-black text-primary outline-none focus:ring-1 focus:ring-indigo-500 transition-all"
                      placeholder="0.00"
                    />
                  </div>
                </div>

                {/* Password Section */}
                <div className="bg-subtle p-3.5 rounded-xl border border-base space-y-2 sm:col-span-2">
                  <span className="text-[8px] font-black text-muted uppercase tracking-widest block">
                    Contraseña de Acceso (POS)
                  </span>
                  <input 
                    type="text"
                    value={selectedUserForConfig.password || ''}
                    onChange={e => {
                      const newPass = e.target.value;
                      const updated = { ...selectedUserForConfig, password: newPass };
                      setSelectedUserForConfig(updated);
                      updateUser(selectedUserForConfig.id, { password: newPass });
                    }}
                    className="w-full px-3 py-2 bg-primary border border-base rounded-lg text-xs font-bold text-primary outline-none focus:ring-1 focus:ring-indigo-500 transition-all"
                    placeholder="Contraseña del empleado"
                  />
                </div>
              </div>

              {/* Branch Permissions Section */}
              <div className="bg-subtle p-4 rounded-xl border border-base space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Building2 size={16} className="text-indigo-600" />
                    <h4 className="text-[10px] font-black text-primary uppercase">
                      {selectedUserForConfig.isIndependent ? 'Almacén Asignado' : 'Permisos de Sucursales'}
                    </h4>
                  </div>
                </div>

                {selectedUserForConfig.isIndependent ? (
                  <div>
                    <select
                      value={selectedUserForConfig.assignedBranchId || ""}
                      onChange={(e) => {
                        const bId = e.target.value;
                        const updated = { 
                          ...selectedUserForConfig, 
                          assignedBranchId: bId,
                          allowedBranches: bId ? [bId] : undefined 
                        };
                        setSelectedUserForConfig(updated);
                        updateUser(selectedUserForConfig.id, { 
                          assignedBranchId: bId,
                          allowedBranches: bId ? [bId] : undefined
                        });
                      }}
                      className="w-full px-3.5 py-2.5 bg-primary border border-base rounded-xl text-xs font-bold text-primary outline-none focus:ring-1 focus:ring-indigo-500 cursor-pointer"
                    >
                      <option value="">Seleccionar Almacén</option>
                      {branches.map(b => (
                        <option key={b.id} value={b.id}>{b.name}</option>
                      ))}
                    </select>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                    {branches.map(branch => {
                      const isAllowed = selectedUserForConfig.allowedBranches?.includes(branch.id) ?? true;
                      return (
                        <label 
                          key={branch.id} 
                          className={cn(
                            "flex items-center gap-2.5 p-2.5 rounded-xl border transition-all cursor-pointer",
                            isAllowed 
                              ? "bg-primary border-indigo-200 dark:border-indigo-500/50 shadow-sm" 
                              : "bg-subtle border-base opacity-40 grayscale"
                          )}
                        >
                          <input 
                            type="checkbox"
                            checked={isAllowed}
                            onChange={(e) => {
                              const current = selectedUserForConfig.allowedBranches ?? branches.map(b => b.id);
                              const newAllowed = e.target.checked 
                                ? [...current, branch.id]
                                : current.filter(id => id !== branch.id);
                              
                              const updated = { ...selectedUserForConfig, allowedBranches: newAllowed };
                              setSelectedUserForConfig(updated);
                              updateUser(selectedUserForConfig.id, { allowedBranches: newAllowed });
                            }}
                            className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500"
                          />
                          <div>
                            <span className="text-[10px] font-black uppercase text-primary block">{branch.name}</span>
                            <span className={cn("text-[8px] font-bold", isAllowed ? "text-indigo-600" : "text-muted")}>
                              {isAllowed ? 'Autorizado' : 'Sin Acceso'}
                            </span>
                          </div>
                        </label>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* IDN Custom Settlement Prices */}
              {selectedUserForConfig.isIndependent && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <DollarSign size={16} className="text-amber-600" />
                      <h4 className="text-[10px] font-black text-primary uppercase">Precios de Liquidación (CUP)</h4>
                    </div>
                  </div>

                  <div className="bg-subtle p-3.5 rounded-xl border border-base space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <div className="relative">
                        <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
                        <input 
                          type="text" 
                          placeholder="Buscar producto..."
                          value={idnProductSearch}
                          onChange={(e) => setIdnProductSearch(e.target.value)}
                          className="w-full pl-9 pr-4 py-2 bg-primary border border-base rounded-lg text-xs font-bold text-primary outline-none focus:ring-1 focus:ring-indigo-500"
                        />
                        {idnProductSearch && filteredIDNProducts.length > 0 && (
                          <div className="absolute top-full left-0 right-0 mt-1 bg-secondary border border-base rounded-xl shadow-xl z-20 overflow-hidden max-h-40 overflow-y-auto">
                            {filteredIDNProducts.map(p => (
                              <button
                                key={p.id}
                                onClick={() => {
                                  setSelectedIDNProduct(p.id);
                                  setIdnProductSearch("");
                                  const existing = idnSettlementPrices.find(sp => sp.userId === selectedUserForConfig.id && sp.productId === p.id);
                                  if (existing) setNewSettlementPrice(existing.settlementPrice);
                                }}
                                className="w-full px-3.5 py-2 text-left hover:bg-subtle flex items-center justify-between transition-colors border-b border-base last:border-0 cursor-pointer"
                              >
                                <span className="text-[10px] font-black uppercase text-primary">{p.name}</span>
                                <span className="text-[9px] font-bold text-muted">{p.sku}</span>
                              </button>
                            ))}
                          </div>
                        )}
                      </div>

                      <div className="flex gap-2">
                        <div className="relative flex-1">
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[10px] font-black text-muted">$</span>
                          <input 
                            type="number" 
                            placeholder="Precio"
                            value={newSettlementPrice || ""}
                            onChange={(e) => setNewSettlementPrice(Number(e.target.value))}
                            className="w-full pl-7 pr-3 py-2 bg-primary border border-base rounded-lg text-xs font-bold text-primary outline-none focus:ring-1 focus:ring-indigo-500"
                          />
                        </div>
                        <button 
                          onClick={() => {
                            if (!selectedUserForConfig || !selectedIDNProduct || newSettlementPrice <= 0) return;
                            const existing = idnSettlementPrices.find(p => p.userId === selectedUserForConfig.id && p.productId === selectedIDNProduct);
                            if (existing) {
                              updateIDNSettlementPrice(existing.id, { settlementPrice: newSettlementPrice });
                            } else {
                              addIDNSettlementPrice({
                                id: crypto.randomUUID(),
                                userId: selectedUserForConfig.id,
                                productId: selectedIDNProduct,
                                settlementPrice: newSettlementPrice
                              });
                            }
                            setNewSettlementPrice(0);
                            setSelectedIDNProduct("");
                          }}
                          disabled={!selectedIDNProduct || newSettlementPrice <= 0}
                          className="bg-amber-600 text-white px-4 rounded-lg font-black text-[9px] uppercase transition-all shadow-sm disabled:opacity-40 cursor-pointer"
                        >
                          Asignar
                        </button>
                      </div>
                    </div>

                    {selectedIDNProduct && (
                      <div className="flex items-center gap-2 px-1">
                        <Package size={14} className="text-amber-600" />
                        <span className="text-[9px] font-black uppercase text-amber-600">
                          {products.find(p => p.id === selectedIDNProduct)?.name}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* List of custom prices */}
                  <div className="space-y-1.5 max-h-48 overflow-y-auto custom-scrollbar pr-1">
                    {idnSettlementPrices.filter(p => p.userId === selectedUserForConfig.id).map(p => {
                      const prod = products.find(pr => pr.id === p.productId);
                      return (
                        <div key={p.id} className="bg-primary p-2.5 rounded-xl border border-base flex items-center justify-between gap-3 shadow-sm">
                          <div className="min-w-0 flex-1">
                            <p className="text-[10px] font-black text-primary uppercase truncate">{prod?.name || 'Producto'}</p>
                            <p className="text-[8px] font-bold text-muted uppercase">{prod?.sku}</p>
                          </div>
                          <div className="flex items-center gap-3">
                            <div className="text-right">
                              <p className="text-[10px] font-black text-indigo-600">{baseCurrency.symbol}{p.settlementPrice.toLocaleString()}</p>
                              <p className="text-[7px] font-bold text-muted uppercase">Liquidación</p>
                            </div>
                            <button 
                              onClick={() => deleteIDNSettlementPrice(p.id)}
                              className="p-1.5 text-muted hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-lg transition-all cursor-pointer"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                    {idnSettlementPrices.filter(p => p.userId === selectedUserForConfig.id).length === 0 && (
                      <div className="py-4 text-center bg-subtle rounded-xl border border-dashed border-base">
                        <p className="text-[9px] font-bold text-muted uppercase">Sin precios de liquidación personalizados</p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Action area */}
              <div className="pt-2 border-t border-base flex items-center justify-between">
                <button
                   type="button"
                   onClick={() => {
                     const userToDeleteTarget = selectedUserForConfig;
                     setSelectedUserForConfig(null);
                     if (userToDeleteTarget) {
                       setUserToDelete({ id: userToDeleteTarget.id, name: userToDeleteTarget.name });
                     }
                   }}
                   className="text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 px-3 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all flex items-center gap-1.5 cursor-pointer"
                 >
                   <Trash2 size={14} />
                   Eliminar
                 </button>

                <button 
                  type="button"
                  onClick={() => {
                    setSelectedUserForConfig(null);
                  }}
                  className="bg-indigo-600 text-white px-8 py-2.5 rounded-xl font-black text-[10px] uppercase transition-all shadow-md active:scale-95 cursor-pointer"
                >
                  Listo
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* IDN Quick Modal Fallback */}
      {selectedIDNUser && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="bg-slate-900 p-4 text-white flex items-center justify-between">
              <div>
                <h3 className="text-xs font-black uppercase">Gestión de Vendedor Independiente</h3>
                <p className="text-[9px] font-bold text-slate-400 uppercase">{selectedIDNUser.name}</p>
              </div>
              <button onClick={() => setSelectedIDNUser(null)} className="p-1 hover:bg-white/10 rounded-lg transition-colors cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto custom-scrollbar space-y-6">
              {/* Branch Assignment */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 bg-indigo-50 rounded-lg">
                    <Building2 className="w-3.5 h-3.5 text-indigo-600" />
                  </div>
                  <h4 className="text-[10px] font-black text-slate-900 uppercase">Almacén / Sucursal Asignada</h4>
                </div>
                <div className="grid grid-cols-1 gap-2">
                  <select 
                    value={selectedIDNUser.assignedBranchId || ""}
                    onChange={(e) => {
                      const branchVal = e.target.value;
                      setSelectedIDNUser({ ...selectedIDNUser, assignedBranchId: branchVal });
                      updateUser(selectedIDNUser.id, { 
                        assignedBranchId: branchVal,
                        allowedBranches: branchVal ? [branchVal] : undefined
                      });
                    }}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all appearance-none cursor-pointer"
                  >
                    <option value="">Sin almacén asignado</option>
                    {branches.map(b => (
                      <option key={b.id} value={b.id}>{b.name}</option>
                    ))}
                  </select>
                  <p className="text-[8px] font-bold text-slate-400 uppercase px-1">
                    * Este vendedor solo podrá operar y liquidar productos de este almacén.
                  </p>
                </div>
              </div>

              {/* Settlement Prices */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 bg-amber-50 rounded-lg">
                    <DollarSign className="w-3.5 h-3.5 text-amber-600" />
                  </div>
                  <h4 className="text-[10px] font-black text-slate-900 uppercase">Precios de Entrega (Liquidación CUP)</h4>
                </div>

                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
                      <input 
                        type="text" 
                        placeholder="Buscar producto..."
                        value={idnProductSearch}
                        onChange={(e) => setIdnProductSearch(e.target.value)}
                        className="w-full pl-9 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-bold outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all"
                      />
                      {idnProductSearch && filteredIDNProducts.length > 0 && (
                        <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-slate-200 rounded-xl shadow-xl z-10 overflow-hidden">
                          {filteredIDNProducts.map(p => (
                            <button
                              key={p.id}
                              onClick={() => {
                                setSelectedIDNProduct(p.id);
                                setIdnProductSearch("");
                                const existing = idnSettlementPrices.find(sp => sp.userId === selectedIDNUser.id && sp.productId === p.id);
                                if (existing) setNewSettlementPrice(existing.settlementPrice);
                              }}
                              className="w-full px-4 py-2 text-left hover:bg-slate-50 flex items-center justify-between transition-colors cursor-pointer"
                            >
                              <span className="text-[10px] font-black uppercase text-slate-700">{p.name}</span>
                              <span className="text-[9px] font-bold text-slate-400">{p.sku}</span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                    
                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[10px] font-black text-slate-400">$</span>
                        <input 
                          type="number" 
                          placeholder="Precio Entrega (CUP)"
                          value={newSettlementPrice || ""}
                          onChange={(e) => setNewSettlementPrice(Number(e.target.value))}
                          className="w-full pl-7 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-bold outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all"
                        />
                      </div>
                      <button 
                        onClick={handleAddIDNSettlement}
                        disabled={!selectedIDNProduct || newSettlementPrice <= 0}
                        className="bg-amber-600 hover:bg-amber-700 text-white px-4 rounded-xl font-black text-[10px] uppercase transition-all shadow-lg disabled:opacity-50 cursor-pointer"
                      >
                        Asignar
                      </button>
                    </div>
                  </div>

                  {selectedIDNProduct && (
                    <div className="flex items-center gap-2 px-1">
                      <Package className="w-3 h-3 text-indigo-500" />
                      <span className="text-[9px] font-black uppercase text-indigo-600">
                        {products.find(p => p.id === selectedIDNProduct)?.name}
                      </span>
                    </div>
                  )}
                </div>

                <div className="space-y-2 max-h-64 overflow-y-auto custom-scrollbar pr-1">
                  {idnSettlementPrices.filter(p => p.userId === selectedIDNUser.id).map(p => {
                    const product = products.find(prod => prod.id === p.productId);
                    return (
                      <div key={p.id} className="bg-white p-3 rounded-xl border border-slate-200 flex items-center justify-between gap-4 shadow-sm group">
                        <div className="min-w-0 flex-1">
                          <p className="text-[10px] font-black text-slate-900 uppercase truncate">{product?.name || 'Producto Eliminado'}</p>
                          <p className="text-[8px] font-bold text-slate-400 uppercase">{product?.sku}</p>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="text-right">
                            <p className="text-[10px] font-black text-amber-700">{baseCurrency.symbol}{p.settlementPrice.toLocaleString()} CUP</p>
                            <p className="text-[7px] font-bold text-slate-400 uppercase">Precio Liquidación</p>
                          </div>
                          <button 
                            onClick={() => deleteIDNSettlementPrice(p.id)}
                            className="p-2 text-slate-300 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                  {idnSettlementPrices.filter(p => p.userId === selectedIDNUser.id).length === 0 && (
                    <div className="py-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                      <p className="text-[9px] font-bold text-slate-400 uppercase">Sin precios específicos asignados</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end">
              <button 
                onClick={() => setSelectedIDNUser(null)}
                className="bg-slate-900 text-white px-8 py-2.5 rounded-xl font-black text-[10px] uppercase hover:bg-slate-800 transition-all shadow-lg cursor-pointer"
              >
                Cerrar y Guardar
              </button>
            </div>
          </div>
        </div>
      )}



      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Tasas de Cambio (Compacto Lineal: CUP, USD, EUR) */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-4 sm:p-5 space-y-3.5 min-w-0">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3 gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <div className="bg-emerald-50 p-1.5 rounded-lg text-emerald-600 shrink-0">
                <DollarSign className="w-4 h-4" />
              </div>
              <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider truncate">Tasas de Cambio</h3>
            </div>
            <span className="text-[9px] font-black uppercase tracking-wider bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-md shrink-0">
              Base: CUP
            </span>
          </div>
          
          <div className="space-y-2">
            {currencies
              .filter(currency => ['CUP', 'USD', 'EUR'].includes(currency.code))
              .map(currency => {
                const isBase = currency.code === 'CUP';
                return (
                  <div 
                    key={currency.code} 
                    className={cn(
                      "px-3 py-2 rounded-xl border transition-all flex items-center justify-between gap-3",
                      isBase ? "bg-slate-50 border-slate-200" : "bg-white border-slate-200 hover:border-indigo-300 shadow-xs"
                    )}
                  >
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="w-6 h-6 rounded-md bg-slate-100 text-slate-800 font-black text-[11px] flex items-center justify-center shrink-0 border border-slate-200 shadow-2xs">
                        {currency.symbol || (currency.code === 'EUR' ? '€' : '$')}
                      </span>
                      <span className="text-xs font-black text-slate-900 uppercase tracking-tight">
                        {currency.code}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 justify-end shrink-0">
                      {isBase ? (
                        <span className="inline-flex items-center gap-1 px-2 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg text-[9px] font-black uppercase tracking-wider">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                          1.00 (Base)
                        </span>
                      ) : (
                        <div className="flex items-center bg-slate-50 border border-slate-200 rounded-lg px-2 py-0.5 focus-within:ring-2 focus-within:ring-indigo-500/20 focus-within:border-indigo-500 transition-all">
                          <span className="text-[9px] font-black text-slate-400 mr-1 select-none">
                            1 {currency.code} =
                          </span>
                          <input
                            type="number"
                            step="0.01"
                            min="0"
                            value={rates[currency.code] ?? ''}
                            onChange={(e) => setRates({ ...rates, [currency.code]: parseFloat(e.target.value) || 0 })}
                            className="w-14 sm:w-16 bg-white border border-slate-200 rounded px-1.5 py-0.5 text-right text-xs font-black text-slate-900 outline-none focus:border-indigo-500"
                            placeholder="0.00"
                          />
                          <span className="text-[9px] font-black text-slate-600 ml-1 select-none">
                            CUP
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
          </div>

          <button 
            onClick={handleSaveRates}
            className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-md shadow-indigo-100 active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Save className="w-3.5 h-3.5" />
            Guardar Tasas
          </button>
        </div>

        {/* Categorías (Compact) */}
        <div className="bg-secondary rounded-2xl shadow-sm border border-base p-5 space-y-4">
          <div className="flex items-center gap-3 border-b border-base pb-3">
            <div className="bg-amber-50 dark:bg-amber-950/30 p-2 rounded-lg text-amber-600 dark:text-amber-400">
              <LayoutGrid size={16} />
            </div>
            <div>
              <h3 className="text-xs font-black text-primary uppercase tracking-wider">Categorías</h3>
              <p className="text-[8px] font-bold text-muted uppercase tracking-tight">Clasificación de Inventario</p>
            </div>
          </div>

          <div className="space-y-3">
            <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1 custom-scrollbar">
              {categories.map(cat => (
                <div key={cat.id} className="flex justify-between items-center bg-subtle p-2 rounded-xl border border-base group">
                  <div className="flex-1 min-w-0 mr-2">
                    <div className="text-[11px] font-black text-primary uppercase tracking-tight break-words leading-snug">{cat.name}</div>
                    <div className="text-[8px] font-bold text-muted uppercase tracking-wider">{cat.department}</div>
                  </div>
                  <div className="flex gap-1 shrink-0">
                    <button onClick={() => { setEditingCategory(cat); setNewCategory({ name: cat.name, department: cat.department }); }} className="p-1.5 text-muted hover:text-indigo-600 rounded-lg transition-colors cursor-pointer" title="Editar"><Edit size={13} /></button>
                    <button onClick={() => setCategoryToDelete({ id: cat.id, name: cat.name })} className="p-1.5 text-muted hover:text-rose-500 rounded-lg transition-colors cursor-pointer" title="Eliminar"><Trash2 size={13} /></button>
                  </div>
                </div>
              ))}
            </div>
            <div className="space-y-3">
              <div className="flex flex-col sm:flex-row gap-2">
                <input 
                  type="text" 
                  value={newCategory.name}
                  onChange={e => setNewCategory({ ...newCategory, name: e.target.value })}
                  placeholder="Categoría"
                  className="flex-[2] min-w-0 w-full px-3 py-2 bg-primary border border-base rounded-xl text-xs font-bold text-primary outline-none focus:ring-1 focus:ring-indigo-500 shadow-sm" 
                />
                <input 
                  type="text" 
                  value={newCategory.department}
                  onChange={e => setNewCategory({ ...newCategory, department: e.target.value })}
                  placeholder="Depto"
                  className="flex-1 min-w-0 w-full px-3 py-2 bg-primary border border-base rounded-xl text-xs font-bold text-primary outline-none focus:ring-1 focus:ring-indigo-500 shadow-sm" 
                />
                <button 
                  onClick={handleAddCategory} 
                  className="p-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 active:scale-95 transition-all flex items-center justify-center shadow-md shrink-0 cursor-pointer"
                >
                  {editingCategory ? <Save size={16} /> : <Plus size={16} />}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Sucursales (Branches) */}
        <div className="bg-secondary rounded-2xl shadow-sm border border-base p-5 space-y-4">
          <div className="flex items-center gap-3 border-b border-base pb-3">
            <div className="bg-indigo-50 dark:bg-indigo-950/30 p-2 rounded-lg text-indigo-600 dark:text-indigo-400">
              <Store size={16} />
            </div>
            <div>
              <h3 className="text-xs font-black text-primary uppercase tracking-wider">Sucursales</h3>
              <p className="text-[8px] font-bold text-muted uppercase tracking-tight">Gestión de Ubicaciones</p>
            </div>
          </div>

          <div className="space-y-3">
            <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1 custom-scrollbar">
              {branches.map(branch => (
                <div key={branch.id} className="flex justify-between items-center bg-subtle p-2 rounded-xl border border-base group">
                  <div className="text-[11px] font-black text-primary uppercase tracking-tight break-words leading-snug flex-1 min-w-0 mr-2">{branch.name}</div>
                  <div className="flex gap-1 shrink-0 ml-1">
                    <button onClick={() => { setEditingBranch(branch); setNewBranchName(branch.name); }} className="p-1.5 text-muted hover:text-indigo-600 rounded-lg transition-colors cursor-pointer" title="Editar"><Edit size={13} /></button>
                    {branches.length > 1 && (
                      <button onClick={() => setBranchToDelete({ id: branch.id, name: branch.name })} className="p-1.5 text-muted hover:text-rose-500 rounded-lg transition-colors cursor-pointer" title="Eliminar"><Trash2 size={13} /></button>
                    )}
                  </div>
                </div>
              ))}
            </div>
            <div className="space-y-3">
              <div className="flex gap-2">
                <input 
                  type="text" 
                  value={newBranchName}
                  onChange={e => setNewBranchName(e.target.value)}
                  placeholder="Nombre"
                  className="flex-1 min-w-0 px-3 py-2 bg-primary border border-base rounded-xl text-xs font-bold text-primary outline-none focus:ring-1 focus:ring-indigo-500" 
                />
                <button onClick={handleAddBranch} className="p-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 active:scale-95 transition-all shrink-0 cursor-pointer">
                  {editingBranch ? <Save size={16} /> : <Plus size={16} />}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Apariencia y Visibilidad (Mejorado para Miopía) */}
        <div className="bg-secondary rounded-2xl shadow-sm border border-base p-5 space-y-4 lg:col-span-3">
          <div className="flex items-center gap-3 border-b border-base pb-3">
            <div className="bg-indigo-600 p-2 rounded-lg text-white">
              <Sparkles size={16} />
            </div>
            <div>
              <h3 className="text-xs font-black text-primary uppercase tracking-wider">Apariencia y Visibilidad</h3>
              <p className="text-[8px] font-bold text-muted uppercase tracking-tight">Personalización del entorno de trabajo</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-6 bg-subtle p-6 rounded-2xl border border-base">
            <div className="flex-1 space-y-2">
              <div className="flex items-center gap-3">
                <div className="bg-primary text-indigo-600 p-2 rounded-xl shadow-sm border border-base">
                  {config.darkMode ? <Moon size={16} /> : <Sun size={16} />}
                </div>
                <div>
                  <h4 className="text-sm font-black text-primary uppercase tracking-tight">Experiencia Visual</h4>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="px-2 py-0.5 bg-indigo-100 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 text-[8px] font-black rounded-full uppercase tracking-wider border border-indigo-200 dark:border-indigo-800">
                      Enterprise Mode
                    </span>
                  </div>
                </div>
              </div>
              <p className="text-[11px] text-secondary leading-relaxed max-w-xl">
                Personaliza el entorno de trabajo. El modo oscuro utiliza una paleta de grises profundos diseñada para reducir la fatiga visual.
              </p>
            </div>

            <div className="shrink-0 flex flex-col items-end gap-3">
              <div className="bg-secondary p-1.5 rounded-2xl border border-base shadow-sm flex items-center gap-1">
                <button 
                  onClick={() => {
                    const newConfig = { ...config, darkMode: false };
                    setConfig(newConfig);
                    updateStoreConfig(newConfig);
                    showToast("Modo luz activado");
                  }}
                  className={cn(
                    "flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all cursor-pointer",
                    !config.darkMode ? "bg-indigo-600 text-white shadow-lg" : "text-muted hover:bg-subtle"
                  )}
                >
                  <Sun size={14} />
                  Luz
                </button>
                <button 
                  onClick={() => {
                    const newConfig = { ...config, darkMode: true };
                    setConfig(newConfig);
                    updateStoreConfig(newConfig);
                    showToast("Modo oscuro activado");
                  }}
                  className={cn(
                    "flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all cursor-pointer",
                    config.darkMode ? "bg-indigo-600 text-white shadow-lg" : "text-muted hover:bg-subtle"
                  )}
                >
                  <Moon size={14} />
                  Oscuro
                </button>
              </div>
              <p className="text-[9px] font-bold text-muted uppercase tracking-widest px-2">Selección de Tema</p>
            </div>
          </div>
        </div>

        {/* Offline Backup & Restore Section */}
        <div className="bg-secondary rounded-2xl shadow-sm border border-base p-5 space-y-4 lg:col-span-3">
          <div className="flex items-center gap-3 border-b border-base pb-3">
            <div className="bg-emerald-50 dark:bg-emerald-950/30 p-2.5 rounded-xl text-emerald-600 dark:text-emerald-400">
              <Save size={20} />
            </div>
            <div>
              <h3 className="text-xs font-black text-primary uppercase tracking-wider">Copia de Seguridad Offline</h3>
              <p className="text-[9px] font-bold text-muted uppercase tracking-tight">Descarga tus datos en un archivo JSON para restaurarlos manualmente cuando quieras</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 bg-slate-50 dark:bg-slate-900/40 rounded-2xl border border-base">
              <div className="flex items-center gap-2 mb-2">
                <CloudDownload className="w-4 h-4 text-indigo-500" />
                <span className="text-[10px] font-black uppercase text-primary tracking-widest">Generar Backup</span>
              </div>
              <p className="text-[9px] text-muted mb-4 font-bold">Crea un archivo con toda tu información local: productos, ventas, turnos y configuración.</p>
              <button
                onClick={() => {
                  const data = exportData();
                  const blob = new Blob([data], { type: 'application/json' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `backup_pos_${new Date().toISOString().split('T')[0]}.json`;
                  document.body.appendChild(a);
                  a.click();
                  document.body.removeChild(a);
                  URL.revokeObjectURL(url);
                  showToast("Copia de seguridad generada y descargada", "success");
                }}
                className="w-full py-2.5 bg-indigo-600 text-white rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-md active:scale-95"
              >
                Descargar Archivo JSON
              </button>
            </div>

            <div className="p-4 bg-slate-50 dark:bg-slate-900/40 rounded-2xl border border-base">
              <div className="flex items-center gap-2 mb-2">
                <CloudUpload className="w-4 h-4 text-emerald-500" />
                <span className="text-[10px] font-black uppercase text-primary tracking-widest">Restaurar Datos</span>
              </div>
              <p className="text-[9px] text-muted mb-4 font-bold">⚠️ ATENCIÓN: Al restaurar, se sobrescribirán todos los datos actuales por los del archivo.</p>
              
              <label className="block">
                <input
                  type="file"
                  accept=".json"
                  className="hidden"
                  id="backup-upload"
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;

                    if (window.confirm("¿Estás seguro de que deseas RESTAURAR los datos? Esta acción sobrescribirá TODO el sistema actual y sincronizará con la nube.")) {
                      setIsLoading(true);
                      const reader = new FileReader();
                      reader.onload = async (event) => {
                        const content = event.target?.result as string;
                        const result = await importData(content);
                        if (result.success) {
                          showToast("Sistema restaurado con éxito", "success");
                          setTimeout(() => window.location.reload(), 1500);
                        } else {
                          showToast(`Error: ${result.error}`, "error");
                        }
                        setIsLoading(false);
                      };
                      reader.readAsText(file);
                    }
                    e.target.value = ''; // Reset input
                  }}
                />
                <div 
                  onClick={() => document.getElementById('backup-upload')?.click()}
                  className="w-full py-2.5 bg-emerald-600 text-white rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-emerald-700 transition-all shadow-md active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
                >
                  {isLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <CloudUpload className="w-3.5 h-3.5" />}
                  Cargar y Restaurar
                </div>
              </label>
            </div>
          </div>
        </div>

        {/* Configuración de Ticket / Recibo */}
        <div className="bg-secondary rounded-2xl shadow-sm border border-base p-5 space-y-4 lg:col-span-3">
          <div className="flex items-center gap-3 border-b border-base pb-3">
            <div className="bg-indigo-50 dark:bg-indigo-950/30 p-2 rounded-lg text-indigo-600 dark:text-indigo-400">
              <Plus size={16} />
            </div>
            <div>
              <h3 className="text-xs font-black text-primary uppercase tracking-wider">Configuración de Ticket</h3>
              <p className="text-[8px] font-bold text-muted uppercase tracking-tight">Información comercial en el recibo</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-4">
              <h4 className="text-[9px] font-black text-muted uppercase tracking-widest border-b border-base pb-1">Hardware e Impresión</h4>
              <div className="space-y-3">
                <label className="flex items-center justify-between cursor-pointer group">
                  <div className="flex flex-col">
                    <span className="text-[10px] font-bold text-secondary group-hover:text-primary transition-colors uppercase">Impresión Automática</span>
                    <span className="text-[7px] text-muted font-medium uppercase">Sin confirmación previa</span>
                  </div>
                  <div className="relative inline-flex items-center ml-2">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={ticketConfig.autoPrint ?? false}
                      onChange={e => setTicketConfig({...ticketConfig, autoPrint: e.target.checked})}
                    />
                    <div className="w-8 h-4 bg-slate-200 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-indigo-600"></div>
                  </div>
                </label>

                <label className="flex items-center justify-between cursor-pointer group">
                  <span className="text-[10px] font-bold text-secondary group-hover:text-primary transition-colors uppercase">Abrir Gaveta</span>
                  <div className="relative inline-flex items-center">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={ticketConfig.openDrawer ?? true}
                      onChange={e => setTicketConfig({...ticketConfig, openDrawer: e.target.checked})}
                    />
                    <div className="w-8 h-4 bg-slate-200 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-indigo-600"></div>
                  </div>
                </label>
                
                <label className="flex items-center justify-between cursor-pointer group">
                  <div>
                    <span className="text-[10px] font-bold text-secondary group-hover:text-primary transition-colors block uppercase">Impresión Nativa</span>
                    <span className="text-[7px] text-muted font-medium uppercase">Directo USB / BT / WiFi</span>
                  </div>
                  <div className="relative inline-flex items-center ml-2 shrink-0">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={ticketConfig.useWebSerial ?? false}
                      onChange={e => setTicketConfig({...ticketConfig, useWebSerial: e.target.checked})}
                    />
                    <div className="w-8 h-4 bg-slate-200 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-indigo-600"></div>
                  </div>
                </label>

                {ticketConfig.useWebSerial && (
                  <div className="space-y-2.5 p-3.5 bg-subtle rounded-xl border border-base">
                    <div className="flex items-center justify-between">
                      <span className="block text-[8px] font-black text-muted uppercase tracking-widest">Buscar Impresora</span>
                      {isInIframe && (
                        <button
                          type="button"
                          onClick={() => window.open(window.location.href, '_blank')}
                          className="text-[8px] font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 bg-indigo-50 dark:bg-indigo-950/50 px-2 py-0.5 rounded transition-all cursor-pointer"
                        >
                          <ExternalLink size={10} />
                          Externo
                        </button>
                      )}
                    </div>
                    
                    {printerStatus && (
                      <div className={cn(
                        "p-2.5 rounded-lg text-[9px] font-medium leading-tight flex items-start gap-2 animate-in fade-in duration-200",
                        printerStatus.type === 'loading' && "bg-blue-50 border border-blue-200 text-blue-800 dark:bg-blue-950/20 dark:border-blue-800/50 dark:text-blue-200",
                        printerStatus.type === 'success' && "bg-emerald-50 border border-emerald-200 text-emerald-900 dark:bg-emerald-950/20 dark:border-emerald-800/50 dark:text-emerald-200",
                        printerStatus.type === 'error' && "bg-rose-50 border border-rose-200 text-rose-800 dark:bg-rose-950/20 dark:border-rose-800/50 dark:text-rose-200",
                        printerStatus.type === 'warning' && "bg-amber-50 border border-amber-200 text-amber-800 dark:bg-amber-950/20 dark:border-amber-800/50 dark:text-amber-200",
                        printerStatus.type === 'idle' && "bg-subtle border border-base text-muted"
                      )}>
                        {printerStatus.type === 'loading' && <RefreshCw size={14} className="animate-spin shrink-0 mt-0.5" />}
                        {printerStatus.type === 'success' && <CheckCircle2 size={14} className="shrink-0 mt-0.5" />}
                        {printerStatus.type === 'error' && <AlertTriangle size={14} className="shrink-0 mt-0.5" />}
                        {printerStatus.type === 'warning' && <AlertCircle size={14} className="shrink-0 mt-0.5" />}
                        <div className="flex-1">
                          <p>{printerStatus.message}</p>
                          {printerStatus.deviceName && (
                            <p className="text-[8px] opacity-80 mt-0.5 font-bold uppercase">Dispositivo: {printerStatus.deviceName}</p>
                          )}
                        </div>
                      </div>
                    )}

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={async () => {
                          setPrinterStatus({ type: 'loading', message: 'Buscando puertos USB...' });
                          try {
                            const { connectPrinter, isInsideIframe } = await import('../lib/escpos');
                            if (isInsideIframe()) {
                              setPrinterStatus({
                                type: 'warning',
                                message: 'USB nativo bloqueado en el visor. Abre en pestaña externa.'
                              });
                              return;
                            }
                            await connectPrinter();
                            setPrinterStatus({
                              type: 'success',
                              message: 'USB conectado y listo.',
                              deviceName: 'Puerto Serie USB'
                            });
                          } catch (error: any) {
                            if (error.message?.includes('cancelada')) {
                              setPrinterStatus({ type: 'idle', message: 'Selección cancelada.' });
                              return;
                            }
                            setPrinterStatus({ type: 'error', message: error.message || 'Error USB' });
                          }
                        }}
                        className="py-2.5 px-3 bg-primary border border-base text-primary rounded-lg text-[9px] font-black uppercase tracking-wider hover:bg-subtle transition-all flex items-center justify-center gap-1.5 shadow-sm active:scale-95 cursor-pointer"
                      >
                        <Usb size={14} className="text-indigo-600" />
                        USB / Serie
                      </button>

                      <button
                        type="button"
                        onClick={async () => {
                          setPrinterStatus({ type: 'loading', message: 'Escaneando Bluetooth...' });
                          try {
                            const { connectBluetoothPrinter, isInsideIframe } = await import('../lib/escpos');
                            if (isInsideIframe()) {
                              setPrinterStatus({
                                type: 'warning',
                                message: 'Bluetooth bloqueado en el visor. Abre en pestaña externa.'
                              });
                              return;
                            }
                            const dev = await connectBluetoothPrinter();
                            setPrinterStatus({
                              type: 'success',
                              message: 'Bluetooth vinculado.',
                              deviceName: dev?.name || 'BT Printer'
                            });
                          } catch (error: any) {
                            if (error.message?.includes('cancelada')) {
                              setPrinterStatus({ type: 'idle', message: 'Cancelado.' });
                              return;
                            }
                            setPrinterStatus({ type: 'error', message: error.message || 'Error BT' });
                          }
                        }}
                        className="py-2.5 px-3 bg-primary border border-base text-primary rounded-lg text-[9px] font-black uppercase tracking-wider hover:bg-subtle transition-all flex items-center justify-center gap-1.5 shadow-sm active:scale-95 cursor-pointer"
                      >
                        <Bluetooth size={14} className="text-blue-600" />
                        Bluetooth
                      </button>
                    </div>

                    <div className="pt-2 border-t border-base flex items-center gap-2">
                      <div className="relative flex-1">
                        <Wifi size={12} className="text-muted absolute left-2.5 top-1/2 -translate-y-1/2" />
                        <input
                          type="text"
                          placeholder="IP (Ej: 192.168.1.100)"
                          value={ticketConfig.printerIp || ''}
                          onChange={e => setTicketConfig({ ...ticketConfig, printerIp: e.target.value })}
                          className="w-full pl-7 pr-2 py-1.5 bg-primary border border-base rounded-lg text-[10px] font-bold text-primary placeholder:text-muted outline-none focus:ring-1 focus:ring-indigo-500"
                        />
                      </div>
                    </div>

                    <div className="space-y-1 pt-1">
                      <button
                        type="button"
                        onClick={async () => {
                          try {
                            const { printESCPOS } = await import('../lib/escpos');
                            const randomProducts = [...products].sort(() => 0.5 - Math.random()).slice(0, 2);
                            const productLines = randomProducts.map(p => `LEFT|${p.name.toUpperCase()} x1 ... $${p.price}`);
                            
                            const lines = [
                              "CENTER|BOLD|" + (ticketConfig.businessName || "MI NEGOCIO"),
                              "CENTER|" + (ticketConfig.businessAddress || "DIRECCIÓN DE PRUEBA"),
                              "CENTER|TEL: " + (ticketConfig.businessPhone || "000-000-0000"),
                              "---",
                              "CENTER|BOLD|TICKET DE PRUEBA",
                              "---",
                              ...productLines,
                              "---",
                              "CENTER|BOLD|TOTAL: $0.00",
                              "---",
                              "CENTER|" + (ticketConfig.footerText || "¡GRACIAS POR SU COMPRA!"),
                              "CENTER|VERSIÓN 2.0"
                            ];

                            await printESCPOS({
                              lines: lines,
                              width: ticketConfig.printerWidth || '58mm'
                            });
                          } catch (err: any) {
                            setPrinterStatus({ type: 'error', message: `Error: ${err.message}` });
                          }
                        }}
                        className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-[10px] font-black uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-sm active:scale-95 cursor-pointer"
                      >
                        <Printer size={15} />
                        Ticket de Prueba
                      </button>
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-[8px] font-black text-muted uppercase tracking-widest mb-1">Ancho de Papel</label>
                  <select 
                    value={ticketConfig.printerWidth || '80mm'}
                    onChange={e => setTicketConfig({...ticketConfig, printerWidth: e.target.value as '58mm' | '80mm'})}
                    className="w-full px-3 py-2 bg-primary border border-base rounded-xl text-xs font-bold text-primary outline-none focus:ring-1 focus:ring-indigo-500 cursor-pointer"
                  >
                    <option value="58mm">58 mm (Pequeña)</option>
                    <option value="80mm">80 mm (Estándar)</option>
                  </select>
                </div>
              </div>
              
              <h4 className="text-[9px] font-black text-muted uppercase tracking-widest border-b border-base pb-1 mt-6">Visibilidad</h4>
              <div className="space-y-3">
                {[
                  { key: 'showLogo', label: 'Nombre / Logo' },
                  { key: 'showAddress', label: 'Dirección' },
                  { key: 'showPhone', label: 'Teléfono' },
                  { key: 'showFooter', label: 'Pie de Página' },
                ].map(item => (
                  <label key={item.key} className="flex items-center justify-between cursor-pointer group">
                    <span className="text-[10px] font-bold text-secondary group-hover:text-primary transition-colors uppercase">{item.label}</span>
                    <div className="relative inline-flex items-center">
                      <input 
                        type="checkbox" 
                        className="sr-only peer"
                        checked={(ticketConfig as any)[item.key]}
                        onChange={e => setTicketConfig({...ticketConfig, [item.key]: e.target.checked})}
                      />
                      <div className="w-8 h-4 bg-slate-200 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-indigo-600"></div>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            <div className="space-y-4 col-span-1 md:col-span-2">
              <h4 className="text-[9px] font-black text-muted uppercase tracking-widest border-b border-base pb-1">Información Impresa</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="block text-[8px] font-black text-muted uppercase tracking-widest">Nombre Comercial</label>
                  <input type="text" value={ticketConfig.businessName} onChange={e => setTicketConfig({...ticketConfig, businessName: e.target.value})} className="w-full px-3 py-2 bg-primary border border-base rounded-xl text-xs font-bold text-primary outline-none focus:ring-1 focus:ring-indigo-500 transition-all" />
                </div>
                <div className="space-y-1">
                  <label className="block text-[8px] font-black text-muted uppercase tracking-widest">Teléfono</label>
                  <input type="text" value={ticketConfig.businessPhone} onChange={e => setTicketConfig({...ticketConfig, businessPhone: e.target.value})} className="w-full px-3 py-2 bg-primary border border-base rounded-xl text-xs font-bold text-primary outline-none focus:ring-1 focus:ring-indigo-500 transition-all" />
                </div>
                <div className="sm:col-span-2 space-y-1">
                  <label className="block text-[8px] font-black text-muted uppercase tracking-widest">Dirección</label>
                  <input type="text" value={ticketConfig.businessAddress} onChange={e => setTicketConfig({...ticketConfig, businessAddress: e.target.value})} className="w-full px-3 py-2 bg-primary border border-base rounded-xl text-xs font-bold text-primary outline-none focus:ring-1 focus:ring-indigo-500 transition-all" />
                </div>
                <div className="sm:col-span-2 space-y-1">
                  <label className="block text-[8px] font-black text-muted uppercase tracking-widest">Texto al Pie</label>
                  <textarea 
                    value={ticketConfig.footerText} 
                    onChange={e => setTicketConfig({...ticketConfig, footerText: e.target.value})}
                    rows={2}
                    className="w-full px-3 py-2 bg-primary border border-base rounded-xl text-xs font-bold text-primary outline-none focus:ring-1 focus:ring-indigo-500 resize-none transition-all"
                    placeholder="Ej: ¡Gracias por su compra!"
                  ></textarea>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-base">
            <button 
              onClick={handleSaveTicket}
              className="w-full sm:w-auto px-8 py-3 bg-indigo-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-md active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
            >
              <Save size={14} />
              Guardar Configuración
            </button>
          </div>
        </div>

      {true && (
        <div className="bg-secondary rounded-2xl shadow-sm border border-base p-5 space-y-4 lg:col-span-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-base pb-3">
            <div className="flex items-center gap-3">
              <div className="bg-indigo-50 dark:bg-indigo-950/30 p-2 rounded-lg text-indigo-600 dark:text-indigo-400">
                <Users size={16} />
              </div>
              <div>
                <h3 className="text-xs font-black text-primary uppercase tracking-wider">Gestión de Personal</h3>
                <p className="text-[8px] font-bold text-muted uppercase tracking-tight">Vendedores Normales e Independientes (IDN)</p>
              </div>
            </div>

            {/* Segmented Filter for Normal vs IDN */}
            <div className="flex items-center bg-subtle p-1 rounded-xl gap-1 border border-base">
              <button
                type="button"
                onClick={() => setUserFilterTab('all')}
                className={cn(
                  "px-3 py-1.5 rounded-lg text-[9px] font-black uppercase transition-all cursor-pointer",
                  userFilterTab === 'all' 
                    ? "bg-secondary text-primary shadow-sm border border-base" 
                    : "text-muted hover:text-primary"
                )}
              >
                Todos
              </button>
              <button
                type="button"
                onClick={() => setUserFilterTab('normal')}
                className={cn(
                  "px-3 py-1.5 rounded-lg text-[9px] font-black uppercase transition-all flex items-center gap-1 cursor-pointer",
                  userFilterTab === 'normal' 
                    ? "bg-indigo-600 text-white shadow-sm" 
                    : "text-muted hover:text-primary"
                )}
              >
                <Users size={12} />
                Normales
              </button>
              <button
                type="button"
                onClick={() => setUserFilterTab('idn')}
                className={cn(
                  "px-3 py-1.5 rounded-lg text-[9px] font-black uppercase transition-all flex items-center gap-1 cursor-pointer",
                  userFilterTab === 'idn' 
                    ? "bg-amber-600 text-white shadow-sm" 
                    : "text-muted hover:text-primary"
                )}
              >
                <Package size={12} />
                IDN
              </button>
            </div>
          </div>

          {/* New Employee Form */}
          <div className="bg-subtle p-4 rounded-xl border border-base border-dashed">
            <h4 className="text-[10px] font-black text-primary uppercase mb-3 flex items-center gap-2">
              <Plus size={14} className="text-indigo-600" />
              Registrar Personal
            </h4>
            <form onSubmit={handleRegisterEmployeeManual} className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="block text-[8px] font-black text-muted uppercase tracking-widest">Nombre</label>
                  <input 
                    type="text"
                    placeholder="Nombre completo"
                    required
                    value={newEmployee.name}
                    onChange={e => setNewEmployee({ ...newEmployee, name: e.target.value })}
                    className="w-full px-3 py-2 bg-primary border border-base rounded-lg text-xs font-bold text-primary outline-none focus:ring-1 focus:ring-indigo-500 transition-all"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block text-[8px] font-black text-muted uppercase tracking-widest">Contraseña</label>
                  <input 
                    type="password"
                    placeholder="Contraseña inicial"
                    required
                    value={newEmployee.password}
                    onChange={e => setNewEmployee({ ...newEmployee, password: e.target.value })}
                    className="w-full px-3 py-2 bg-primary border border-base rounded-lg text-xs font-bold text-primary outline-none focus:ring-1 focus:ring-indigo-500 transition-all"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block text-[8px] font-black text-muted uppercase tracking-widest">Tipo</label>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setNewEmployee({ ...newEmployee, isIndependent: false, assignedBranchId: "" })}
                      className={cn(
                        "flex-1 py-2 rounded-lg text-[9px] font-black uppercase border transition-all cursor-pointer",
                        !newEmployee.isIndependent 
                          ? "bg-indigo-600 text-white border-indigo-600 shadow-sm" 
                          : "bg-primary text-secondary border-base"
                      )}
                    >
                      Fijo
                    </button>
                    <button
                      type="button"
                      onClick={() => setNewEmployee({ ...newEmployee, isIndependent: true })}
                      className={cn(
                        "flex-1 py-2 rounded-lg text-[9px] font-black uppercase border transition-all cursor-pointer",
                        newEmployee.isIndependent 
                          ? "bg-amber-600 text-white border-amber-600 shadow-sm" 
                          : "bg-primary text-secondary border-base"
                      )}
                    >
                      IDN
                    </button>
                  </div>
                </div>
              </div>

              {newEmployee.isIndependent && (
                <div className="bg-amber-50/50 dark:bg-amber-900/20 p-3 rounded-xl border border-amber-100 dark:border-amber-800/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <Package size={16} className="text-amber-600" />
                    <div>
                      <p className="text-[9px] font-black text-amber-900 dark:text-amber-200 uppercase">Almacén Exclusivo</p>
                      <p className="text-[7px] font-bold text-amber-700 dark:text-amber-400 uppercase">Stock asignado para IDN</p>
                    </div>
                  </div>
                  <select 
                    value={newEmployee.assignedBranchId}
                    onChange={e => setNewEmployee({ ...newEmployee, assignedBranchId: e.target.value })}
                    className="w-full sm:w-64 bg-primary border border-amber-200 dark:border-amber-800 rounded-lg px-3 py-2 text-xs font-bold text-primary outline-none focus:ring-1 focus:ring-amber-500"
                  >
                    <option value="">Seleccionar Almacén</option>
                    {branches.map(b => (
                      <option key={b.id} value={b.id}>{b.name}</option>
                    ))}
                  </select>
                </div>
              )}

              <div className="flex justify-end pt-1">
                <button 
                  type="submit"
                  className="w-full sm:w-auto px-6 py-2 bg-indigo-600 text-white rounded-lg text-[10px] font-black uppercase tracking-widest transition-all shadow-md flex items-center justify-center gap-2"
                >
                  <Plus size={14} />
                  Registrar
                </button>
              </div>
            </form>
          </div>
          
          {/* Employee Cards Grid (Compact & Tablet Optimized) */}
          {users.length === 0 ? (
            <div className="p-8 bg-subtle rounded-xl text-center text-sm font-bold text-muted">
              No hay usuarios o trabajadores registrados en el sistema.
            </div>
          ) : (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {users
                  .filter(u => {
                    if (userFilterTab === 'normal') return !u.isIndependent;
                    if (userFilterTab === 'idn') return u.isIndependent;
                    return true;
                  })
                  .map(u => {
                    const isIdn = u.isIndependent;
                    const assignedBranchName = branches.find(b => b.id === u.assignedBranchId)?.name;
                    const allowedCount = (u.allowedBranches || branches.map(b => b.id)).length;

                    return (
                      <div 
                        key={u.id} 
                        className={cn(
                          "p-3.5 rounded-2xl border transition-all flex flex-col justify-between gap-3 shadow-sm hover:shadow-md",
                          isIdn 
                            ? "bg-amber-50/10 dark:bg-amber-900/10 border-amber-200 dark:border-amber-800/50" 
                            : "bg-secondary border-base"
                        )}
                      >
                        {/* Header card */}
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <p className="text-xs font-black text-primary uppercase truncate">{u.name}</p>
                              <span className="text-[7px] font-black uppercase bg-subtle px-1.5 py-0.5 rounded text-muted">
                                {u.role === 'admin' ? 'Admin' : 'Empleado'}
                              </span>
                            </div>
                            <div className="flex items-center gap-1 mt-1">
                              <span className={cn(
                                "text-[7px] font-black uppercase px-2 py-0.5 rounded-full inline-flex items-center gap-1 border",
                                isIdn 
                                  ? "bg-amber-100 text-amber-800 border-amber-300 dark:bg-amber-950 dark:text-amber-300 dark:border-amber-800" 
                                  : "bg-indigo-100 text-indigo-800 border-indigo-200 dark:bg-indigo-950 dark:text-indigo-300 dark:border-indigo-800"
                              )}>
                                {isIdn ? <Package size={10} /> : <Users size={10} />}
                                {isIdn ? 'Vendedor IDN' : 'Fijo / Normal'}
                              </span>
                            </div>
                          </div>

                          {/* Quick Delete */}
                          <button
                            type="button"
                            onClick={() => setUserToDelete({ id: u.id, name: u.name })}
                            className="p-1.5 text-muted hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-lg transition-colors cursor-pointer"
                            title="Desactivar Empleado"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>

                        {/* Middle info */}
                        <div className="bg-subtle p-2.5 rounded-xl border border-base text-[9px] space-y-1">
                          <div className="flex justify-between font-bold text-muted">
                            <span>Sucursales:</span>
                            {isIdn ? (
                              <span className={assignedBranchName ? "text-indigo-600 dark:text-indigo-400 font-black" : "text-rose-600 font-black"}>
                                {assignedBranchName ? `📍 ${assignedBranchName}` : '⚠️ Sin asignar'}
                              </span>
                            ) : (
                              <span className="text-primary font-black">
                                {allowedCount === branches.length ? 'Todas' : `${allowedCount} autorizadas`}
                              </span>
                            )}
                          </div>
                          <div className="flex justify-between font-bold text-muted">
                            <span>Salario Base:</span>
                            <span className="text-primary font-black">
                              {baseCurrency.symbol}{(employeeSalaries[u.id] ?? (u.baseSalary || 0)).toLocaleString()} CUP
                            </span>
                          </div>
                          {isIdn && (
                            <div className="flex justify-between font-bold text-muted">
                              <span>Precios Especiales:</span>
                              <span className="text-amber-600 font-black">
                                {idnSettlementPrices.filter(sp => sp.userId === u.id).length} asignados
                              </span>
                            </div>
                          )}
                        </div>

                        {/* Action buttons */}
                        <button
                          type="button"
                          onClick={() => setSelectedUserForConfig(u)}
                          className={cn(
                            "w-full py-2 px-3 rounded-xl font-black text-[9px] uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 shadow-sm active:scale-95 cursor-pointer",
                            isIdn 
                              ? "bg-amber-600 text-white" 
                              : "bg-indigo-600 text-white"
                          )}
                        >
                          <SettingsIcon size={14} />
                          Configuración
                        </button>
                      </div>
                    );
                  })}
              </div>
            </div>
          )}
          
          <div className="bg-amber-50 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-900/50 p-3 rounded-xl flex gap-3">
            <InfoTooltip text="Configura aquí el pago base y los accesos. Cada empleado puede configurarse con permisos individuales de sucursales o como vendedor independiente (IDN) con almacén exclusivo y precios de liquidación." />
            <p className="text-[9px] text-amber-700 dark:text-amber-300 font-medium leading-relaxed">
              <strong>Tip:</strong> Haz clic en <strong>Configuración</strong> para modificar sucursales, contraseñas o ajustar precios de liquidación IDN.
            </p>
          </div>
        </div>
      )}

      {/* Zona Peligrosa */}
      <div className="bg-secondary rounded-2xl shadow-sm border border-red-200 dark:border-red-900/30 p-5 space-y-4 lg:col-span-3">
        <div className="flex items-center gap-3 border-b border-red-50 dark:border-red-950/30 pb-3">
          <div className="bg-red-50 dark:bg-red-950/50 p-2 rounded-lg text-red-600 dark:text-red-400">
            <AlertTriangle size={16} />
          </div>
          <div>
            <h3 className="text-xs font-black text-red-600 dark:text-red-400 uppercase tracking-wider">Zona Peligrosa</h3>
            <p className="text-[8px] font-bold text-muted uppercase tracking-tight">Acciones críticas e irreversibles</p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-primary p-4 rounded-xl border border-base border-dashed">
          <div>
            <h4 className="text-sm font-bold text-primary">Limpiar caché del navegador</h4>
            <p className="text-xs text-muted mt-1">
              Limpia recursos temporales del navegador sin borrar ventas, inventario ni la información operativa guardada.
            </p>
          </div>
          <div className="flex gap-2">
            {showConfirmCache ? (
              <>
                <button
                  onClick={() => setShowConfirmCache(false)}
                  className="px-4 py-2 bg-subtle text-primary border border-base rounded-xl text-[10px] font-black uppercase tracking-widest transition-all"
                >
                  Cancelar
                </button>
                <button
                  onClick={async () => {
                    try {
                      sessionStorage.clear();
                      if ('caches' in window) {
                        const cacheNames = await caches.keys();
                        await Promise.all(cacheNames.map(name => caches.delete(name)));
                      }
                    } catch (e) {
                      console.error('Error limpiando caché:', e);
                    }
                    window.location.href = "/";
                  }}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-md active:scale-95"
                >
                  Confirmar
                </button>
              </>
            ) : (
              <button
                onClick={() => setShowConfirmCache(true)}
                className="w-full sm:w-auto px-6 py-3 bg-indigo-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-md active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
              >
                <RefreshCw size={14} />
                Limpiar Caché
              </button>
            )}
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-red-50/50 dark:bg-red-950/20 p-4 rounded-xl border border-red-100 dark:border-red-900/30">
          <div className="flex-1">
            <h4 className="text-sm font-bold text-primary">Restablecer Sistema</h4>
            <p className="text-xs text-muted mt-1">Selecciona exactamente qué módulos quieres restablecer. Los demás datos permanecen intactos.</p>
            {showConfirmReset && (
              <div className="mt-4 w-full p-4 bg-primary rounded-xl border border-red-200 dark:border-red-900/50">
                <div className="flex items-center justify-between gap-3 mb-3">
                  <div>
                    <p className="text-xs font-black text-primary uppercase">¿Qué deseas restablecer?</p>
                    <p className="text-[10px] text-muted mt-1">Marca uno o varios módulos.</p>
                  </div>
                  <button type="button" onClick={toggleAllResetSections} className="px-3 py-2 text-[10px] font-black uppercase rounded-lg border border-base text-primary hover:bg-subtle">
                    {resetSections.length === RESET_OPTIONS.length ? 'Desmarcar todo' : 'Marcar todo'}
                  </button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                  {RESET_OPTIONS.map(option => {
                    const Icon = option.icon;
                    const checked = resetSections.includes(option.id);
                    return (
                      <label key={option.id} className={cn('flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition-all', checked ? 'border-red-500 bg-red-50 dark:bg-red-950/20' : 'border-base hover:bg-subtle')}>
                        <input type="checkbox" checked={checked} onChange={() => toggleResetSection(option.id)} className="mt-1 h-4 w-4 accent-red-600" />
                        <span className="min-w-0">
                          <span className="flex items-center gap-2 text-xs font-black text-primary"><Icon size={14} />{option.label}</span>
                          <span className="block text-[10px] text-muted mt-1 leading-snug">{option.desc}</span>
                        </span>
                      </label>
                    );
                  })}
                </div>
                <div className="mt-4 p-3 rounded-lg bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900/50">
                  <p className="text-[10px] font-black text-red-700 dark:text-red-300 uppercase">Se borrará únicamente lo seleccionado</p>
                  <p className="text-[10px] text-muted mt-1">Esta acción no se puede deshacer. Antes de continuar, confirma escribiendo ELIMINAR.</p>
                </div>
                <input type="text" value={resetInput} onChange={e => setResetInput(e.target.value)} className="mt-3 w-full px-3 py-3 bg-secondary border border-base rounded-lg text-sm font-bold text-primary outline-none focus:ring-1 focus:ring-red-500 uppercase" placeholder="Escribe ELIMINAR" />
              </div>
            )}
          </div>
          <div className="flex gap-2 shrink-0">
            {showConfirmReset ? (
              <>
                <button onClick={() => { setShowConfirmReset(false); setResetInput(''); setResetSections([]); }} className="px-4 py-2 bg-subtle text-primary border border-base rounded-xl text-[10px] font-black uppercase tracking-widest">Cancelar</button>
                <button onClick={handleClearData} disabled={isLoading || resetSections.length === 0 || resetInput.trim().toUpperCase() !== 'ELIMINAR'} className="px-4 py-2 bg-red-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-md disabled:opacity-30 flex items-center gap-2">
                  {isLoading ? <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white" /> : <Trash2 size={12} />} Restablecer seleccionados
                </button>
              </>
            ) : (
              <button onClick={() => setShowConfirmReset(true)} disabled={isLoading} className="w-full sm:w-auto px-6 py-3 bg-red-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-md active:scale-95 flex items-center justify-center gap-2 disabled:opacity-50">
                <Trash2 size={14} /> Restablecer datos
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
